<?php
require_once '../api/db.php';

header('Content-Type: text/html; charset=utf-8');

echo "<h2>Debug - Atribuir Responsável</h2>";

try {
    $db = getDB();
    
    // 1. Verificar estrutura da tabela schedules
    echo "<h3>1. Estrutura da tabela 'schedules':</h3>";
    $stmt = $db->query("DESCRIBE schedules");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<pre>";
    foreach ($columns as $col) {
        echo $col['Field'] . " - " . $col['Type'] . "\n";
    }
    echo "</pre>";
    
    // 2. Verificar se a coluna assigned_to existe
    $hasAssignedTo = false;
    foreach ($columns as $column) {
        if ($column['Field'] === 'assigned_to') {
            $hasAssignedTo = true;
            break;
        }
    }
    
    if ($hasAssignedTo) {
        echo "<p style='color: green;'>✓ Coluna 'assigned_to' existe!</p>";
    } else {
        echo "<p style='color: red;'>✗ Coluna 'assigned_to' NÃO existe!</p>";
        echo "<p>Execute o script: fixes/add_assigned_to_schedules.php</p>";
    }
    
    // 3. Verificar agendamentos de grupo
    echo "<h3>2. Agendamentos de grupo (últimos 5):</h3>";
    $stmt = $db->query("
        SELECT s.id, s.group_id, s.scheduled_date, s.scheduled_time, s.meal_type, 
               s.user_id, s.assigned_to,
               g.name as group_name
        FROM schedules s
        LEFT JOIN `groups` g ON s.group_id = g.id
        WHERE s.group_id IS NOT NULL
        ORDER BY s.id DESC
        LIMIT 5
    ");
    $schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($schedules) > 0) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Grupo</th><th>Data</th><th>Hora</th><th>Tipo</th><th>User ID</th><th>Assigned To</th></tr>";
        foreach ($schedules as $sched) {
            echo "<tr>";
            echo "<td>" . $sched['id'] . "</td>";
            echo "<td>" . ($sched['group_name'] ?? 'N/A') . "</td>";
            echo "<td>" . ($sched['scheduled_date'] ?? 'N/A') . "</td>";
            echo "<td>" . ($sched['scheduled_time'] ?? 'N/A') . "</td>";
            echo "<td>" . ($sched['meal_type'] ?? 'N/A') . "</td>";
            echo "<td>" . $sched['user_id'] . "</td>";
            echo "<td>" . ($sched['assigned_to'] ?? 'NULL') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Nenhum agendamento de grupo encontrado.</p>";
    }
    
    // 4. Verificar membros de grupos
    echo "<h3>3. Membros de grupos:</h3>";
    $stmt = $db->query("
        SELECT gm.group_id, g.name as group_name, gm.user_id, u.username, gm.role
        FROM `group_members` gm
        JOIN `groups` g ON gm.group_id = g.id
        JOIN users u ON gm.user_id = u.id
        ORDER BY gm.group_id, gm.user_id
        LIMIT 10
    ");
    $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($members) > 0) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Grupo ID</th><th>Grupo Nome</th><th>User ID</th><th>Username</th><th>Role</th></tr>";
        foreach ($members as $member) {
            echo "<tr>";
            echo "<td>" . $member['group_id'] . "</td>";
            echo "<td>" . $member['group_name'] . "</td>";
            echo "<td>" . $member['user_id'] . "</td>";
            echo "<td>" . $member['username'] . "</td>";
            echo "<td>" . $member['role'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Nenhum membro de grupo encontrado.</p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>Erro: " . $e->getMessage() . "</p>";
}
?>
