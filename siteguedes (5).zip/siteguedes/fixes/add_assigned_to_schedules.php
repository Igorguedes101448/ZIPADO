<?php
// ============================================
// Adicionar Coluna assigned_to em Schedules
// ============================================

require_once '../api/db.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar assigned_to - ChefGuedes</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            border-bottom: 3px solid #16a085;
            padding-bottom: 10px;
        }
        .success {
            color: #27ae60;
            background: #d5f4e6;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .error {
            color: #c0392b;
            background: #fadbd8;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .info {
            color: #2980b9;
            background: #d6eaf8;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        code {
            background: #ecf0f1;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Adicionar Coluna assigned_to na Tabela Schedules</h1>
        
        <div class="info">
            <strong>ℹ️ Informação:</strong><br>
            Esta migração adiciona a coluna <code>assigned_to</code> à tabela <code>schedules</code><br>
            permitindo atribuir um membro do grupo como responsável pela receita agendada.
        </div>

<?php
try {
    $db = getDB();
    echo "<h2>Verificando estado atual...</h2>";
    
    // Verificar se a coluna já existe
    $stmt = $db->query("SHOW COLUMNS FROM schedules LIKE 'assigned_to'");
    $columnExists = $stmt->fetch();
    
    if ($columnExists) {
        echo "<div class='success'>✅ A coluna 'assigned_to' já existe na tabela 'schedules'!</div>";
    } else {
        echo "<p style='color: #e67e22;'>⚠️ A coluna 'assigned_to' não existe. Adicionando...</p>";
        
        // Adicionar coluna
        $db->exec("
            ALTER TABLE schedules 
            ADD COLUMN assigned_to INT(11) NULL DEFAULT NULL AFTER notes
        ");
        echo "<div class='success'>✅ Coluna 'assigned_to' adicionada com sucesso!</div>";
        
        // Verificar se a chave estrangeira existe
        $stmt = $db->query("
            SELECT CONSTRAINT_NAME 
            FROM information_schema.TABLE_CONSTRAINTS 
            WHERE TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME = 'schedules' 
            AND CONSTRAINT_NAME = 'fk_schedules_assigned_to'
        ");
        $fkExists = $stmt->fetch();
        
        if (!$fkExists) {
            // Adicionar chave estrangeira
            $db->exec("
                ALTER TABLE schedules 
                ADD CONSTRAINT fk_schedules_assigned_to 
                FOREIGN KEY (assigned_to) REFERENCES users(id) 
                ON DELETE SET NULL
            ");
            echo "<div class='success'>✅ Chave estrangeira adicionada com sucesso!</div>";
        } else {
            echo "<div class='success'>✅ Chave estrangeira já existe!</div>";
        }
        
        // Verificar se o índice existe
        $stmt = $db->query("
            SELECT INDEX_NAME 
            FROM information_schema.STATISTICS 
            WHERE TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME = 'schedules' 
            AND INDEX_NAME = 'idx_assigned_to'
        ");
        $indexExists = $stmt->fetch();
        
        if (!$indexExists) {
            // Criar índice
            $db->exec("CREATE INDEX idx_assigned_to ON schedules(assigned_to)");
            echo "<div class='success'>✅ Índice criado com sucesso!</div>";
        } else {
            echo "<div class='success'>✅ Índice já existe!</div>";
        }
    }
    
    // Mostrar estrutura final
    echo "<h2>Estrutura Final da Tabela Schedules:</h2>";
    echo "<div style='background: #ecf0f1; padding: 15px; border-radius: 5px; overflow-x: auto;'>";
    echo "<table style='width: 100%; border-collapse: collapse;'>";
    echo "<tr style='background: #34495e; color: white;'>";
    echo "<th style='padding: 10px; text-align: left;'>Campo</th>";
    echo "<th style='padding: 10px; text-align: left;'>Tipo</th>";
    echo "<th style='padding: 10px; text-align: left;'>Nulo</th>";
    echo "<th style='padding: 10px; text-align: left;'>Padrão</th>";
    echo "</tr>";
    
    $stmt = $db->query("SHOW COLUMNS FROM schedules");
    $columns = $stmt->fetchAll();
    $alternate = false;
    
    foreach ($columns as $column) {
        $bgColor = $alternate ? '#f8f9fa' : 'white';
        $alternate = !$alternate;
        
        echo "<tr style='background: {$bgColor};'>";
        echo "<td style='padding: 8px;'><code>{$column['Field']}</code></td>";
        echo "<td style='padding: 8px;'>{$column['Type']}</td>";
        echo "<td style='padding: 8px;'>{$column['Null']}</td>";
        echo "<td style='padding: 8px;'>" . ($column['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    
    echo "</table></div>";
    
    echo "<div class='success' style='margin-top: 20px;'>";
    echo "<strong>✅ Migração concluída com sucesso!</strong><br>";
    echo "A coluna <code>assigned_to</code> está agora disponível para uso.";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div class='error'>";
    echo "<strong>❌ Erro:</strong><br>";
    echo htmlspecialchars($e->getMessage());
    echo "</div>";
}
?>

        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
            <a href="../pages/grupos.html" style="color: #16a085; text-decoration: none; font-weight: bold;">← Voltar para Grupos</a>
        </div>
    </div>
</body>
</html>
