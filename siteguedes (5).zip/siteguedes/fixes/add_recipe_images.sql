-- Script para adicionar imagens às receitas existentes
-- Execute este script para atualizar as receitas com os caminhos corretos das imagens

-- Atualizar Bacalhau à Brás
UPDATE recipes 
SET image = '../images/receitas/bacalhau-bras.jpg'
WHERE (title LIKE '%Bacalhau%Brás%' OR title LIKE '%Bacalhau%Bras%') AND (image IS NULL OR image = '');

-- Atualizar Caldo Verde
UPDATE recipes 
SET image = '../images/receitas/caldo-verde.jpg'
WHERE title LIKE '%Caldo Verde%' AND (image IS NULL OR image = '');

-- Atualizar Francesinha
UPDATE recipes 
SET image = '../images/receitas/francesinha.png'
WHERE title LIKE '%Francesinha%' AND (image IS NULL OR image = '');

-- Atualizar Açorda Alentejana
UPDATE recipes 
SET image = '../images/receitas/acorda-alentejana.avif'
WHERE (title LIKE '%Açorda%' OR title LIKE '%Acorda%') AND (image IS NULL OR image = '');

-- Atualizar Arroz de Marisco
UPDATE recipes 
SET image = '../images/receitas/arroz-marisco.jpg'
WHERE title LIKE '%Arroz%Marisco%' AND (image IS NULL OR image = '');

-- Atualizar Polvo à Lagareiro
UPDATE recipes 
SET image = '../images/receitas/polvo-lagareiro.jpg'
WHERE title LIKE '%Polvo%Lagareiro%' AND (image IS NULL OR image = '');

-- Atualizar Pastéis de Nata
UPDATE recipes 
SET image = '../images/receitas/pasteis-nata.webp'
WHERE (title LIKE '%Pastéis de Nata%' OR title LIKE '%Pasteis de Nata%') AND (image IS NULL OR image = '');

-- Atualizar Cozido à Portuguesa
UPDATE recipes 
SET image = '../images/receitas/cozido-portuguesa.png'
WHERE (title LIKE '%Cozido%Portuguesa%' OR title LIKE '%Cozido%Português%') AND (image IS NULL OR image = '');

-- Verificar receitas atualizadas
SELECT id, title, image FROM recipes WHERE image IS NOT NULL AND image != '';
