<?php
/**
 * Script para adicionar imagens às receitas existentes
 * Execute este script uma vez para atualizar todas as receitas com imagens
 */

require_once '../api/db.php';

try {
    $db = getDB();
    
    echo "<h2>Atualizando imagens das receitas...</h2>";
    
    // Array de mapeamento: título => imagem
    $receitasComImagens = [
        '%Bacalhau%Brás%' => '../images/receitas/bacalhau-bras.jpg',
        '%Bacalhau%Bras%' => '../images/receitas/bacalhau-bras.jpg',
        '%Caldo Verde%' => '../images/receitas/caldo-verde.jpg',
        '%Francesinha%' => '../images/receitas/francesinha.png',
        '%Açorda%' => '../images/receitas/acorda-alentejana.avif',
        '%Acorda%' => '../images/receitas/acorda-alentejana.avif',
        '%Arroz%Marisco%' => '../images/receitas/arroz-marisco.jpg',
        '%Polvo%Lagareiro%' => '../images/receitas/polvo-lagareiro.jpg',
        '%Pastéis de Nata%' => '../images/receitas/pasteis-nata.webp',
        '%Pasteis de Nata%' => '../images/receitas/pasteis-nata.webp',
        '%Cozido%Portuguesa%' => '../images/receitas/cozido-portuguesa.png',
        '%Cozido%Português%' => '../images/receitas/cozido-portuguesa.png',
    ];
    
    $totalAtualizadas = 0;
    
    foreach ($receitasComImagens as $pattern => $imagePath) {
        $stmt = $db->prepare("
            UPDATE recipes 
            SET image = ?
            WHERE title LIKE ? AND (image IS NULL OR image = '')
        ");
        
        $stmt->execute([$imagePath, $pattern]);
        $affected = $stmt->rowCount();
        
        if ($affected > 0) {
            echo "<p style='color: green;'>✓ Atualizadas {$affected} receita(s) com padrão '{$pattern}'</p>";
            $totalAtualizadas += $affected;
        }
    }
    
    echo "<hr>";
    echo "<h3>Resumo:</h3>";
    echo "<p><strong>Total de receitas atualizadas: {$totalAtualizadas}</strong></p>";
    
    // Listar receitas com imagens
    echo "<h3>Receitas com imagens:</h3>";
    $stmt = $db->query("SELECT id, title, image FROM recipes WHERE image IS NOT NULL AND image != '' ORDER BY title");
    $receitasComImagem = $stmt->fetchAll();
    
    if (count($receitasComImagem) > 0) {
        echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>Título</th><th>Imagem</th></tr>";
        foreach ($receitasComImagem as $receita) {
            echo "<tr>";
            echo "<td>{$receita['id']}</td>";
            echo "<td>{$receita['title']}</td>";
            echo "<td>{$receita['image']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Nenhuma receita com imagem encontrada.</p>";
    }
    
    echo "<hr>";
    echo "<p><a href='../pages/explorar-receitas.html'>Ver Receitas</a></p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>Erro: " . $e->getMessage() . "</p>";
}
?>
