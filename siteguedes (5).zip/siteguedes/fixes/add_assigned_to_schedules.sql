-- Adicionar coluna assigned_to à tabela schedules
-- Esta coluna permite atribuir um membro do grupo como responsável pela receita agendada

ALTER TABLE schedules 
ADD COLUMN assigned_to INT(11) NULL DEFAULT NULL AFTER notes,
ADD CONSTRAINT fk_schedules_assigned_to 
    FOREIGN KEY (assigned_to) REFERENCES users(id) 
    ON DELETE SET NULL;

-- Criar índice para melhor performance
CREATE INDEX idx_assigned_to ON schedules(assigned_to);
