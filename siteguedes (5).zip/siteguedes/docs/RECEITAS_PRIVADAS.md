# Funcionalidade: Receitas Privadas

## Descrição
Esta funcionalidade permite aos utilizadores gerir as suas receitas privadas e rascunhos numa página dedicada, com total controlo sobre a privacidade e edição das suas criações culinárias.

## Ficheiros Criados

### 1. `/pages/minhas-receitas-privadas.html`
Página HTML dedicada para visualizar e gerir receitas privadas.

**Características:**
- Layout responsivo com grid de receitas
- Filtros de pesquisa e visibilidade (todas/privadas/rascunhos)
- Badges visuais para identificar o estado de cada receita
- Botões de ação: Editar, Ver, Eliminar
- Modal de edição integrado
- Navegação fácil de volta ao dashboard

### 2. `/js/minhas-receitas-privadas.js`
Script JavaScript para gerir toda a lógica da página.

**Funcionalidades:**
- Carregar receitas privadas via API com autenticação
- Filtrar e pesquisar receitas em tempo real
- Modal de edição com formulário completo
- Gestão dinâmica de ingredientes
- Atualização de receitas com validação
- Eliminação de receitas com confirmação
- Integração com filtro de profanidade

## Alterações em Ficheiros Existentes

### API Backend: `/api/recipes.php`
**Melhorias adicionadas:**
- ✅ Suporte para método HTTP PUT (atualização RESTful)
- ✅ Suporte para método HTTP DELETE (eliminação RESTful)
- ✅ Campo `image_url` como alternativa a `image`
- ✅ Campo `is_draft` com suporte para ambas as notações (camelCase e snake_case)
- ✅ Atualização automática do campo `updated_at`
- ✅ Validação de propriedade da receita antes de permitir edição/eliminação

**Segurança:**
- Apenas o autor da receita pode editar ou eliminar
- Validação de token de autenticação obrigatória
- Verificação de sessão ativa

### Navegação Global
Todos os menus de perfil foram atualizados para incluir o link "Receitas Privadas":
- ✅ `/index.html` - Página inicial
- ✅ `/pages/dashboard.html` - Dashboard do utilizador
- ✅ `/pages/explorar-receitas.html`
- ✅ `/pages/grupos.html`
- ✅ `/pages/nova-receita.html`
- ✅ `/pages/perfil.html`
- ✅ `/pages/receita-detalhes.html`

### Dashboard: `/pages/dashboard.html`
**Atualizações:**
- Botão "Ver Receitas Privadas" no acesso rápido
- Card de estatísticas clicável para receitas privadas
- Link "Ver todas" nas receitas privadas recentes

### Página Inicial: `/index.html`
**Atualizações:**
- Novo card de acesso rápido "Receitas Privadas" na seção de acesso rápido

## Como Funciona

### 1. Acesso à Página
O utilizador pode aceder às suas receitas privadas através de:
- Menu de perfil → "Receitas Privadas"
- Dashboard → Botão "Ver Receitas Privadas"
- Dashboard → Card de estatísticas "Receitas Privadas"
- Página inicial → Card "Receitas Privadas" no acesso rápido

### 2. Visualização de Receitas
- Receitas são exibidas em cards com imagem, título e metadados
- Badges visuais indicam o estado:
  - **Rascunho** (cinza): Receita incompleta ou em progresso
  - **Privada** (vermelho): Receita completa mas privada
- Filtros disponíveis:
  - Pesquisa por título ou descrição
  - Filtro por tipo: Todas/Privadas/Rascunhos

### 3. Edição de Receitas
Ao clicar em "Editar":
1. Modal abre com formulário pré-preenchido
2. Todos os campos podem ser alterados:
   - Informações básicas (título, categoria, descrição)
   - Tempos e dificuldade
   - Ingredientes (adicionar/remover dinamicamente)
   - Modo de preparação
   - Imagem
   - Visibilidade (pública/privada)
   - Estado de rascunho
3. Ao guardar, a receita é atualizada via API PUT
4. Lista é recarregada automaticamente

### 4. Eliminação de Receitas
- Confirmação obrigatória antes de eliminar
- Eliminação permanente via API DELETE
- Lista é atualizada automaticamente

### 5. Segurança e Privacidade
- ✅ Apenas o próprio utilizador pode ver as suas receitas privadas
- ✅ API valida a propriedade da receita antes de qualquer operação
- ✅ Token de autenticação obrigatório em todas as operações
- ✅ Receitas privadas não aparecem em pesquisas públicas
- ✅ Outros utilizadores não têm acesso às receitas privadas

## API Endpoints Utilizados

### GET `/api/recipes.php?private=true`
Carregar todas as receitas privadas do utilizador (incluindo rascunhos).
- **Autenticação:** Obrigatória (Bearer token)
- **Retorno:** Array de receitas privadas

### PUT `/api/recipes.php?id={recipeId}`
Atualizar uma receita existente.
- **Autenticação:** Obrigatória (Bearer token)
- **Body:** Dados da receita em JSON
- **Validação:** Verifica se o utilizador é o autor

### DELETE `/api/recipes.php?id={recipeId}`
Eliminar uma receita existente.
- **Autenticação:** Obrigatória (Bearer token)
- **Validação:** Verifica se o utilizador é o autor

## Estilos CSS
Todos os estilos necessários já existem em `/css/styles.css`:
- `.recipe-card` - Cards de receitas
- `.modal` - Modal de edição
- `.form-group` - Grupos de formulário
- `.btn` - Botões de ação

## Testagem Recomendada

1. ✅ Acesso à página via diferentes pontos de entrada
2. ✅ Carregamento de receitas privadas
3. ✅ Filtros e pesquisa funcionam corretamente
4. ✅ Edição de receita atualiza todos os campos
5. ✅ Eliminação de receita com confirmação
6. ✅ Badges de estado aparecem corretamente
7. ✅ Apenas o autor pode editar/eliminar
8. ✅ Tentativa de acesso não autenticado redireciona para login

## Próximos Passos Sugeridos

1. **Notificações Toast**: Substituir `alert()` por notificações toast mais elegantes
2. **Pré-visualização de Imagem**: Adicionar pré-visualização ao inserir URL de imagem
3. **Upload de Imagens**: Implementar upload de ficheiros em vez de apenas URLs
4. **Ordenação**: Adicionar opções de ordenação (data, título, categoria)
5. **Ações em Lote**: Permitir selecionar múltiplas receitas para ações em lote

## Compatibilidade
- ✅ Chrome, Firefox, Safari, Edge (versões modernas)
- ✅ Responsivo para dispositivos móveis
- ✅ Acessível via teclado

---

**Data de Implementação:** 04/02/2026
**Versão:** 1.0
**Status:** ✅ Completo e Funcional
