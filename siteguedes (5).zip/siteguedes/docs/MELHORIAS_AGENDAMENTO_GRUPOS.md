# Melhorias no Sistema de Agendamento de Grupos

## 📅 Data: 9 de Fevereiro de 2026

## 🎯 Resumo das Alterações

Este documento descreve as melhorias implementadas no sistema de agendamento de receitas para grupos, conforme solicitado.

---

## ✅ Correções Implementadas

### 1. **Permissões de Remoção de Agendamentos**

**Problema:** Administradores de grupos não conseguiam remover receitas agendadas por outros membros.

**Solução:** 
- Modificado `api/schedules.php` para verificar se o utilizador é admin do grupo
- Admins podem agora eliminar qualquer agendamento do grupo
- Membros regulares só podem eliminar os seus próprios agendamentos
- Agendamentos pessoais continuam protegidos (só o criador pode eliminar)

**Ficheiros Alterados:**
- `api/schedules.php` (método DELETE e POST legacy)

---

### 2. **Sistema de Atribuição de Responsável**

**Problema:** Não havia forma de atribuir um membro do grupo como responsável por preparar uma receita agendada.

**Solução:** 
- Adicionada coluna `assigned_to` na tabela `schedules`
- Criado endpoint API para atribuir responsáveis
- Interface visual mostra o responsável atribuído com ícone 👤
- Validação para garantir que o responsável é membro do grupo

**Ficheiros Criados:**
- `fixes/add_assigned_to_schedules.sql` - Script SQL para migração
- `fixes/add_assigned_to_schedules.php` - Interface para executar migração

**Ficheiros Alterados:**
- `api/schedules.php` - Novo endpoint 'assign' e suporte no GET/POST
- `js/main-api.js` - Função `assignScheduleResponsible()`

---

### 3. **Modal de Detalhes da Receita Agendada**

**Problema:** Utilizadores não conseguiam ver os detalhes completos das receitas agendadas, incluindo notas.

**Solução:** 
- Criado modal interativo para mostrar detalhes completos
- Receitas agendadas agora são clicáveis
- Modal mostra:
  - Tipo de refeição
  - Nome da receita
  - Data e hora (se disponível)
  - Criador do agendamento
  - Notas/descrição
  - Responsável atual
  - Opção para atribuir/alterar responsável
  - Link direto para ver a receita completa

**Ficheiros Alterados:**
- `pages/grupos.html` - Novo modal e funções JavaScript
- Interface visual melhorada para mostrar responsável nas cards

---

## 📋 Como Usar as Novas Funcionalidades

### Ver Detalhes de uma Receita Agendada:
1. Aceda à página de Grupos
2. Selecione um grupo
3. Clique na tab "Agendamento Semanal"
4. **Clique em qualquer receita agendada** para ver os detalhes

### Atribuir Responsável:
1. Abra os detalhes de uma receita agendada (clique nela)
2. Na secção "Responsável por preparar", selecione um membro do grupo
3. Clique em "Guardar Responsável"
4. O nome do responsável aparecerá na card com ícone 👤

### Remover Receitas Agendadas (Admin):
- Administradores veem um botão "×" em cada receita agendada
- Agora podem remover qualquer agendamento do grupo
- Antes só podiam remover os seus próprios agendamentos

---

## 🔧 Instalação

### Passo 1: Executar Migração da Base de Dados

Aceda a: `http://localhost/siteguedes/fixes/add_assigned_to_schedules.php`

Esta página irá:
- ✅ Verificar se a coluna `assigned_to` existe
- ✅ Adicionar a coluna se necessário
- ✅ Criar chave estrangeira para `users`
- ✅ Criar índice para melhor performance
- ✅ Mostrar a estrutura final da tabela

### Passo 2: Teste as Funcionalidades

1. Aceda à página de Grupos
2. Crie ou selecione um grupo existente
3. Adicione uma receita agendada
4. Clique na receita para ver detalhes
5. Atribua um responsável
6. Teste a remoção (se for admin)

---

## 🔍 Alterações Técnicas Detalhadas

### Base de Dados
```sql
ALTER TABLE schedules 
ADD COLUMN assigned_to INT(11) NULL DEFAULT NULL AFTER notes,
ADD CONSTRAINT fk_schedules_assigned_to 
    FOREIGN KEY (assigned_to) REFERENCES users(id) 
    ON DELETE SET NULL;

CREATE INDEX idx_assigned_to ON schedules(assigned_to);
```

### API - schedules.php

#### Novo Endpoint: Atribuir Responsável
```
POST /api/schedules.php
{
    "action": "assign",
    "sessionToken": "...",
    "scheduleId": 123,
    "assignedTo": 456  // user_id ou null
}
```

#### GET - Alterações
- Agora retorna `assigned_to_name` e `assigned_to_id`
- JOIN adicional com tabela users para obter nome do responsável

#### DELETE - Alterações
- Verificação de permissões melhorada
- Admins de grupo podem eliminar qualquer agendamento
- Mantém proteção para agendamentos pessoais

### Frontend - grupos.html

#### Novas Funções JavaScript:
- `openScheduleDetails(scheduleId)` - Abre modal com detalhes
- `saveAssignedTo(scheduleId)` - Guarda responsável atribuído
- `formatDateFull(date)` - Formata data por extenso

#### Nova API Function - main-api.js:
- `assignScheduleResponsible(scheduleId, assignedTo)` - Chamada API

---

## 🎨 Melhorias Visuais

- ✨ Cards de receitas agendadas agora são clicáveis
- 👤 Ícone visual para responsável atribuído
- 📋 Modal elegante com toda a informação organizada
- 🎯 Botão de remoção reposicionado para não interferir com o clique

---

## ⚠️ Notas Importantes

### Permissões:
- **Admins**: Podem adicionar, editar, remover e atribuir responsáveis a qualquer agendamento do grupo
- **Membros**: Podem ver detalhes e atribuir responsáveis, mas só podem remover seus próprios agendamentos
- **Agendamentos Pessoais**: Continuam privados, só o criador tem acesso total

### Compatibilidade:
- ✅ Mantém compatibilidade com agendamentos existentes
- ✅ Campo `assigned_to` é opcional (NULL por padrão)
- ✅ API suporta tanto formato novo como legacy

### Performance:
- Índice criado em `assigned_to` para queries rápidas
- JOINs otimizados para carregar informações de uma vez

---

## 🐛 Resolução de Problemas

### Admin não consegue remover agendamentos:
- Verifique se o utilizador é realmente admin do grupo
- Confirme que não está em modo de agendamento pessoal
- Limpe o cache do navegador

### Campo assigned_to não aparece:
- Execute o script de migração: `add_assigned_to_schedules.php`
- Verifique logs de erro do PHP/MySQL
- Confirme permissões da base de dados

### Modal não abre:
- Verifique console do navegador para erros JavaScript
- Confirme que `main-api.js` está carregado
- Limpe cache e recarregue a página

---

## 📞 Suporte

Para questões ou problemas:
1. Verifique os logs do navegador (F12 > Console)
2. Verifique logs do servidor PHP
3. Consulte a documentação principal do sistema

---

## 📝 Checklist de Teste

- [ ] Migração da base de dados executada com sucesso
- [ ] Admin consegue remover agendamentos de outros membros
- [ ] Membros conseguem ver detalhes das receitas
- [ ] Modal de detalhes abre corretamente
- [ ] Notas são exibidas quando existem
- [ ] Responsável pode ser atribuído e guardado
- [ ] Responsável aparece visualmente na card
- [ ] Link para receita completa funciona
- [ ] Validações impedem atribuir não-membros

---

**Implementado com sucesso! ✅**
