/* ============================================
   ChefGuedes - Sistema de Administração Completo
   Gestão de utilizadores, receitas, grupos, moderação, etc.
   ============================================ */

// Estado global
let currentSection = 'dashboard';
let currentPage = 1;
let itemsPerPage = 50;
let selectedItems = {
    users: new Set(),
    recipes: new Set(),
    comments: new Set()
};

let allData = {
    users: [],
    recipes: [],
    groups: [],
    comments: [],
    ratings: [],
    infractions: [],
    schedules: [],
    logs: []
};

let charts = {};

// ============================================
// AUTENTICAÇÃO PARA FETCH (token + cookies)
// ============================================
const originalFetch = window.fetch.bind(window);

function getAdminSessionToken() {
    return localStorage.getItem('chefguedes-session-token') || sessionStorage.getItem('chefguedes-session-token') || '';
}

window.fetch = async (url, options = {}) => {
    const token = getAdminSessionToken();
    const method = (options.method || 'GET').toUpperCase();

    const nextOptions = {
        credentials: 'include',
        ...options,
        headers: {
            ...(options.headers || {})
        }
    };

    if (token) {
        nextOptions.headers.Authorization = nextOptions.headers.Authorization || `Bearer ${token}`;
    }

    let finalUrl = url;
    if (typeof url === 'string' && token && method === 'GET') {
        try {
            const parsedUrl = new URL(url, window.location.href);
            if (!parsedUrl.searchParams.has('sessionToken')) {
                parsedUrl.searchParams.set('sessionToken', token);
            }
            finalUrl = parsedUrl.toString();
        } catch (_) {
            finalUrl = url;
        }
    }

    if (token && method !== 'GET' && method !== 'HEAD') {
        const contentType = String(nextOptions.headers['Content-Type'] || nextOptions.headers['content-type'] || '').toLowerCase();
        if (contentType.includes('application/json')) {
            try {
                const bodyObject = typeof nextOptions.body === 'string'
                    ? JSON.parse(nextOptions.body || '{}')
                    : (nextOptions.body || {});

                if (!bodyObject.sessionToken) {
                    bodyObject.sessionToken = token;
                }
                nextOptions.body = JSON.stringify(bodyObject);
            } catch (_) {
                // Ignorar parse inválido e manter body original
            }
        }
    }

    return originalFetch(finalUrl, nextOptions);
};

// ============================================
// API HELPER - Garantir que todas as chamadas incluem credenciais
// ============================================
async function apiCall(url, options = {}) {
    const defaultOptions = {
        credentials: 'include', // Always send cookies
        headers: {
            'Content-Type': 'application/json',
            ...options.headers
        }
    };
    
    return fetch(url, { ...defaultOptions, ...options });
}

// ============================================
// INICIALIZAÇÃO
// ============================================
document.addEventListener('DOMContentLoaded', async () => {
    // Verificar se é admin
    const isAdmin = await checkAdmin();
    if (!isAdmin) {
        showToast('Acesso negado. Apenas administradores podem aceder.', 'error');
        setTimeout(() => window.location.href = '../login.html', 2000);
        return;
    }

    // Inicializar navegação
    initNavigation();
    
    // Carregar dashboard
    await loadDashboard();
    
    // Event listeners
    setupEventListeners();
});

// ============================================
// VERIFICAR SE É ADMIN
// ============================================
async function checkAdmin() {
    try {
        // First check session debug
        const debugResponse = await apiCall('../api/admin.php?action=debug_session');
        const debugData = await debugResponse.json();
        console.log('Session debug:', debugData);
        
        const response = await apiCall('../api/admin.php?action=check_admin');
        
        // Check if response is JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            console.error('Response is not JSON:', await response.text());
            return false;
        }
        
        const data = await response.json();
        console.log('Admin check result:', data);
        return data.success;
    } catch (error) {
        console.error('Erro ao verificar admin:', error);
        return false;
    }
}

// ============================================
// NAVEGAÇÃO
// ============================================
function initNavigation() {
    const tabs = document.querySelectorAll('.admin-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const section = tab.dataset.section;
            switchSection(section);
        });
    });

    // Inner tabs (moderation)
    const innerTabs = document.querySelectorAll('.tab-inner');
    innerTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabName = tab.dataset.tab;
            switchInnerTab(tabName);
        });
    });

    // Notification target type change
    const targetTypeSelect = document.getElementById('notification-target-type');
    if (targetTypeSelect) {
        targetTypeSelect.addEventListener('change', (e) => {
            const targetUserGroup = document.getElementById('target-user-group');
            const targetGroupGroup = document.getElementById('target-group-group');
            
            // Hide both
            targetUserGroup.style.display = 'none';
            targetGroupGroup.style.display = 'none';
            
            // Show appropriate field
            if (e.target.value === 'user') {
                targetUserGroup.style.display = 'block';
            } else if (e.target.value === 'group') {
                targetGroupGroup.style.display = 'block';
            }
        });
    }

    // Notification form
    const notificationForm = document.getElementById('notification-form');
    if (notificationForm) {
        notificationForm.addEventListener('submit', sendNotification);
    }
}

function switchSection(section) {
    currentSection = section;
    
    // Update tabs
    document.querySelectorAll('.admin-tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.section === section);
    });
    
    // Update sections
    document.querySelectorAll('.admin-section').forEach(sec => {
        sec.classList.toggle('active', sec.id === section);
    });
    
    // Load section data
    loadSectionData(section);
}

function switchInnerTab(tabName) {
    // Update inner tabs
    document.querySelectorAll('.tab-inner').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.tab === tabName);
    });
    
    // Update tab contents
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.toggle('active', content.id === `${tabName}-tab`);
    });
    
    // Load tab data
    if (tabName === 'comments') loadComments();
    else if (tabName === 'ratings') loadRatings();
    else if (tabName === 'infractions') loadInfractions();
}

async function loadSectionData(section) {
    switch(section) {
        case 'dashboard':
            await loadDashboard();
            break;
        case 'users':
            await loadUsers();
            break;
        case 'recipes':
            await loadRecipes();
            break;
        case 'groups':
            await loadGroups();
            break;
        case 'moderation':
            await loadComments();
            break;
        case 'schedules':
            await loadSchedules();
            break;
        case 'notifications':
            await loadNotificationHistory();
            break;
        case 'analytics':
            await loadAnalytics();
            break;
        case 'logs':
            await loadLogs();
            break;
        case 'settings':
            await loadSettings();
            break;
    }
}

function refreshCurrentSection() {
    loadSectionData(currentSection);
    showToast('Dados atualizados!', 'success');
}

// ============================================
// DASHBOARD
// ============================================
async function loadDashboard() {
    try {
        // Load stats
        const response = await fetch('../api/admin.php?action=stats');
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('stat-total-users').textContent = data.data.totalUsers || 0;
            document.getElementById('stat-suspended').textContent = data.data.suspendedUsers || 0;
            document.getElementById('stat-banned').textContent = data.data.bannedUsers || 0;
            document.getElementById('stat-total-recipes').textContent = data.data.totalRecipes || 0;
            document.getElementById('stat-public-recipes').textContent = data.data.publicRecipes || 0;
            document.getElementById('stat-today-actions').textContent = data.data.todayActions || 0;
        }
        
        // Load additional stats
        await loadExtendedStats();
        
        // Load recent activity
        await loadRecentActivity();
        
    } catch (error) {
        console.error('Erro ao carregar dashboard:', error);
        showToast('Erro ao carregar estatísticas', 'error');
    }
}

async function loadExtendedStats() {
    try {
        // Groups count
        const groupsResp = await fetch('../api/admin.php?action=get_groups');
        const groupsData = await groupsResp.json();
        if (groupsData.success) {
            document.getElementById('stat-total-groups').textContent = groupsData.data.length || 0;
        }
        
        // Active schedules
        const schedulesResp = await fetch('../api/admin.php?action=get_schedules');
        const schedulesData = await schedulesResp.json();
        if (schedulesData.success) {
            document.getElementById('stat-active-schedules').textContent = schedulesData.data.length || 0;
        }
        
        // Infractions
        const infractionsResp = await fetch('../api/admin.php?action=get_infractions');
        const infractionsData = await infractionsResp.json();
        if (infractionsData.success) {
            document.getElementById('stat-infractions').textContent = infractionsData.data.length || 0;
        }
        
        // Sessions (simulated)
        const sessionsResp = await fetch('../api/admin.php?action=get_sessions');
        const sessionsData = await sessionsResp.json();
        if (sessionsData.success) {
            document.getElementById('stat-active-sessions').textContent = sessionsData.data.length || 0;
        }
        
        // Comments and ratings (simulated for now)
        document.getElementById('stat-comments-today').textContent = '0';
        document.getElementById('stat-ratings-week').textContent = '0';
        
    } catch (error) {
        console.error('Erro ao carregar estatísticas estendidas:', error);
    }
}

async function loadRecentActivity() {
    try {
        const response = await fetch('../api/admin.php?action=logs&limit=10');
        const data = await response.json();
        
        const container = document.getElementById('recent-activity');
        
        if (data.success && data.data.logs && data.data.logs.length > 0) {
            container.innerHTML = data.data.logs.map(log => `
                <div class="activity-item action-${log.action_type}">
                    <div class="activity-icon">${getActionIcon(log.action_type)}</div>
                    <div class="activity-content">
                        <div class="activity-text">
                            <span class="username">${log.admin_username || 'Admin'}</span> 
                            ${translateAction(log.action_type).toLowerCase()} 
                            ${log.target_name ? `<span class="target">${log.target_name}</span>` : ''}
                        </div>
                        <div class="activity-time">${formatDate(log.created_at)}</div>
                    </div>
                </div>
            `).join('');
        } else {
            container.innerHTML = '<div class="empty-state"><p>Sem atividade recente</p></div>';
        }
    } catch (error) {
        console.error('Erro ao carregar atividade:', error);
    }
}

// ============================================
// USERS
// ============================================
async function loadUsers() {
    try {
        const search = document.getElementById('user-search')?.value || '';
        const status = document.getElementById('user-status-filter')?.value || '';
        
        let url = `../api/admin.php?action=users&search=${encodeURIComponent(search)}`;
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            allData.users = data.data;
            
            // Apply status filter
            let filteredUsers = allData.users;
            if (status) {
                filteredUsers = filteredUsers.filter(u => u.status === status);
            }
            
            displayUsers(filteredUsers);
        }
    } catch (error) {
        console.error('Erro ao carregar utilizadores:', error);
        showToast('Erro ao carregar utilizadores', 'error');
    }
}

function displayUsers(users) {
    const tbody = document.getElementById('users-table-body');
    
    if (!users || users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="empty-state">Nenhum utilizador encontrado</td></tr>';
        return;
    }
    
    tbody.innerHTML = users.map(user => `
        <tr>
            <td><input type="checkbox" class="user-checkbox" data-id="${user.id}"></td>
            <td>${user.user_code || user.id}</td>
            <td><strong>${user.username}</strong></td>
            <td>${user.email}</td>
            <td>${formatDate(user.created_at)}</td>
            <td>${getStatusBadge(user.status)}</td>
            <td><span class="badge badge-warning">${user.warning_count || 0}</span></td>
            <td>-</td>
            <td>-</td>
            <td>
                <div class="action-buttons">
                    <button class="btn-action btn-primary btn-sm" onclick="viewUserDetails(${user.id})" title="Ver Detalhes">Ver</button>
                    ${user.status !== 'banned' ? 
                        `<button class="btn-action btn-warning btn-sm" onclick="warnUser(${user.id})" title="Avisar">Avisar</button>
                         <button class="btn-action btn-warning btn-sm" onclick="suspendUser(${user.id})" title="Suspender">Suspender</button>
                         <button class="btn-action btn-danger btn-sm" onclick="banUser(${user.id})" title="Banir">Banir</button>` 
                        : 
                        `<button class="btn-action btn-success btn-sm" onclick="unbanUser(${user.id})" title="Desbanir">Desbanir</button>`
                    }
                    ${user.status === 'suspended' ? 
                        `<button class="btn-action btn-success btn-sm" onclick="unsuspendUser(${user.id})" title="Reativar">Reativar</button>` 
                        : ''
                    }
                    <button class="btn-action btn-danger btn-sm" onclick="deleteUser(${user.id})" title="Apagar">Apagar</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    // Setup checkbox listeners
    document.querySelectorAll('.user-checkbox').forEach(cb => {
        cb.addEventListener('change', updateBulkActions);
    });
    
    // Select all checkbox
    const selectAll = document.getElementById('select-all-users');
    if (selectAll) {
        selectAll.addEventListener('change', (e) => {
            document.querySelectorAll('.user-checkbox').forEach(cb => {
                cb.checked = e.target.checked;
            });
            updateBulkActions();
        });
    }
}

async function viewUserDetails(userId) {
    try {
        const response = await fetch(`../api/admin.php?action=user_details&user_id=${userId}`);
        const data = await response.json();
        
        if (data.success) {
            const user = data.data.user;
            const recipes = data.data.recipes;
            const groups = data.data.groups;
            const infractions = data.data.infractions;
            const activities = data.data.activities;
            
            const content = document.getElementById('user-detail-content');
            content.innerHTML = `
                <div class="detail-grid">
                    <div class="detail-item">
                        <label>Código de Utilizador</label>
                        <value>${user.user_code || user.id}</value>
                    </div>
                    <div class="detail-item">
                        <label>Username</label>
                        <value>${user.username}</value>
                    </div>
                    <div class="detail-item">
                        <label>Email</label>
                        <value>${user.email}</value>
                    </div>
                    <div class="detail-item">
                        <label>Status</label>
                        <value>${getStatusBadge(user.status)}</value>
                    </div>
                    <div class="detail-item">
                        <label>Avisos</label>
                        <value>${user.warning_count || 0}</value>
                    </div>
                    <div class="detail-item">
                        <label>Registo</label>
                        <value>${formatDate(user.created_at)}</value>
                    </div>
                    <div class="detail-item">
                        <label>Receitas</label>
                        <value>${user.recipe_count || 0}</value>
                    </div>
                    <div class="detail-item">
                        <label>Grupos</label>
                        <value>${user.group_count || 0}</value>
                    </div>
                    <div class="detail-item">
                        <label>Comentários</label>
                        <value>${user.comment_count || 0}</value>
                    </div>
                    <div class="detail-item">
                        <label>Avaliações</label>
                        <value>${user.rating_count || 0}</value>
                    </div>
                </div>
                
                <h3 style="margin-top: 30px;">Receitas (últimas 10)</h3>
                ${recipes.length > 0 ? `
                    <table>
                        <tr><th>Título</th><th>Categoria</th><th>Visibilidade</th><th>Data</th></tr>
                        ${recipes.map(r => `
                            <tr>
                                <td>${r.title}</td>
                                <td>${r.category}</td>
                                <td>${getVisibilityBadge(r.visibility)}</td>
                                <td>${formatDate(r.created_at)}</td>
                            </tr>
                        `).join('')}
                    </table>
                ` : '<p>Sem receitas</p>'}
                
                <h3 style="margin-top: 30px;">Grupos</h3>
                ${groups.length > 0 ? `
                    <table>
                        <tr><th>Nome</th><th>Função</th><th>Entrada</th></tr>
                        ${groups.map(g => `
                            <tr>
                                <td>${g.name}</td>
                                <td><span class="badge badge-info">${g.role}</span></td>
                                <td>${formatDate(g.joined_at)}</td>
                            </tr>
                        `).join('')}
                    </table>
                ` : '<p>Sem grupos</p>'}
                
                <h3 style="margin-top: 30px;">Infrações</h3>
                ${infractions.length > 0 ? `
                    <table>
                        <tr><th>Tipo</th><th>Detalhes</th><th>Data</th></tr>
                        ${infractions.map(i => `
                            <tr>
                                <td><span class="badge badge-danger">${i.infraction_type}</span></td>
                                <td>${i.infraction_details}</td>
                                <td>${formatDate(i.created_at)}</td>
                            </tr>
                        `).join('')}
                    </table>
                ` : '<p>Sem infrações</p>'}
            `;
            
            openModal('user-detail-modal');
        }
    } catch (error) {
        console.error('Erro ao carregar detalhes:', error);
        showToast('Erro ao carregar detalhes', 'error');
    }
}

async function warnUser(userId) {
    const reason = prompt('Motivo do aviso:');
    if (!reason) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'warn_user', user_id: userId, reason})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadUsers();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao avisar utilizador', 'error');
    }
}

async function suspendUser(userId) {
    const days = prompt('Dias de suspensão:', '7');
    if (!days) return;
    
    const reason = prompt('Motivo da suspensão:');
    if (!reason) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'suspend_user', user_id: userId, days: parseInt(days), reason})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadUsers();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao suspender utilizador', 'error');
    }
}

async function banUser(userId) {
    const reason = prompt('Motivo do banimento:');
    if (!reason) return;
    
    if (!confirm('Tem a certeza que deseja banir este utilizador?')) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'ban_user', user_id: userId, reason})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadUsers();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao banir utilizador', 'error');
    }
}

async function unbanUser(userId) {
    if (!confirm('Deseja desbanir este utilizador?')) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'unban_user', user_id: userId})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadUsers();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao desbanir utilizador', 'error');
    }
}

async function unsuspendUser(userId) {
    if (!confirm('Deseja remover a suspensão deste utilizador?')) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'unsuspend_user', user_id: userId})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadUsers();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao reativar utilizador', 'error');
    }
}

async function deleteUser(userId) {
    if (!confirm('ATENÇÃO: Apagar este utilizador irá remover todas as suas receitas, comentários e dados. Continuar?')) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'delete_user', user_id: userId})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadUsers();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao apagar utilizador', 'error');
    }
}

// ============================================
// RECIPES
// ============================================
async function loadRecipes() {
    try {
        const search = document.getElementById('recipe-search')?.value || '';
        const visibility = document.getElementById('recipe-visibility-filter')?.value || '';
        const category = document.getElementById('recipe-category-filter')?.value || '';
        
        const response = await fetch(`../api/admin.php?action=recipes&search=${encodeURIComponent(search)}`);
        const data = await response.json();
        
        if (data.success) {
            allData.recipes = data.data;
            
            // Apply visibility and category filters
            let filteredRecipes = allData.recipes;
            if (visibility) {
                filteredRecipes = filteredRecipes.filter(r => r.visibility === visibility);
            }
            if (category) {
                filteredRecipes = filteredRecipes.filter(r => r.category === category);
            }
            
            displayRecipes(filteredRecipes);
            populateCategoryFilter(allData.recipes);
        }
    } catch (error) {
        console.error('Erro ao carregar receitas:', error);
        showToast('Erro ao carregar receitas', 'error');
    }
}

function displayRecipes(recipes) {
    const tbody = document.getElementById('recipes-table-body');
    
    if (!recipes || recipes.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="empty-state">Nenhuma receita encontrada</td></tr>';
        return;
    }
    
    tbody.innerHTML = recipes.map(recipe => `
        <tr>
            <td><input type="checkbox" class="recipe-checkbox" data-id="${recipe.id}"></td>
            <td>${recipe.id}</td>
            <td><img src="${recipe.image || '../images/placeholder.jpg'}" class="recipe-thumb" alt="${recipe.title}"></td>
            <td><strong>${recipe.title}</strong></td>
            <td>${recipe.category}</td>
            <td>${getVisibilityBadge(recipe.visibility)}</td>
            <td>${recipe.average_rating || 0} ★</td>
            <td>${formatDate(recipe.created_at)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn-action btn-primary btn-sm" onclick="changeRecipeVisibility(${recipe.id}, '${recipe.visibility}')" title="Alterar Visibilidade">Visibilidade</button>
                    <button class="btn-action btn-danger btn-sm" onclick="deleteRecipe(${recipe.id})" title="Apagar">Apagar</button>
                </div>
            </td>
        </tr>
    `).join('');
    
    // Setup checkbox listeners
    document.querySelectorAll('.recipe-checkbox').forEach(cb => {
        cb.addEventListener('change', updateBulkActions);
    });
    
    // Select all checkbox
    const selectAll = document.getElementById('select-all-recipes');
    if (selectAll) {
        selectAll.addEventListener('change', (e) => {
            document.querySelectorAll('.recipe-checkbox').forEach(cb => {
                cb.checked = e.target.checked;
            });
            updateBulkActions();
        });
    }
}

function populateCategoryFilter(recipes) {
    const categories = [...new Set(recipes.map(r => r.category))];
    const select = document.getElementById('recipe-category-filter');
    if (select) {
        // Guardar a categoria atualmente selecionada
        const currentValue = select.value;
        
        select.innerHTML = '<option value="">Todas</option>' + 
            categories.map(cat => `<option value="${cat}">${cat}</option>`).join('');
        
        // Restaurar a seleção anterior
        select.value = currentValue;
    }
}

async function changeRecipeVisibility(recipeId, currentVisibility) {
    const visibility = prompt(`Visibilidade atual: ${currentVisibility}\nNova visibilidade (public/private/friends):`, currentVisibility);
    if (!visibility || !['public', 'private', 'friends'].includes(visibility)) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'change_recipe_visibility', recipe_id: recipeId, visibility})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadRecipes();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao alterar visibilidade', 'error');
    }
}

async function deleteRecipe(recipeId) {
    const reason = prompt('Motivo para apagar esta receita:');
    if (!reason) return;
    
    if (!confirm('Tem a certeza que deseja apagar esta receita?')) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'delete_recipe', recipe_id: recipeId, reason})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadRecipes();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao apagar receita', 'error');
    }
}

// ============================================
// GROUPS
// ============================================
async function loadGroups() {
    try {
        const search = document.getElementById('group-search')?.value || '';
        const response = await fetch(`../api/admin.php?action=get_groups&search=${encodeURIComponent(search)}`);
        const data = await response.json();
        
        if (data.success) {
            allData.groups = data.data;
            displayGroups(allData.groups);
        }
    } catch (error) {
        console.error('Erro ao carregar grupos:', error);
        showToast('Erro ao carregar grupos', 'error');
    }
}

function displayGroups(groups) {
    const tbody = document.getElementById('groups-table-body');
    
    if (!groups || groups.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-state">Nenhum grupo encontrado</td></tr>';
        return;
    }
    
    tbody.innerHTML = groups.map(group => `
        <tr>
            <td>${group.id}</td>
            <td><img src="${group.image || '../images/placeholder.jpg'}" class="recipe-thumb" alt="${group.name}"></td>
            <td><strong>${group.name}</strong></td>
            <td>${group.creator_username || 'Desconhecido'}</td>
            <td><span class="badge badge-info">${group.member_count || 0}</span></td>
            <td><span class="badge badge-secondary">${group.schedule_count || 0}</span></td>
            <td>${formatDate(group.created_at)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn-action btn-primary btn-sm" onclick="viewGroupMembers(${group.id})" title="Ver Membros">Membros</button>
                    <button class="btn-action btn-danger btn-sm" onclick="deleteGroup(${group.id})" title="Apagar">Apagar</button>
                </div>
            </td>
        </tr>
    `).join('');
}

async function viewGroupMembers(groupId) {
    try {
        const response = await fetch(`../api/admin.php?action=get_group_members&group_id=${groupId}`);
        const data = await response.json();
        
        if (data.success) {
            const content = document.getElementById('group-members-content');
            content.innerHTML = `
                <table>
                    <thead>
                        <tr><th>Utilizador</th><th>Email</th><th>Função</th><th>Entrada</th><th>Ações</th></tr>
                    </thead>
                    <tbody>
                        ${data.data.map(member => `
                            <tr>
                                <td>${member.username}</td>
                                <td>${member.email}</td>
                                <td><span class="badge badge-${member.role === 'admin' ? 'warning' : 'info'}">${member.role}</span></td>
                                <td>${formatDate(member.joined_at)}</td>
                                <td>
                                    <button class="btn-action btn-danger btn-sm" onclick="removeGroupMember(${groupId}, ${member.user_id})">Remover</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
            openModal('group-members-modal');
        }
    } catch (error) {
        console.error('Erro ao carregar membros:', error);
        showToast('Erro ao carregar membros', 'error');
    }
}

async function removeGroupMember(groupId, userId) {
    if (!confirm('Remover este membro do grupo?')) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'remove_group_member', group_id: groupId, user_id: userId, reason: 'Removido pelo administrador'})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            closeModal('group-members-modal');
            loadGroups();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao remover membro', 'error');
    }
}

async function deleteGroup(groupId) {
    const reason = prompt('Motivo para apagar este grupo:');
    if (!reason) return;
    
    if (!confirm('ATENÇÃO: Apagar este grupo irá remover todos os seus agendamentos e membros. Continuar?')) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'delete_group', group_id: groupId, reason})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadGroups();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao apagar grupo', 'error');
    }
}

// ============================================
// MODERATION - COMMENTS
// ============================================
async function loadComments() {
    try {
        const search = document.getElementById('comment-search')?.value || '';
        const response = await fetch(`../api/admin.php?action=get_comments&search=${encodeURIComponent(search)}`);
        const data = await response.json();
        
        if (data.success) {
            allData.comments = data.data;
            displayComments(allData.comments);
        }
    } catch (error) {
        console.error('Erro ao carregar comentários:', error);
        showToast('Erro ao carregar comentários', 'error');
    }
}

function displayComments(comments) {
    const tbody = document.getElementById('comments-table-body');
    
    if (!comments || comments.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state">Nenhum comentário encontrado</td></tr>';
        return;
    }
    
    tbody.innerHTML = comments.map(comment => `
        <tr>
            <td><input type="checkbox" class="comment-checkbox" data-id="${comment.id}"></td>
            <td>${comment.id}</td>
            <td>${comment.recipe_title || 'Desconhecida'}</td>
            <td>${comment.username || 'Desconhecido'}</td>
            <td>${truncate(comment.comment, 50)}</td>
            <td>${formatDate(comment.created_at)}</td>
            <td>
                <button class="btn-action btn-danger btn-sm" onclick="deleteComment(${comment.id})">Apagar</button>
            </td>
        </tr>
    `).join('');
    
    // Setup checkbox listeners
    document.querySelectorAll('.comment-checkbox').forEach(cb => {
        cb.addEventListener('change', updateBulkActions);
    });
    
    // Select all checkbox
    const selectAll = document.getElementById('select-all-comments');
    if (selectAll) {
        selectAll.addEventListener('change', (e) => {
            document.querySelectorAll('.comment-checkbox').forEach(cb => {
                cb.checked = e.target.checked;
            });
            updateBulkActions();
        });
    }
}

async function deleteComment(commentId) {
    const reason = prompt('Motivo para apagar este comentário:');
    if (!reason) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'delete_comment', comment_id: commentId, reason})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadComments();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao apagar comentário', 'error');
    }
}

// ============================================
// MODERATION - RATINGS
// ============================================
async function loadRatings() {
    try {
        const ratingFilter = document.getElementById('rating-filter')?.value || '';
        let url = '../api/admin.php?action=get_ratings';
        if (ratingFilter) url += `&min_rating=${ratingFilter}&max_rating=${ratingFilter}`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            allData.ratings = data.data;
            displayRatings(allData.ratings);
        }
    } catch (error) {
        console.error('Erro ao carregar avaliações:', error);
        showToast('Erro ao carregar avaliações', 'error');
    }
}

function displayRatings(ratings) {
    const tbody = document.getElementById('ratings-table-body');
    
    if (!ratings || ratings.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state">Nenhuma avaliação encontrada</td></tr>';
        return;
    }
    
    tbody.innerHTML = ratings.map(rating => `
        <tr>
            <td>${rating.id}</td>
            <td>${rating.recipe_title || 'Desconhecida'}</td>
            <td>${rating.username || 'Desconhecido'}</td>
            <td>${'★'.repeat(rating.rating)}</td>
            <td>${formatDate(rating.created_at)}</td>
            <td>
                <button class="btn-action btn-danger btn-sm" onclick="deleteRating(${rating.id})">Apagar</button>
            </td>
        </tr>
    `).join('');
}

async function deleteRating(ratingId) {
    if (!confirm('Apagar esta avaliação?')) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'delete_rating', rating_id: ratingId, reason: 'Removida pelo administrador'})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadRatings();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao apagar avaliação', 'error');
    }
}

// ============================================
// MODERATION - INFRACTIONS
// ============================================
async function loadInfractions() {
    try {
        const typeFilter = document.getElementById('infraction-type-filter')?.value || '';
        let url = '../api/admin.php?action=get_infractions';
        if (typeFilter) url += `&type=${typeFilter}`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            allData.infractions = data.data;
            displayInfractions(allData.infractions);
        }
    } catch (error) {
        console.error('Erro ao carregar infrações:', error);
        showToast('Erro ao carregar infrações', 'error');
    }
}

function displayInfractions(infractions) {
    const tbody = document.getElementById('infractions-table-body');
    
    if (!infractions || infractions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state">Nenhuma infração encontrada</td></tr>';
        return;
    }
    
    tbody.innerHTML = infractions.map(infraction => `
        <tr>
            <td>${infraction.id}</td>
            <td>${infraction.username || 'Desconhecido'}</td>
            <td><span class="badge badge-danger">${infraction.infraction_type}</span></td>
            <td>${truncate(infraction.infraction_details, 50)}</td>
            <td>${formatDate(infraction.created_at)}</td>
            <td>
                <button class="btn-action btn-primary btn-sm" onclick="viewUserDetails(${infraction.user_id})">Ver Utilizador</button>
            </td>
        </tr>
    `).join('');
}

// ============================================
// SCHEDULES
// ============================================
async function loadSchedules() {
    try {
        const typeFilter = document.getElementById('schedule-type-filter')?.value || '';
        const startDate = document.getElementById('schedule-start-date')?.value || '';
        const endDate = document.getElementById('schedule-end-date')?.value || '';
        
        let url = '../api/admin.php?action=get_schedules';
        const params = [];
        if (typeFilter) params.push(`is_personal=${typeFilter}`);
        if (startDate) params.push(`start_date=${startDate}`);
        if (endDate) params.push(`end_date=${endDate}`);
        if (params.length > 0) url += '&' + params.join('&');
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            allData.schedules = data.data;
            displaySchedules(allData.schedules);
        }
    } catch (error) {
        console.error('Erro ao carregar agendamentos:', error);
        showToast('Erro ao carregar agendamentos', 'error');
    }
}

function displaySchedules(schedules) {
    const tbody = document.getElementById('schedules-table-body');
    
    if (!schedules || schedules.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-state">Nenhum agendamento encontrado</td></tr>';
        return;
    }
    
    tbody.innerHTML = schedules.map(schedule => `
        <tr>
            <td>${schedule.id}</td>
            <td><span class="badge badge-${schedule.is_personal ? 'info' : 'warning'}">${schedule.is_personal ? 'Pessoal' : 'Grupo'}</span></td>
            <td>${schedule.is_personal ? (schedule.user_name || '-') : (schedule.group_name || '-')}</td>
            <td>${schedule.recipe_title || schedule.title || '-'}</td>
            <td>${schedule.meal_type || '-'}</td>
            <td>${schedule.scheduled_date || schedule.schedule_date || '-'}</td>
            <td>${schedule.scheduled_time || schedule.meal_time || '-'}</td>
            <td>
                <button class="btn-action btn-danger btn-sm" onclick="deleteSchedule(${schedule.id})">Apagar</button>
            </td>
        </tr>
    `).join('');
}

async function deleteSchedule(scheduleId) {
    if (!confirm('Apagar este agendamento?')) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'delete_schedule', schedule_id: scheduleId, reason: 'Removido pelo administrador'})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadSchedules();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao apagar agendamento', 'error');
    }
}

// ==============Continuation needed...
// ============================================
// NOTIFICATIONS
// ============================================
async function sendNotification(e) {
    e.preventDefault();
    
    const targetType = document.getElementById('notification-target-type').value;
    const targetUser = document.getElementById('notification-target-user')?.value.trim().toUpperCase();
    const targetGroup = document.getElementById('notification-target-group')?.value;
    const title = document.getElementById('notification-title').value;
    const message = document.getElementById('notification-message').value;
    const link = document.getElementById('notification-link').value;
    
    // Determine target_id based on type
    let targetId = null;
    if (targetType === 'user') {
        if (!targetUser || targetUser.length !== 6) {
            showToast('Por favor, insira um código de utilizador válido (6 caracteres)', 'error');
            return;
        }
        targetId = targetUser;
    } else if (targetType === 'group') {
        targetId = targetGroup;
    }
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                action: 'send_notification',
                target_type: targetType,
                target_id: targetId || null,
                title,
                message,
                link: link || null
            })
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            e.target.reset();
            // Hide target fields
            document.getElementById('target-user-group').style.display = 'none';
            document.getElementById('target-group-group').style.display = 'none';
            loadNotificationHistory();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao enviar notificação', 'error');
    }
}

async function loadNotificationHistory() {
    try {
        const response = await fetch('../api/admin.php?action=logs&action_type=send_notification&limit=50');
        const data = await response.json();
        
        if (data.success && data.data.logs) {
            const tbody = document.getElementById('notifications-history-body');
            tbody.innerHTML = data.data.logs.map(log => {
                const details = log.details ? JSON.parse(log.details) : {};
                return `
                    <tr>
                        <td>${formatDate(log.created_at)}</td>
                        <td>${details.title || '-'}</td>
                        <td><span class="badge badge-info">${log.target_type || 'Todos'}</span></td>
                        <td>${details.recipients || 0}</td>
                    </tr>
                `;
            }).join('');
        }
    } catch (error) {
        console.error('Erro ao carregar histórico:', error);
    }
}

// ============================================
// ANALYTICS
// ============================================
async function loadAnalytics() {
    try {
        const response = await fetch('../api/admin.php?action=analytics');
        const data = await response.json();
        
        if (data.success) {
            // User growth chart
            createLineChart('user-growth-chart', 'Novos Utilizadores', data.data.userGrowth);
            
            // Recipes by category chart
            createPieChart('recipes-category-chart', data.data.recipesByCategory);
            
            // Comments timeline
            createLineChart('comments-timeline-chart', 'Comentários', data.data.commentsTimeline);
            
            // Ratings timeline
            createLineChart('ratings-timeline-chart', 'Avaliações', data.data.ratingsTimeline);
            
            // Display active users table
            displayActiveUsers(data.data.activeUsers);
            
            // Display popular recipes table
            displayPopularRecipes(data.data.popularRecipes);
        }
    } catch (error) {
        console.error('Erro ao carregar analytics:', error);
        showToast('Erro ao carregar analytics', 'error');
    }
}

function createLineChart(canvasId, label, data) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;
    
    // Destroy existing chart if it exists
    if (charts[canvasId]) {
        charts[canvasId].destroy();
    }
    
    charts[canvasId] = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(d => formatDate(d.date)),
            datasets: [{
                label: label,
                data: data.map(d => d.count),
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

function createPieChart(canvasId, data) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;
    
    // Destroy existing chart if it exists
    if (charts[canvasId]) {
        charts[canvasId].destroy();
    }
    
    const colors = ['#667eea', '#764ba2', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#ec4899'];
    
    charts[canvasId] = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: data.map(d => d.category),
            datasets: [{
                data: data.map(d => d.count),
                backgroundColor: colors.slice(0, data.length)
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

function displayActiveUsers(users) {
    const tbody = document.getElementById('active-users-body');
    if (!tbody || !users) return;
    
    tbody.innerHTML = users.map((user, index) => `
        <tr>
            <td>${index + 1}</td>
            <td><strong>${user.username}</strong></td>
            <td><span class="badge badge-success">${user.recipe_count}</span></td>
        </tr>
    `).join('');
}

function displayPopularRecipes(recipes) {
    const tbody = document.getElementById('popular-recipes-body');
    if (!tbody || !recipes) return;
    
    tbody.innerHTML = recipes.map((recipe, index) => `
        <tr>
            <td>${index + 1}</td>
            <td><img src="${recipe.image || '../images/placeholder.jpg'}" class="recipe-thumb" alt="${recipe.title}"></td>
            <td><strong>${recipe.title}</strong></td>
            <td><span class="badge badge-warning">${recipe.favorite_count} ♥</span></td>
            <td>${recipe.average_rating || 0} ★</td>
        </tr>
    `).join('');
}

// ============================================
// LOGS
// ============================================
async function loadLogs() {
    try {
        const search = document.getElementById('log-search')?.value || '';
        const actionType = document.getElementById('log-action-filter')?.value || '';
        const startDate = document.getElementById('log-start-date')?.value || '';
        const endDate = document.getElementById('log-end-date')?.value || '';
        
        let url = '../api/admin.php?action=logs&limit=100';
        if (actionType) url += `&action_type=${actionType}`;
        if (startDate) url += `&start_date=${startDate}`;
        if (endDate) url += `&end_date=${endDate}`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success && data.data.logs) {
            allData.logs = data.data.logs;
            displayLogs(allData.logs);
        }
    } catch (error) {
        console.error('Erro ao carregar logs:', error);
        showToast('Erro ao carregar logs', 'error');
    }
}

function displayLogs(logs) {
    const tbody = document.getElementById('logs-table-body');
    
    if (!logs || logs.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state">Nenhum log encontrado</td></tr>';
        return;
    }
    
    tbody.innerHTML = logs.map(log => `
        <tr>
            <td>${formatDateTime(log.created_at)}</td>
            <td><strong>${log.admin_username || 'Admin'}</strong></td>
            <td><span class="badge badge-info">${translateAction(log.action_type)}</span></td>
            <td>${log.target_type || '-'}</td>
            <td>${log.target_name || log.target_id || '-'}</td>
            <td>${truncate(log.reason || '-', 30)}</td>
            <td><small>${log.details ? truncate(log.details, 40) : '-'}</small></td>
        </tr>
    `).join('');
}

// ============================================
// SETTINGS
// ============================================
async function loadSettings() {
    await loadAdmins();
    await loadSessions();
}

async function loadAdmins() {
    try {
        const response = await fetch('../api/admin.php?action=get_admins');
        const data = await response.json();
        
        if (data.success) {
            const container = document.getElementById('admins-list');
            container.innerHTML = `
                <table>
                    <thead>
                        <tr><th>ID</th><th>Username</th><th>Email</th><th>Ações</th></tr>
                    </thead>
                    <tbody>
                        ${data.data.map(admin => `
                            <tr>
                                <td>${admin.id}</td>
                                <td><strong>${admin.username}</strong></td>
                                <td>${admin.email}</td>
                                <td>
                                    <button class="btn-action btn-danger btn-sm" onclick="demoteAdmin(${admin.id})">Remover Admin</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        }
    } catch (error) {
        console.error('Erro ao carregar admins:', error);
    }
}

async function promoteToAdmin() {
    const userId = document.getElementById('promote-user-id').value;
    if (!userId) {
        showToast('Introduza o ID do utilizador', 'error');
        return;
    }
    
    if (!confirm(`Promover utilizador ID ${userId} a administrador?`)) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'promote_to_admin', user_id: parseInt(userId)})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            document.getElementById('promote-user-id').value = '';
            loadAdmins();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao promover utilizador', 'error');
    }
}

async function demoteAdmin(userId) {
    if (!confirm('Remover permissões de administrador deste utilizador?')) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'demote_admin', user_id: userId})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadAdmins();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao remover admin', 'error');
    }
}

async function loadSessions() {
    try {
        const response = await fetch('../api/admin.php?action=get_sessions');
        const data = await response.json();
        
        if (data.success && data.data) {
            const container = document.getElementById('sessions-list');
            container.innerHTML = `
                <p style="color: #666; margin-bottom: 15px;">Total de sessões ativas: <strong>${data.data.length}</strong></p>
                <table>
                    <thead>
                        <tr><th>Utilizador</th><th>IP</th><th>Criada</th><th>Expira</th><th>Ações</th></tr>
                    </thead>
                    <tbody>
                        ${data.data.slice(0, 10).map(session => `
                            <tr>
                                <td>${session.username || 'Desconhecido'}</td>
                                <td><small>${session.ip_address || '-'}</small></td>
                                <td>${formatDate(session.created_at)}</td>
                                <td>${formatDate(session.expires_at)}</td>
                                <td>
                                    <button class="btn-action btn-danger btn-sm" onclick="terminateSession(${session.id})">Terminar</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        }
    } catch (error) {
        console.error('Erro ao carregar sessões:', error);
    }
}

async function terminateSession(sessionId) {
    if (!confirm('Terminar esta sessão?')) return;
    
    try {
        const response = await fetch('../api/admin.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'terminate_session', session_id: sessionId})
        });
        
        const data = await response.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadSessions();
        } else {
            showToast(data.message, 'error');
        }
    } catch (error) {
        showToast('Erro ao terminar sessão', 'error');
    }
}

function updateProfanityList() {
    showToast('Funcionalidade em desenvolvimento', 'warning');
}

// ============================================
// BULK ACTIONS
// ============================================
function updateBulkActions() {
    // Users
    const userCheckboxes = document.querySelectorAll('.user-checkbox:checked');
    const usersBulkActions = document.getElementById('users-bulk-actions');
    const usersCount = document.getElementById('users-selected-count');
    if (usersBulkActions && usersCount) {
        usersCount.textContent = userCheckboxes.length;
        usersBulkActions.classList.toggle('active', userCheckboxes.length > 0);
    }
    
    // Recipes
    const recipeCheckboxes = document.querySelectorAll('.recipe-checkbox:checked');
    const recipesBulkActions = document.getElementById('recipes-bulk-actions');
    const recipesCount = document.getElementById('recipes-selected-count');
    if (recipesBulkActions && recipesCount) {
        recipesCount.textContent = recipeCheckboxes.length;
        recipesBulkActions.classList.toggle('active', recipeCheckboxes.length > 0);
    }
    
    // Comments
    const commentCheckboxes = document.querySelectorAll('.comment-checkbox:checked');
    const commentsBulkActions = document.getElementById('comments-bulk-actions');
    const commentsCount = document.getElementById('comments-selected-count');
    if (commentsBulkActions && commentsCount) {
        commentsCount.textContent = commentCheckboxes.length;
        commentsBulkActions.classList.toggle('active', commentCheckboxes.length > 0);
    }
}

async function bulkAction(action) {
    if (action === 'ban') {
        const userIds = Array.from(document.querySelectorAll('.user-checkbox:checked')).map(cb => parseInt(cb.dataset.id));
        if (userIds.length === 0) return;
        
        const reason = prompt('Motivo do banimento em massa:');
        if (!reason) return;
        
        if (!confirm(`Banir ${userIds.length} utilizadores?`)) return;
        
        try {
            const response = await fetch('../api/admin.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({action: 'bulk_ban_users', user_ids: userIds, reason})
            });
            
            const data = await response.json();
            showToast(data.message, data.success ? 'success' : 'error');
            if (data.success) loadUsers();
        } catch (error) {
            showToast('Erro ao banir utilizadores', 'error');
        }
    } else if (action === 'delete') {
        const userIds = Array.from(document.querySelectorAll('.user-checkbox:checked')).map(cb => parseInt(cb.dataset.id));
        if (userIds.length === 0) return;
        
        if (!confirm(`ATENÇÃO: Apagar ${userIds.length} utilizadores e todo o seu conteúdo?`)) return;
        
        try {
            const response = await fetch('../api/admin.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({action: 'bulk_delete_users', user_ids: userIds, reason: 'Remoção em massa'})
            });
            
            const data = await response.json();
            showToast(data.message, data.success ? 'success' : 'error');
            if (data.success) loadUsers();
        } catch (error) {
            showToast('Erro ao apagar utilizadores', 'error');
        }
    } else if (action === 'deleteRecipes') {
        const recipeIds = Array.from(document.querySelectorAll('.recipe-checkbox:checked')).map(cb => parseInt(cb.dataset.id));
        if (recipeIds.length === 0) return;
        
        const reason = prompt('Motivo da remoção em massa:');
        if (!reason) return;
        
        if (!confirm(`Apagar ${recipeIds.length} receitas?`)) return;
        
        try {
            const response = await fetch('../api/admin.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({action: 'bulk_delete_recipes', recipe_ids: recipeIds, reason})
            });
            
            const data = await response.json();
            showToast(data.message, data.success ? 'success' : 'error');
            if (data.success) loadRecipes();
        } catch (error) {
            showToast('Erro ao apagar receitas', 'error');
        }
    } else if (action === 'deleteComments') {
        const commentIds = Array.from(document.querySelectorAll('.comment-checkbox:checked')).map(cb => parseInt(cb.dataset.id));
        if (commentIds.length === 0) return;
        
        if (!confirm(`Apagar ${commentIds.length} comentários?`)) return;
        
        try {
            const response = await fetch('../api/admin.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({action: 'bulk_delete_comments', comment_ids: commentIds, reason: 'Remoção em massa'})
            });
            
            const data = await response.json();
            showToast(data.message, data.success ? 'success' : 'error');
            if (data.success) loadComments();
        } catch (error) {
            showToast('Erro ao apagar comentários', 'error');
        }
    }
}

// ============================================
// FILTERS & SEARCH
// ============================================
function setupEventListeners() {
    // User search and filters
    const userSearch = document.getElementById('user-search');
    if (userSearch) userSearch.addEventListener('input', debounce(loadUsers, 300));
    
    const userStatusFilter = document.getElementById('user-status-filter');
    if (userStatusFilter) userStatusFilter.addEventListener('change', loadUsers);
    
    // Recipe search and filters
    const recipeSearch = document.getElementById('recipe-search');
    if (recipeSearch) recipeSearch.addEventListener('input', debounce(loadRecipes, 300));
    
    const recipeVisFilter = document.getElementById('recipe-visibility-filter');
    if (recipeVisFilter) recipeVisFilter.addEventListener('change', loadRecipes);
    
    const recipeCatFilter = document.getElementById('recipe-category-filter');
    if (recipeCatFilter) recipeCatFilter.addEventListener('change', loadRecipes);
    
    // Group search
    const groupSearch = document.getElementById('group-search');
    if (groupSearch) groupSearch.addEventListener('input', debounce(loadGroups, 300));
    
    // Comment search
    const commentSearch = document.getElementById('comment-search');
    if (commentSearch) commentSearch.addEventListener('input', debounce(loadComments, 300));
    
    // Rating filter
    const ratingFilter = document.getElementById('rating-filter');
    if (ratingFilter) ratingFilter.addEventListener('change', loadRatings);
    
    // Infraction filter
    const infractionFilter = document.getElementById('infraction-type-filter');
    if (infractionFilter) infractionFilter.addEventListener('change', loadInfractions);
    
    // Schedule filters
    const scheduleTypeFilter = document.getElementById('schedule-type-filter');
    if (scheduleTypeFilter) scheduleTypeFilter.addEventListener('change', loadSchedules);
    
    const scheduleStartDate = document.getElementById('schedule-start-date');
    if (scheduleStartDate) scheduleStartDate.addEventListener('change', loadSchedules);
    
    const scheduleEndDate = document.getElementById('schedule-end-date');
    if (scheduleEndDate) scheduleEndDate.addEventListener('change', loadSchedules);
    
    // Log filters
    const logSearch = document.getElementById('log-search');
    if (logSearch) logSearch.addEventListener('input', debounce(loadLogs, 300));
    
    const logActionFilter = document.getElementById('log-action-filter');
    if (logActionFilter) logActionFilter.addEventListener('change', loadLogs);
    
    const logStartDate = document.getElementById('log-start-date');
    if (logStartDate) logStartDate.addEventListener('change', loadLogs);
    
    const logEndDate = document.getElementById('log-end-date');
    if (logEndDate) logEndDate.addEventListener('change', loadLogs);
}

function clearFilters(section) {
    if (section === 'users') {
        document.getElementById('user-search').value = '';
        document.getElementById('user-status-filter').value = '';
        loadUsers();
    } else if (section === 'recipes') {
        document.getElementById('recipe-search').value = '';
        document.getElementById('recipe-visibility-filter').value = '';
        document.getElementById('recipe-category-filter').value = '';
        loadRecipes();
    } else if (section === 'groups') {
        document.getElementById('group-search').value = '';
        loadGroups();
    } else if (section === 'schedules') {
        document.getElementById('schedule-type-filter').value = '';
        document.getElementById('schedule-start-date').value = '';
        document.getElementById('schedule-end-date').value = '';
        loadSchedules();
    } else if (section === 'logs') {
        document.getElementById('log-search').value = '';
        document.getElementById('log-action-filter').value = '';
        document.getElementById('log-start-date').value = '';
        document.getElementById('log-end-date').value = '';
        loadLogs();
    }
}

// ============================================
// EXPORT
// ============================================
function exportData(type) {
    let data = [];
    let filename = '';
    let headers = [];
    
    if (type === 'users') {
        data = allData.users;
        filename = 'users.csv';
        headers = ['ID', 'Username', 'Email', 'Status', 'Warnings', 'Created'];
        data = data.map(u => [u.id, u.username, u.email, u.status, u.warning_count || 0, u.created_at]);
    } else if (type === 'recipes') {
        data = allData.recipes;
        filename = 'recipes.csv';
        headers = ['ID', 'Title', 'Author', 'Category', 'Visibility', 'Created'];
        data = data.map(r => [r.id, r.title, r.author_username, r.category, r.visibility, r.created_at]);
    } else if (type === 'logs') {
        data = allData.logs;
        filename = 'admin_logs.csv';
        headers = ['Date', 'Admin', 'Action', 'Target Type', 'Target', 'Reason'];
        data = data.map(l => [l.created_at, l.admin_username, l.action_type, l.target_type, l.target_name || l.target_id, l.reason || '']);
    }
    
    downloadCSV(headers, data, filename);
}

function downloadCSV(headers, data, filename) {
    const csv = [headers, ...data].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
    const blob = new Blob(['\ufeff' + csv], {type: 'text/csv;charset=utf-8;'});
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.click();
}

// ============================================
// MODALS
// ============================================
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add('active');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('active');
}

// Close modal on outside click
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
    }
});

// ============================================
// UTILITY FUNCTIONS
// ============================================
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 4000);
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-PT');
}

function formatDateTime(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleString('pt-PT');
}

function truncate(text, length) {
    if (!text) return '';
    return text.length > length ? text.substring(0, length) + '...' : text;
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function getStatusBadge(status) {
    const badges = {
        'active': '<span class="badge badge-success">Ativo</span>',
        'suspended': '<span class="badge badge-warning">Suspenso</span>',
        'banned': '<span class="badge badge-danger">Banido</span>'
    };
    return badges[status] || '<span class="badge badge-secondary">Desconhecido</span>';
}

function getVisibilityBadge(visibility) {
    const badges = {
        'public': '<span class="badge badge-success">Público</span>',
        'private': '<span class="badge badge-danger">Privado</span>',
        'friends': '<span class="badge badge-info">Amigos</span>'
    };
    return badges[visibility] || '<span class="badge badge-secondary">-</span>';
}

function translateAction(action) {
    const translations = {
        'ban': 'Banir',
        'unban': 'Desbanir',
        'suspend': 'Suspender',
        'unsuspend': 'Remover Suspensão',
        'warn': 'Avisar',
        'delete_user': 'Apagar Utilizador',
        'delete_recipe': 'Apagar Receita',
        'delete_comment': 'Apagar Comentário',
        'delete_rating': 'Apagar Avaliação',
        'delete_group': 'Apagar Grupo',
        'send_notification': 'Enviar Notificação',
        'promote_to_admin': 'Promover a Admin',
        'demote_admin': 'Remover Admin'
    };
    return translations[action] || action;
}

function getActionIcon(action) {
    const icons = {
        'ban': '✕',
        'unban': '✓',
        'suspend': '⏸',
        'unsuspend': '▶',
        'warn': '!',
        'delete_user': '⊗',
        'delete_recipe': '⊗',
        'delete_comment': '⊗',
        'delete_rating': '★',
        'delete_group': '⊗',
        'send_notification': '◉',
        'promote_to_admin': '♔',
        'demote_admin': '↓'
    };
    return icons[action] || 'i';
}

function logout() {
    if (confirm('Sair do painel de administração?')) {
        window.location.href = '../api/users.php?action=logout';
    }
}
