// Receitas Atribuídas - Variáveis Globais
let assignedRecipes = [];
let filteredRecipes = [];
let currentFilter = 'all';

// Inicialização
document.addEventListener('DOMContentLoaded', async function() {
    const isAuthed = await requireAuth();
    if (!isAuthed) {
        return;
    }

    loadAssignedRecipes();
    applyFilter('pending');
});

// Carregar receitas atribuídas pelos grupos
async function loadAssignedRecipes() {
    try {
        const token = getSessionToken();
        if (!token) {
            showError('Sessão expirada.');
            window.location.href = '../login.html';
            return;
        }

        const today = new Date();
        const startDate = new Date(today);
        const endDate = new Date(today);
        startDate.setDate(startDate.getDate() - 30);
        endDate.setDate(endDate.getDate() + 90);

        const response = await fetch(
            `../api/schedules.php?is_personal=1&start_date=${formatDateForDB(startDate)}&end_date=${formatDateForDB(endDate)}`,
            {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const result = await response.json();

        if (result.success) {
            const allSchedules = Array.isArray(result.data) ? result.data : [];
            assignedRecipes = allSchedules.filter(schedule => schedule.group_id);
            applyFilter('all');
        } else {
            console.error('Erro ao carregar receitas atribuídas:', result.message);
            showEmptyState();
        }
    } catch (error) {
        console.error('Erro ao carregar receitas atribuídas:', error);
        showEmptyState();
    }
}

// Filtrar receitas (chamado pelos botões HTML)
function filterRecipes(filterType) {
    // Atualizar abas ativas
    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    event.target.classList.add('active');
    
    applyFilter(filterType);
}

// Aplicar filtro (função interna)
function applyFilter(filterType) {
    currentFilter = filterType;

    if (filterType === 'pending') {
        filteredRecipes = Array.isArray(assignedRecipes) ? assignedRecipes.filter(r => !r.completed) : [];
    } else if (filterType === 'completed') {
        filteredRecipes = Array.isArray(assignedRecipes) ? assignedRecipes.filter(r => r.completed) : [];
    }

    renderAssignedRecipes();
    updateStats();
}

// Renderizar lista de receitas atribuídas
function renderAssignedRecipes() {
    const container = document.getElementById('assignedRecipesList');
    
    if (!Array.isArray(filteredRecipes) || filteredRecipes.length === 0) {
        showEmptyState();
        return;
    }

    container.innerHTML = '';

    filteredRecipes.forEach(recipe => {
        const recipeCard = document.createElement('div');
        recipeCard.className = `recipe-card ${recipe.completed ? 'completed' : ''}`;
        
        const mealTypeLabel = getMealTypeLabel(recipe.meal_type);
        const scheduleDate = new Date(recipe.schedule_date);
        const formattedDate = formatDateDisplay(scheduleDate);

        recipeCard.innerHTML = `
            <div class="recipe-info">
                <div class="recipe-name">${recipe.recipe_name || recipe.title || 'Receita'}</div>
                <div class="recipe-group">👥 ${recipe.group_name || 'Grupo'}</div>
                <div class="recipe-details">
                    <div class="recipe-detail-item">
                        <span>📅 ${formattedDate}</span>
                    </div>
                    <div class="recipe-detail-item">
                        <span>🍽️ ${mealTypeLabel}</span>
                    </div>
                    ${recipe.meal_time ? `
                        <div class="recipe-detail-item">
                            <span>🕐 ${recipe.meal_time}</span>
                        </div>
                    ` : ''}
                </div>
                <div class="recipe-assigned-by">Atribuído por ${recipe.created_by_name || 'Admin'}</div>
                ${recipe.notes ? `<div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #eee; font-size: 0.9rem; color: var(--text-secondary);">📝 ${recipe.notes}</div>` : ''}
            </div>
            <div class="recipe-actions">
                <button class="btn-mark-complete ${recipe.completed ? 'completed' : ''}" 
                        onclick="markAsCompleted(${recipe.id}, ${recipe.completed ? 'true' : 'false'})"
                        ${recipe.completed ? 'disabled' : ''}>
                    ${recipe.completed ? '✓ Concluída' : 'Marcar Concluída'}
                </button>
            </div>
        `;

        container.appendChild(recipeCard);
    });
}

// Marcar receita como concluída
async function markAsCompleted(recipeId, isAlreadyCompleted) {
    if (isAlreadyCompleted) {
        return;
    }

    try {
        const token = getSessionToken();
        if (!token) {
            showError('Sessão expirada.');
            window.location.href = '../login.html';
            return;
        }

        const response = await fetch(`../api/schedules.php?id=${recipeId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                completed: 1
            })
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Receita marcada como concluída!');
            loadAssignedRecipes();
            
            // Depois de recarregar, ir para a aba "Concluídas"
            setTimeout(() => {
                document.querySelectorAll('.filter-tab').forEach(tab => {
                    tab.classList.remove('active');
                });
                const completedTab = Array.from(document.querySelectorAll('.filter-tab')).find(tab => 
                    tab.textContent.includes('Concluídas')
                );
                if (completedTab) {
                    completedTab.classList.add('active');
                }
                applyFilter('completed');
            }, 300);
        } else {
            showError(result.message || 'Erro ao marcar como concluída');
        }
    } catch (error) {
        console.error('Erro:', error);
        showError('Erro ao comunicar com o servidor');
    }
}

// Mostrar estado vazio
function showEmptyState() {
    const container = document.getElementById('assignedRecipesList');
    container.innerHTML = `
        <div class="empty-state">
            <div class="empty-state-icon">📋</div>
            <div class="empty-state-text">Ainda não tem receitas atribuídas</div>
            <div class="empty-state-subtext">Quando o seu grupo atribuir receitas, elas aparecerão aqui</div>
        </div>
    `;
}

// Atualizar estatísticas
function updateStats() {
    const recipesArray = Array.isArray(assignedRecipes) ? assignedRecipes : [];
    const total = recipesArray.length;
    const completed = recipesArray.filter(r => r.completed).length;
    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;

    document.getElementById('totalAssigned').textContent = total;
    document.getElementById('totalCompleted').textContent = completed;
    document.getElementById('completionRate').textContent = completionRate + '%';
}

// Funções auxiliares
function getMealTypeLabel(mealType) {
    const labels = {
        'breakfast': 'Pequeno-Almoço',
        'lunch': 'Almoço',
        'snack': 'Lanche',
        'dinner': 'Jantar'
    };
    return labels[mealType] || mealType;
}

function formatDateDisplay(date) {
    const options = { weekday: 'short', year: 'numeric', month: 'long', day: 'numeric' };
    return date.toLocaleDateString('pt-PT', options);
}

function formatDateForDB(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Mensagens
function showSuccess(message) {
    alert(message);
}

function showError(message) {
    alert('Erro: ' + message);
}
