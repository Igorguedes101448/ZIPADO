// Agendamento Pessoal - Variáveis Globais
let currentWeekStart = null;
let personalSchedules = [];
let userRecipes = [];
let currentEditingMeal = null;

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    // Verificar autenticação
    if (!checkAuth()) {
        window.location.href = '../login.html';
        return;
    }

    initializeWeek();
    loadUserRecipes();
    loadPersonalSchedules();
});

// Inicializar semana atual
function initializeWeek() {
    const today = new Date();
    // Encontrar segunda-feira desta semana
    const dayOfWeek = today.getDay();
    const diff = dayOfWeek === 0 ? -6 : 1 - dayOfWeek; // Se domingo (0), volta 6 dias
    currentWeekStart = new Date(today);
    currentWeekStart.setDate(today.getDate() + diff);
    currentWeekStart.setHours(0, 0, 0, 0);
    
    renderWeekCalendar();
}

// Renderizar calendário semanal
function renderWeekCalendar() {
    const calendar = document.getElementById('weekCalendar');
    calendar.innerHTML = '';
    
    const weekDays = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    const mealTypes = [
        { key: 'breakfast', label: 'Pequeno-Almoço' },
        { key: 'lunch', label: 'Almoço' },
        { key: 'snack', label: 'Lanche' },
        { key: 'dinner', label: 'Jantar' }
    ];

    // Atualizar título da semana
    const weekEnd = new Date(currentWeekStart);
    weekEnd.setDate(weekEnd.getDate() + 6);
    document.getElementById('weekTitle').textContent = 
        `${formatDate(currentWeekStart)} - ${formatDate(weekEnd)}`;

    // Criar cards para cada dia da semana
    for (let i = 0; i < 7; i++) {
        const date = new Date(currentWeekStart);
        date.setDate(date.getDate() + i);
        const dayIndex = date.getDay();
        
        const dayCard = document.createElement('div');
        dayCard.className = 'day-card';
        
        // Cabeçalho do dia
        dayCard.innerHTML = `
            <div class="day-header">
                <div class="day-name">${weekDays[dayIndex]}</div>
                <div class="day-date">${formatDateShort(date)}</div>
            </div>
        `;

        // Adicionar slots de refeições
        mealTypes.forEach(mealType => {
            const meal = findMealForDateTime(date, mealType.key);
            const mealSlot = createMealSlot(date, mealType, meal);
            dayCard.appendChild(mealSlot);
        });

        calendar.appendChild(dayCard);
    }

    updateStats();
}

// Criar slot de refeição
function createMealSlot(date, mealType, meal) {
    const slot = document.createElement('div');
    slot.className = meal ? 'meal-slot filled' : 'meal-slot';
    
    if (meal) {
        const recipe = userRecipes.find(r => r.id == meal.recipe_id);
        slot.innerHTML = `
            <div class="meal-type">${mealType.label}</div>
            <div class="meal-recipe">${recipe ? recipe.name : 'Receita não encontrada'}</div>
            <div class="meal-time">${meal.meal_time || 'Sem hora'}</div>
            ${meal.notes ? `<div class="meal-time">${meal.notes}</div>` : ''}
            <div class="meal-actions">
                <button class="btn-edit-meal" onclick="editMeal(${meal.id})">Editar</button>
                <button class="btn-delete-meal" onclick="deleteMeal(${meal.id})">Remover</button>
            </div>
        `;
    } else {
        slot.innerHTML = `
            <div class="meal-type">${mealType.label}</div>
            <div class="meal-empty">Clique para adicionar</div>
        `;
    }
    
    slot.onclick = () => {
        if (meal) {
            editMeal(meal.id);
        } else {
            openAddMealModal(date, mealType.key);
        }
    };
    
    return slot;
}

// Encontrar refeição para data/tipo específico
function findMealForDateTime(date, mealType) {
    const dateStr = formatDateForDB(date);
    return personalSchedules.find(s => 
        s.schedule_date === dateStr && s.meal_type === mealType
    );
}

// Abrir modal para adicionar refeição
function openAddMealModal(date, mealType = '') {
    currentEditingMeal = null;
    document.getElementById('modalMealTitle').textContent = 'Adicionar Refeição';
    document.getElementById('mealId').value = '';
    document.getElementById('mealDate').value = formatDateForDB(date);
    document.getElementById('mealType').value = mealType;
    document.getElementById('mealRecipe').value = '';
    document.getElementById('mealTime').value = getDefaultTimeForMealType(mealType);
    document.getElementById('mealNotes').value = '';
    
    openModal('modalMeal');
}

// Editar refeição
function editMeal(mealId) {
    const meal = personalSchedules.find(s => s.id == mealId);
    if (!meal) return;
    
    currentEditingMeal = meal;
    document.getElementById('modalMealTitle').textContent = 'Editar Refeição';
    document.getElementById('mealId').value = meal.id;
    document.getElementById('mealDate').value = meal.schedule_date;
    document.getElementById('mealType').value = meal.meal_type;
    document.getElementById('mealRecipe').value = meal.recipe_id;
    document.getElementById('mealTime').value = meal.meal_time || '';
    document.getElementById('mealNotes').value = meal.notes || '';
    
    openModal('modalMeal');
}

// Guardar refeição
async function saveMeal(event) {
    event.preventDefault();
    
    const mealId = document.getElementById('mealId').value;
    const mealData = {
        schedule_date: document.getElementById('mealDate').value,
        meal_type: document.getElementById('mealType').value,
        recipe_id: document.getElementById('mealRecipe').value,
        meal_time: document.getElementById('mealTime').value,
        notes: document.getElementById('mealNotes').value,
        is_personal: true
    };

    try {
        const token = localStorage.getItem('token');
        const url = mealId 
            ? `../api/schedules.php?id=${mealId}`
            : '../api/schedules.php';
        
        const method = mealId ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(mealData)
        });

        const result = await response.json();

        if (result.success) {
            showSuccess(mealId ? 'Refeição atualizada!' : 'Refeição adicionada!');
            closeMealModal();
            loadPersonalSchedules();
        } else {
            showError(result.message || 'Erro ao guardar refeição');
        }
    } catch (error) {
        console.error('Erro ao guardar refeição:', error);
        showError('Erro ao comunicar com o servidor');
    }
}

// Remover refeição
async function deleteMeal(mealId) {
    if (!confirm('Tem certeza que deseja remover esta refeição do seu planeamento?')) {
        return;
    }

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`../api/schedules.php?id=${mealId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const result = await response.json();

        if (result.success) {
            showSuccess('Refeição removida!');
            loadPersonalSchedules();
        } else {
            showError(result.message || 'Erro ao remover refeição');
        }
    } catch (error) {
        console.error('Erro ao remover refeição:', error);
        showError('Erro ao comunicar com o servidor');
    }
}

// Carregar receitas do utilizador
async function loadUserRecipes() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('../api/recipes.php?my_recipes=1', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const result = await response.json();

        if (result.success) {
            userRecipes = result.data || [];
            populateRecipeSelect();
        } else {
            console.error('Erro ao carregar receitas:', result.message);
        }
    } catch (error) {
        console.error('Erro ao carregar receitas:', error);
    }
}

// Preencher select de receitas
function populateRecipeSelect() {
    const select = document.getElementById('mealRecipe');
    select.innerHTML = '<option value="">Selecione uma receita...</option>';
    
    if (userRecipes.length === 0) {
        select.innerHTML += '<option value="" disabled>Você ainda não tem receitas. Crie uma primeiro!</option>';
    } else {
        userRecipes.forEach(recipe => {
            const option = document.createElement('option');
            option.value = recipe.id;
            option.textContent = recipe.name;
            select.appendChild(option);
        });
    }
}

// Carregar agendamentos pessoais
async function loadPersonalSchedules() {
    try {
        const token = localStorage.getItem('token');
        const startDate = formatDateForDB(currentWeekStart);
        const endDate = new Date(currentWeekStart);
        endDate.setDate(endDate.getDate() + 6);
        const endDateStr = formatDateForDB(endDate);

        const response = await fetch(
            `../api/schedules.php?is_personal=1&start_date=${startDate}&end_date=${endDateStr}`, 
            {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }
        );

        const result = await response.json();

        if (result.success) {
            personalSchedules = result.data || [];
            renderWeekCalendar();
        } else {
            console.error('Erro ao carregar agendamentos:', result.message);
        }
    } catch (error) {
        console.error('Erro ao carregar agendamentos:', error);
    }
}

// Navegação de semanas
function previousWeek() {
    currentWeekStart.setDate(currentWeekStart.getDate() - 7);
    loadPersonalSchedules();
}

function nextWeek() {
    currentWeekStart.setDate(currentWeekStart.getDate() + 7);
    loadPersonalSchedules();
}

// Atualizar estatísticas
function updateStats() {
    const totalMeals = personalSchedules.length;
    const uniqueRecipes = new Set(personalSchedules.map(s => s.recipe_id)).size;
    const totalSlots = 7 * 4; // 7 dias × 4 refeições
    const completionRate = Math.round((totalMeals / totalSlots) * 100);

    document.getElementById('totalMeals').textContent = totalMeals;
    document.getElementById('totalRecipes').textContent = uniqueRecipes;
    document.getElementById('completionRate').textContent = completionRate + '%';
}

// Funções auxiliares
function formatDate(date) {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
}

function formatDateShort(date) {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    return `${day}/${month}`;
}

function formatDateForDB(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}

function getDefaultTimeForMealType(mealType) {
    const defaults = {
        'breakfast': '08:00',
        'lunch': '13:00',
        'snack': '17:00',
        'dinner': '20:00'
    };
    return defaults[mealType] || '';
}

// Modal functions
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
}

function closeMealModal() {
    document.getElementById('modalMeal').style.display = 'none';
    currentEditingMeal = null;
}

// Mensagens
function showSuccess(message) {
    alert(message); // Pode ser substituído por toast/notification mais elegante
}

function showError(message) {
    alert('Erro: ' + message);
}

// Fechar modal ao clicar fora
window.onclick = function(event) {
    const modal = document.getElementById('modalMeal');
    if (event.target === modal) {
        closeMealModal();
    }
}
