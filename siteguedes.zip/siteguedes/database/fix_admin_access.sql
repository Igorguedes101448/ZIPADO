-- ============================================
-- ChefGuedes - Fix de acesso ao painel admin
-- Seguro para executar mais de uma vez (idempotente)
-- ============================================

USE `siteguedes`;

-- 1) Adicionar coluna `suspended_until` se não existir
SET @dbname = DATABASE();
SET @tablename = 'users';
SET @columnname = 'suspended_until';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE (table_name = @tablename) AND (table_schema = @dbname) AND (column_name = @columnname)) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN `", @columnname, "` DATETIME NULL DEFAULT NULL AFTER `banned_reason`")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 2) Adicionar coluna `warning_count` se não existir
SET @columnname = 'warning_count';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE (table_name = @tablename) AND (table_schema = @dbname) AND (column_name = @columnname)) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN `", @columnname, "` INT NOT NULL DEFAULT 0 AFTER `suspended_until`")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 3) Adicionar índice para `suspended_until` se não existir
SET @indexname = 'idx_suspended_until';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE table_name = @tablename AND table_schema = @dbname AND index_name = @indexname) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD INDEX `", @indexname, "` (`suspended_until`)")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 4) Adicionar índice para `warning_count` se não existir
SET @indexname = 'idx_warning_count';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE table_name = @tablename AND table_schema = @dbname AND index_name = @indexname) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD INDEX `", @indexname, "` (`warning_count`)")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 3) Garantir que utilizadores admin conhecidos têm permissão
UPDATE `users`
SET `is_admin` = 1
WHERE `username` IN ('teste123', 'teste', 'admin')
   OR `email` IN ('teste123@gmail.com', 'admin@siteguedes.com');

-- 4) (Opcional) Verificar resultado final
SELECT id, username, email, is_admin, banned, warning_count, suspended_until
FROM users
WHERE username IN ('teste123', 'teste', 'admin')
   OR email IN ('teste123@gmail.com', 'admin@siteguedes.com');
