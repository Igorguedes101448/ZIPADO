-- ============================================
-- Migration: Group Recipe Assignments
-- Purpose: Ensure schedules table properly supports group recipe assignments to members
-- Date: 2026-02-11
-- ============================================

-- Check if is_personal column exists, if not add it
SET @column_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'schedules' 
    AND COLUMN_NAME = 'is_personal'
);

SET @sql = IF(@column_exists = 0,
    'ALTER TABLE schedules ADD COLUMN is_personal TINYINT(1) DEFAULT 0 AFTER assigned_to',
    'SELECT "Column is_personal already exists" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check if schedule_date column exists (for compatibility with personal schedules)
SET @column_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'schedules' 
    AND COLUMN_NAME = 'schedule_date'
);

SET @sql = IF(@column_exists = 0,
    'ALTER TABLE schedules ADD COLUMN schedule_date DATE NULL AFTER scheduled_date',
    'SELECT "Column schedule_date already exists" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check if meal_time column exists (for compatibility with personal schedules)
SET @column_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'schedules' 
    AND COLUMN_NAME = 'meal_time'
);

SET @sql = IF(@column_exists = 0,
    'ALTER TABLE schedules ADD COLUMN meal_time TIME NULL AFTER scheduled_time',
    'SELECT "Column meal_time already exists" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Sync schedule_date from scheduled_date where needed
UPDATE schedules 
SET schedule_date = scheduled_date 
WHERE schedule_date IS NULL AND scheduled_date IS NOT NULL;

-- Sync meal_time from scheduled_time where needed
UPDATE schedules 
SET meal_time = scheduled_time 
WHERE meal_time IS NULL AND scheduled_time IS NOT NULL;

-- Add index for efficient querying of assigned schedules
SET @index_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.STATISTICS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'schedules' 
    AND INDEX_NAME = 'idx_assigned_schedules'
);

SET @sql = IF(@index_exists = 0,
    'CREATE INDEX idx_assigned_schedules ON schedules(assigned_to, scheduled_date)',
    'SELECT "Index idx_assigned_schedules already exists" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================
-- NOTES:
-- ============================================
-- The schedules table now supports:
--   - scheduled_date: For group schedules (legacy format)
--   - schedule_date: For personal schedules (new format) - will be synced with scheduled_date
--   - assigned_to: User ID to whom the recipe is assigned
--   - is_personal: Flag to distinguish personal vs group schedules
--   - group_id: NULL for personal schedules, set for group schedules

-- Group-assigned schedules work as follows:
--   1. Group admin creates schedule with group_id set
--   2. Admin assigns to member by setting assigned_to = member_user_id
--   3. When fetching personal schedules, include:
--      - Personal schedules: group_id IS NULL AND user_id = current_user
--      - Assigned group schedules: assigned_to = current_user
-- ============================================

SELECT 'Migration completed successfully!' AS message;
