# 🚀 Quick Start Guide - New Admin Panel

## Step 1: Install Database Table (2 minutes)

### Option A: Using phpMyAdmin
1. Open phpMyAdmin in your browser
2. Select database `siteguedes`
3. Click the **SQL** tab
4. Open the file `c:\wamp64\www\siteguedes\database\init_admin_actions.sql`
5. Copy the entire contents
6. Paste into phpMyAdmin SQL window
7. Click **Go**
8. You should see: "Query OK" message

### Option B: Using Command Line
```bash
# Navigate to your MySQL bin directory
cd C:\wamp64\bin\mysql\mysql8.x.x\bin

# Run the migration
mysql.exe -u root -p siteguedes < "C:\wamp64\www\siteguedes\database\init_admin_actions.sql"

# Enter your MySQL password when prompted
```

### Verify It Worked
Run this query in phpMyAdmin:
```sql
SELECT COUNT(*) FROM admin_actions;
```
If it returns a number (even 0), it worked!

---

## Step 2: Access the New Admin Panel (30 seconds)

1. Open your browser
2. Navigate to: `http://localhost/siteguedes/pages/admin-new.html`
3. You should see the new admin panel with 10 tabs

**Note:** If you see a login screen, make sure you're logged in as an admin user.

---

## Step 3: Test Basic Functionality (5 minutes)

### Dashboard
- ✅ Look at the 12 stat cards
- ✅ Check if numbers appear correctly
- ✅ Scroll down to see recent activity

### Users Section
- ✅ Click the "👥 Utilizadores" tab
- ✅ See your user list
- ✅ Try searching for a username
- ✅ Click the eye icon (👁️) on a user to see details

### Recipes Section
- ✅ Click the "🍳 Receitas" tab
- ✅ See your recipes
- ✅ Try the visibility filter

### Groups Section
- ✅ Click the "👨‍👩‍👧‍👦 Grupos" tab
- ✅ See all groups
- ✅ Click "👥" to view group members

### That's it! You're all set up! 🎉

---

## Common Issues & Fixes

### ❌ "Table 'admin_actions' doesn't exist"
**Fix:** Run the SQL migration (Step 1)

### ❌ "Acesso negado" (Access Denied)
**Fix:** Make sure your user has `is_admin = 1` in the database
```sql
UPDATE users SET is_admin = 1 WHERE id = YOUR_USER_ID;
```

### ❌ Stats show "0" for everything
**Fix:** This is normal if you just installed. Create some test data:
- Create a user
- Create a recipe
- Create a group
Then refresh the dashboard

### ❌ "Failed to load data"
**Fix:** Check that your `api/admin.php` file was updated correctly

### ❌ Charts don't show
**Fix:** Make sure you have an internet connection (Chart.js loads from CDN)

---

## Where Are The Files?

| File | Location | Purpose |
|------|----------|---------|
| SQL Migration | `database/init_admin_actions.sql` | Creates admin_actions table |
| Admin HTML | `pages/admin-new.html` | New admin interface |
| Admin JavaScript | `js/admin-new.js` | All admin functionality |
| Admin API | `api/admin.php` | Backend endpoints (already updated) |
| Documentation | `docs/ADMIN_OVERHAUL.md` | Complete documentation |

---

## Next Steps

Once everything works:

### Replace Old Admin (Optional)
If you want to make the new admin the default:

1. **Backup old files first!**
   ```
   Copy pages/admin.html to pages/admin-old.html
   Copy js/admin.js to js/admin-old.js
   ```

2. **Replace with new versions:**
   ```
   Rename pages/admin-new.html to pages/admin.html
   Rename js/admin-new.js to js/admin.js
   ```

3. **Update links:**
   - Find any links to `admin.html` in your code
   - They will now point to the new version automatically

---

## Quick Actions Reference

### Ban a User
1. Go to Users tab
2. Find the user
3. Click the 🚫 button
4. Enter reason
5. Confirm

### Delete a Recipe
1. Go to Recipes tab
2. Find the recipe
3. Click the 🗑️ button
4. Enter reason
5. Confirm

### Send Notification to All Users
1. Go to Notifications tab
2. Keep "Todos os Utilizadores" selected
3. Enter title and message
4. Click "Enviar Notificação"

### View User Details
1. Go to Users tab
2. Click 👁️ on any user
3. See their recipes, groups, infractions, etc.

### Promote User to Admin
1. Go to Settings tab (⚙️)
2. Enter user ID in the field
3. Click "Promover a Admin"

---

## Performance Tips

- Use search instead of scrolling through long lists
- Use filters to narrow down data
- Export to CSV for offline analysis
- Refresh button (🔄) updates current section only

---

## Support

Need help? Check:
1. **Full Documentation:** `docs/ADMIN_OVERHAUL.md`
2. **Browser Console:** Press F12 to see errors
3. **PHP Errors:** Check `C:\wamp64\logs\php_error.log`

---

**You're now ready to manage your entire platform! 🎉**

Happy administrating! 🛡️
