-- Migração para suportar agendamentos pessoais
-- Adiciona colunas necessárias à tabela schedules

-- Adicionar coluna is_personal se não existir
SET @exist := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'schedules' 
    AND COLUMN_NAME = 'is_personal');

SET @sqlstmt := IF(@exist = 0, 
    'ALTER TABLE schedules ADD COLUMN is_personal TINYINT(1) DEFAULT 0 AFTER notes',
    'SELECT "Coluna is_personal já existe"');

PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Adicionar coluna schedule_date se não existir (alias de scheduled_date)
SET @exist := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'schedules' 
    AND COLUMN_NAME = 'schedule_date');

SET @sqlstmt := IF(@exist = 0, 
    'ALTER TABLE schedules ADD COLUMN schedule_date DATE NULL AFTER is_personal',
    'SELECT "Coluna schedule_date já existe"');

PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Adicionar coluna meal_time se não existir (alias de scheduled_time)
SET @exist := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'schedules' 
    AND COLUMN_NAME = 'meal_time');

SET @sqlstmt := IF(@exist = 0, 
    'ALTER TABLE schedules ADD COLUMN meal_time TIME NULL AFTER schedule_date',
    'SELECT "Coluna meal_time já existe"');

PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Copiar dados de scheduled_date para schedule_date se necessário
UPDATE schedules 
SET schedule_date = scheduled_date 
WHERE schedule_date IS NULL AND scheduled_date IS NOT NULL;

-- Copiar dados de scheduled_time para meal_time se necessário
UPDATE schedules 
SET meal_time = scheduled_time 
WHERE meal_time IS NULL AND scheduled_time IS NOT NULL;

-- Adicionar índice para agendamentos pessoais
SET @exist := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'schedules' 
    AND INDEX_NAME = 'idx_personal_schedules');

SET @sqlstmt := IF(@exist = 0, 
    'CREATE INDEX idx_personal_schedules ON schedules(user_id, is_personal, schedule_date)',
    'SELECT "Índice idx_personal_schedules já existe"');

PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT 'Migração concluída com sucesso!' as status;
