<?php
// ============================================
// ChefGuedes - API de Agendamento
// Gestão de agendamentos de receitas
// ============================================

require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

// Verificar autenticação via Bearer token
function verifyAuth() {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? '';
    
    if (!preg_match('/Bearer\s+(\S+)/', $authHeader, $matches)) {
        jsonError('Token de autenticação não fornecido.', 401);
    }
    
    $token = $matches[1];
    $db = getDB();
    $stmt = $db->prepare("SELECT user_id FROM sessions WHERE session_token = ? AND (expires_at IS NULL OR expires_at > NOW())");
    $stmt->execute([$token]);
    $session = $stmt->fetch();
    
    if (!$session) {
        jsonError('Sessão inválida ou expirada.', 401);
    }
    
    return $session['user_id'];
}

// Verificar sessão (legacy)
function verifySession($sessionToken) {
    $db = getDB();
    $stmt = $db->prepare("SELECT user_id FROM sessions WHERE session_token = ? AND (expires_at IS NULL OR expires_at > NOW())");
    $stmt->execute([$sessionToken]);
    $session = $stmt->fetch();
    
    if (!$session) {
        jsonError('Sessão inválida ou expirada.', 401);
    }
    
    return $session['user_id'];
}

// ============================================
// LISTAR AGENDAMENTOS
// ============================================
if ($method === 'GET') {
    // Suportar autenticação via sessionToken ou Bearer
    if (isset($_GET['sessionToken'])) {
        $userId = verifySession($_GET['sessionToken']);
    } else {
        $userId = verifyAuth();
    }
    
    $startDate = $_GET['start_date'] ?? date('Y-m-d');
    $endDate = $_GET['end_date'] ?? date('Y-m-d', strtotime('+30 days'));
    $groupId = $_GET['group_id'] ?? null;
    $isPersonal = isset($_GET['is_personal']) && $_GET['is_personal'] == '1';
    
    try {
        $db = getDB();
        
        // Se is_personal, buscar agendamentos pessoais E agendamentos de grupo atribuídos ao utilizador
        if ($isPersonal) {
            $sql = "
                SELECT s.id, 
                       COALESCE(s.schedule_date, s.scheduled_date) as schedule_date,
                       s.meal_type, 
                       s.recipe_id, 
                       COALESCE(s.meal_time, s.scheduled_time) as meal_time,
                       s.notes,
                       s.group_id,
                       s.assigned_to,
                       s.user_id,
                       r.title as recipe_name, 
                       r.image as recipe_image,
                       g.name as group_name,
                       u.username as created_by_name
                FROM schedules s
                LEFT JOIN recipes r ON s.recipe_id = r.id
                LEFT JOIN `groups` g ON s.group_id = g.id
                LEFT JOIN users u ON s.user_id = u.id
                WHERE (
                    (s.user_id = ? AND (s.group_id IS NULL OR s.is_personal = 1))
                    OR 
                    (s.assigned_to = ?)
                )
                AND COALESCE(s.schedule_date, s.scheduled_date) BETWEEN ? AND ?
                ORDER BY COALESCE(s.schedule_date, s.scheduled_date) ASC, 
                         COALESCE(s.meal_time, s.scheduled_time) ASC
            ";
            $stmt = $db->prepare($sql);
            $stmt->execute([$userId, $userId, $startDate, $endDate]);
            $schedules = $stmt->fetchAll();
            jsonSuccess('Agendamentos pessoais carregados.', $schedules);
        }
        // Se group_id for fornecido, buscar agendamentos do grupo
        elseif ($groupId) {
            // Verificar se o utilizador é membro do grupo
            $stmt = $db->prepare("SELECT id FROM `group_members` WHERE group_id = ? AND user_id = ?");
            $stmt->execute([$groupId, $userId]);
            if (!$stmt->fetch()) {
                jsonError('Não tem permissão para ver agendamentos deste grupo.', 403);
            }
            
            // Verificar se a coluna assigned_to existe
            $checkColumn = $db->query("SHOW COLUMNS FROM schedules LIKE 'assigned_to'")->fetch();
            
            if ($checkColumn) {
                // Com assigned_to
                $sql = "
                    SELECT s.*, r.title as recipe_title, r.image as recipe_image,
                           u.username as created_by_name,
                           u2.username as assigned_to_name, u2.id as assigned_to_id
                    FROM schedules s
                    LEFT JOIN recipes r ON s.recipe_id = r.id
                    LEFT JOIN users u ON s.user_id = u.id
                    LEFT JOIN users u2 ON s.assigned_to = u2.id
                    WHERE s.group_id = ? AND s.scheduled_date BETWEEN ? AND ?
                    ORDER BY s.scheduled_date ASC, s.scheduled_time ASC
                ";
            } else {
                // Sem assigned_to (compatibilidade)
                $sql = "
                    SELECT s.*, r.title as recipe_title, r.image as recipe_image,
                           u.username as created_by_name
                    FROM schedules s
                    LEFT JOIN recipes r ON s.recipe_id = r.id
                    LEFT JOIN users u ON s.user_id = u.id
                    WHERE s.group_id = ? AND s.scheduled_date BETWEEN ? AND ?
                    ORDER BY s.scheduled_date ASC, s.scheduled_time ASC
                ";
            }
            $stmt = $db->prepare($sql);
            $stmt->execute([$groupId, $startDate, $endDate]);
            $schedules = $stmt->fetchAll();
            jsonSuccess('Agendamentos carregados.', ['schedules' => $schedules]);
        } else {
            // Buscar agendamentos pessoais do utilizador (fallback)
            $sql = "
                SELECT s.*, r.title as recipe_title, r.image as recipe_image
                FROM schedules s
                LEFT JOIN recipes r ON s.recipe_id = r.id
                WHERE s.user_id = ? AND s.group_id IS NULL AND s.scheduled_date BETWEEN ? AND ?
                ORDER BY s.scheduled_date ASC, s.scheduled_time ASC
            ";
            $stmt = $db->prepare($sql);
            $stmt->execute([$userId, $startDate, $endDate]);
            $schedules = $stmt->fetchAll();
            jsonSuccess('Agendamentos carregados.', ['schedules' => $schedules]);
        }
        
    } catch (PDOException $e) {
        jsonError('Erro ao carregar agendamentos: ' . $e->getMessage(), 500);
    }
}

// ============================================
// CRIAR AGENDAMENTO
// ============================================
if ($method === 'POST' && (!isset($input['action']) || $input['action'] === 'create')) {
    // Suportar autenticação via sessionToken ou Bearer
    if (isset($input['sessionToken'])) {
        $userId = verifySession($input['sessionToken']);
    } else {
        $userId = verifyAuth();
    }
    
    // Suportar novo formato de agendamento pessoal
    if (isset($input['is_personal']) && $input['is_personal']) {
        $scheduleDate = $input['schedule_date'] ?? '';
        $mealType = $input['meal_type'] ?? '';
        $recipeId = $input['recipe_id'] ?? null;
        $mealTime = $input['meal_time'] ?? null;
        $notes = $input['notes'] ?? '';
        
        if (empty($scheduleDate) || empty($mealType) || empty($recipeId)) {
            jsonError('Data, tipo de refeição e receita são obrigatórios.', 400);
        }
        
        try {
            $db = getDB();
            
            // Criar agendamento pessoal
            $stmt = $db->prepare("
                INSERT INTO schedules (user_id, recipe_id, schedule_date, meal_type, meal_time, notes, is_personal) 
                VALUES (?, ?, ?, ?, ?, ?, 1)
            ");
            $stmt->execute([$userId, $recipeId, $scheduleDate, $mealType, $mealTime, $notes]);
            
            $scheduleId = $db->lastInsertId();
            
            jsonSuccess('Refeição agendada com sucesso!', ['id' => $scheduleId]);
            
        } catch (PDOException $e) {
            jsonError('Erro ao criar agendamento: ' . $e->getMessage(), 500);
        }
        exit;
    }
    
    // Formato antigo (compatibilidade) - criar agendamento
    $groupId = $input['groupId'] ?? null;
    $recipeId = $input['recipeId'] ?? null;
    $title = $input['title'] ?? '';
    $description = $input['description'] ?? '';
    $mealType = $input['mealType'] ?? 'Almoço';
    $scheduledDate = $input['scheduledDate'] ?? '';
    $scheduledTime = $input['scheduledTime'] ?? null;
    $notes = $input['notes'] ?? '';
    $assignedTo = $input['assignedTo'] ?? null;
    
    if (empty($title) || empty($scheduledDate)) {
        jsonError('Título e data são obrigatórios.', 400);
    }
    
    try {
        $db = getDB();
        
        // Se for para um grupo, verificar se é membro
        if ($groupId) {
            $stmt = $db->prepare("SELECT id FROM `group_members` WHERE group_id = ? AND user_id = ?");
            $stmt->execute([$groupId, $userId]);
            if (!$stmt->fetch()) {
                jsonError('Não tem permissão para criar agendamentos neste grupo.', 403);
            }
            
            // Se assignedTo foi fornecido, verificar se é membro do grupo
            if ($assignedTo) {
                $stmt = $db->prepare("SELECT id FROM `group_members` WHERE group_id = ? AND user_id = ?");
                $stmt->execute([$groupId, $assignedTo]);
                if (!$stmt->fetch()) {
                    jsonError('O utilizador atribuído não é membro do grupo.', 400);
                }
            }
        }
        
        // Verificar se a coluna assigned_to existe
        $checkColumn = $db->query("SHOW COLUMNS FROM schedules LIKE 'assigned_to'")->fetch();
        
        // Criar agendamento com ou sem assigned_to
        if ($checkColumn) {
            // Com assigned_to
            $stmt = $db->prepare("
                INSERT INTO schedules (user_id, group_id, recipe_id, title, description, meal_type, scheduled_date, scheduled_time, notes, assigned_to) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $userId,
                $groupId,
                $recipeId,
                $title,
                $description,
                $mealType,
                $scheduledDate,
                $scheduledTime,
                $notes,
                $assignedTo
            ]);
        } else {
            // Sem assigned_to (compatibilidade)
            $stmt = $db->prepare("
                INSERT INTO schedules (user_id, group_id, recipe_id, title, description, meal_type, scheduled_date, scheduled_time) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $userId,
                $groupId,
                $recipeId,
                $title,
                $description,
                $mealType,
                $scheduledDate,
                $scheduledTime
            ]);
        }
        
        $scheduleId = $db->lastInsertId();
        
        // Se for agendamento de grupo, notificar os membros
        if ($groupId) {
            $stmt = $db->prepare("SELECT name FROM `groups` WHERE id = ?");
            $stmt->execute([$groupId]);
            $group = $stmt->fetch();
            
            $stmt = $db->prepare("SELECT user_id FROM `group_members` WHERE group_id = ? AND user_id != ?");
            $stmt->execute([$groupId, $userId]);
            $members = $stmt->fetchAll();
            
            $notifStmt = $db->prepare("
                INSERT INTO notifications (user_id, type, title, message, link, sender_id, related_id) 
                VALUES (?, 'schedule_reminder', ?, ?, ?, ?, ?)
            ");
            
            foreach ($members as $member) {
                $notifStmt->execute([
                    $member['user_id'],
                    'Nova Refeição Agendada',
                    "Refeição '$title' foi agendada no grupo '{$group['name']}' para " . date('d/m/Y', strtotime($scheduledDate)),
                    'grupos.html?group=' . $groupId,
                    $userId,
                    $scheduleId
                ]);
            }
        }
        
        // Registar atividade
        $stmt = $db->prepare("
            INSERT INTO activities (user_id, type, description) 
            VALUES (?, 'schedule_create', ?)
        ");
        $activityDesc = $groupId ? "Agendou refeição: $title (Grupo)" : "Agendou refeição: $title";
        $stmt->execute([$userId, $activityDesc]);
        
        jsonSuccess('Agendamento criado com sucesso!', ['scheduleId' => $scheduleId]);
        
    } catch (PDOException $e) {
        jsonError('Erro ao criar agendamento: ' . $e->getMessage(), 500);
    }
}

// ============================================
// ATUALIZAR AGENDAMENTO (PUT)
// ============================================
if ($method === 'PUT') {
    $userId = verifyAuth();
    
    $scheduleId = $_GET['id'] ?? 0;
    
    // Suportar formato de agendamento pessoal
    if (isset($input['is_personal']) && $input['is_personal']) {
        $scheduleDate = $input['schedule_date'] ?? '';
        $mealType = $input['meal_type'] ?? '';
        $recipeId = $input['recipe_id'] ?? null;
        $mealTime = $input['meal_time'] ?? null;
        $notes = $input['notes'] ?? '';
        
        try {
            $db = getDB();
            
            // Verificar se o agendamento pertence ao utilizador
            $stmt = $db->prepare("SELECT user_id, group_id FROM schedules WHERE id = ?");
            $stmt->execute([$scheduleId]);
            $schedule = $stmt->fetch();
            
            if (!$schedule) {
                jsonError('Agendamento não encontrado.', 404);
            }
            
            // Se for agendamento pessoal, apenas o criador pode editar
            if (!$schedule['group_id']) {
                if ($schedule['user_id'] != $userId) {
                    jsonError('Não tem permissão para editar este agendamento.', 403);
                }
            } else {
                // Se for agendamento de grupo, verificar se é criador ou admin do grupo
                $stmt = $db->prepare("SELECT role FROM `group_members` WHERE group_id = ? AND user_id = ?");
                $stmt->execute([$schedule['group_id'], $userId]);
                $member = $stmt->fetch();
                
                // Verificar se é admin do sistema
                $stmt = $db->prepare("SELECT is_admin FROM `users` WHERE id = ?");
                $stmt->execute([$userId]);
                $user = $stmt->fetch();
                $isSystemAdmin = $user && $user['is_admin'];
                
                // Permitir apenas se for criador, admin do grupo ou admin do sistema
                if ($schedule['user_id'] != $userId && (!$member || $member['role'] !== 'admin') && !$isSystemAdmin) {
                    jsonError('Apenas o criador do agendamento ou administradores do grupo podem editar.', 403);
                }
            }
            
            // Atualizar agendamento
            $stmt = $db->prepare("
                UPDATE schedules 
                SET recipe_id = ?, schedule_date = ?, meal_type = ?, meal_time = ?, notes = ?
                WHERE id = ?
            ");
            $stmt->execute([$recipeId, $scheduleDate, $mealType, $mealTime, $notes, $scheduleId]);
            
            jsonSuccess('Refeição atualizada com sucesso!');
            
        } catch (PDOException $e) {
            jsonError('Erro ao atualizar agendamento: ' . $e->getMessage(), 500);
        }
        exit;
    }
}

// ============================================
// ATUALIZAR AGENDAMENTO (POST - Legacy)
// ============================================
if ($method === 'POST' && isset($input['action']) && $input['action'] === 'update') {
    $sessionToken = $input['sessionToken'] ?? '';
    $userId = verifySession($sessionToken);
    
    $scheduleId = $input['scheduleId'] ?? 0;
    $title = $input['title'] ?? '';
    $description = $input['description'] ?? '';
    $mealType = $input['mealType'] ?? 'Almoço';
    $scheduledDate = $input['scheduledDate'] ?? '';
    $scheduledTime = $input['scheduledTime'] ?? null;
    $recipeId = $input['recipeId'] ?? null;
    
    try {
        $db = getDB();
        
        // Verificar se o agendamento existe e obter informações
        $stmt = $db->prepare("SELECT user_id, group_id FROM schedules WHERE id = ?");
        $stmt->execute([$scheduleId]);
        $schedule = $stmt->fetch();
        
        if (!$schedule) {
            jsonError('Agendamento não encontrado.', 404);
        }
        
        // Verificar permissões
        if ($schedule['group_id']) {
            // Agendamento de grupo - verificar se é criador ou admin do grupo
            $stmt = $db->prepare("SELECT role FROM `group_members` WHERE group_id = ? AND user_id = ?");
            $stmt->execute([$schedule['group_id'], $userId]);
            $member = $stmt->fetch();
            
            // Verificar se é admin do sistema
            $stmt = $db->prepare("SELECT is_admin FROM `users` WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            $isSystemAdmin = $user && $user['is_admin'];
            
            // Permitir apenas se for criador, admin do grupo ou admin do sistema
            if ($schedule['user_id'] != $userId && (!$member || $member['role'] !== 'admin') && !$isSystemAdmin) {
                jsonError('Apenas o criador do agendamento ou administradores do grupo podem editar.', 403);
            }
        } else {
            // Agendamento pessoal - apenas o criador pode editar
            if ($schedule['user_id'] != $userId) {
                jsonError('Não tem permissão para editar este agendamento.', 403);
            }
        }
        
        // Atualizar agendamento
        $stmt = $db->prepare("
            UPDATE schedules 
            SET title = ?, description = ?, meal_type = ?, scheduled_date = ?, scheduled_time = ?, recipe_id = ?
            WHERE id = ?
        ");
        $stmt->execute([$title, $description, $mealType, $scheduledDate, $scheduledTime, $recipeId, $scheduleId]);
        
        // Registar atividade
        $stmt = $db->prepare("
            INSERT INTO activities (user_id, type, description) 
            VALUES (?, 'schedule_update', ?)
        ");
        $stmt->execute([$userId, "Atualizou agendamento: $title"]);
        
        jsonSuccess('Agendamento atualizado com sucesso!');
        
    } catch (PDOException $e) {
        jsonError('Erro ao atualizar agendamento: ' . $e->getMessage(), 500);
    }
}

// ============================================
// ELIMINAR AGENDAMENTO (DELETE)
// ============================================
if ($method === 'DELETE') {
    $userId = verifyAuth();
    
    $scheduleId = $_GET['id'] ?? 0;
    
    try {
        $db = getDB();
        
        // Verificar permissões
        $stmt = $db->prepare("SELECT user_id, group_id FROM schedules WHERE id = ?");
        $stmt->execute([$scheduleId]);
        $schedule = $stmt->fetch();
        
        if (!$schedule) {
            jsonError('Agendamento não encontrado.', 404);
        }
        
        // Se for agendamento de grupo, verificar se é admin do grupo
        if ($schedule['group_id']) {
            $stmt = $db->prepare("SELECT role FROM `group_members` WHERE group_id = ? AND user_id = ?");
            $stmt->execute([$schedule['group_id'], $userId]);
            $member = $stmt->fetch();
            
            // Verificar se é admin do sistema
            $stmt = $db->prepare("SELECT is_admin FROM `users` WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            $isSystemAdmin = $user && $user['is_admin'];
            
            // Admin do sistema, admin do grupo ou criador podem eliminar
            if (!$member) {
                jsonError('Não tem permissão para eliminar este agendamento.', 403);
            }
            
            if ($member['role'] !== 'admin' && $schedule['user_id'] != $userId && !$isSystemAdmin) {
                jsonError('Apenas o criador, administradores do grupo ou administradores do sistema podem eliminar agendamentos.', 403);
            }
        } else {
            // Agendamento pessoal - só o criador pode eliminar
            if ($schedule['user_id'] != $userId) {
                jsonError('Não tem permissão para eliminar este agendamento.', 403);
            }
        }
        
        // Eliminar
        $stmt = $db->prepare("DELETE FROM schedules WHERE id = ?");
        $stmt->execute([$scheduleId]);
        
        jsonSuccess('Agendamento eliminado com sucesso!');
        
    } catch (PDOException $e) {
        jsonError('Erro ao eliminar agendamento: ' . $e->getMessage(), 500);
    }
    exit;
}

// ============================================
// ELIMINAR AGENDAMENTO (POST - Legacy)
// ============================================
if ($method === 'POST' && isset($input['action']) && $input['action'] === 'delete') {
    $sessionToken = $input['sessionToken'] ?? '';
    $userId = verifySession($sessionToken);
    
    $scheduleId = $input['scheduleId'] ?? 0;
    
    try {
        $db = getDB();
        
        // Verificar permissões
        $stmt = $db->prepare("SELECT user_id, group_id FROM schedules WHERE id = ?");
        $stmt->execute([$scheduleId]);
        $schedule = $stmt->fetch();
        
        if (!$schedule) {
            jsonError('Agendamento não encontrado.', 404);
        }
        
        // Se for agendamento de grupo, verificar se é admin do grupo
        if ($schedule['group_id']) {
            $stmt = $db->prepare("SELECT role FROM `group_members` WHERE group_id = ? AND user_id = ?");
            $stmt->execute([$schedule['group_id'], $userId]);
            $member = $stmt->fetch();
            
            // Verificar se é admin do sistema
            $stmt = $db->prepare("SELECT is_admin FROM `users` WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            $isSystemAdmin = $user && $user['is_admin'];
            
            // Admin do sistema, admin do grupo ou criador podem eliminar
            if (!$member) {
                jsonError('Não tem permissão para eliminar este agendamento.', 403);
            }
            
            if ($member['role'] !== 'admin' && $schedule['user_id'] != $userId && !$isSystemAdmin) {
                jsonError('Apenas o criador, administradores do grupo ou administradores do sistema podem eliminar agendamentos.', 403);
            }
        } else {
            // Agendamento pessoal - só o criador pode eliminar
            if ($schedule['user_id'] != $userId) {
                jsonError('Não tem permissão para eliminar este agendamento.', 403);
            }
        }
        
        // Eliminar
        $stmt = $db->prepare("DELETE FROM schedules WHERE id = ?");
        $stmt->execute([$scheduleId]);
        
        jsonSuccess('Agendamento eliminado com sucesso!');
        
    } catch (PDOException $e) {
        jsonError('Erro ao eliminar agendamento: ' . $e->getMessage(), 500);
    }
}

// ============================================
// ATRIBUIR RESPONSÁVEL (POST)
// ============================================
if ($method === 'POST' && isset($input['action']) && $input['action'] === 'assign') {
    $sessionToken = $input['sessionToken'] ?? '';
    $userId = verifySession($sessionToken);
    
    $scheduleId = $input['scheduleId'] ?? 0;
    $assignedTo = $input['assignedTo'] ?? null;
    
    // Log para debug
    error_log("Assign action - scheduleId: $scheduleId, assignedTo: " . ($assignedTo ?? 'null') . ", userId: $userId");
    
    try {
        $db = getDB();
        
        // Verificar se o agendamento existe e obter informações
        $stmt = $db->prepare("SELECT user_id, group_id FROM schedules WHERE id = ?");
        $stmt->execute([$scheduleId]);
        $schedule = $stmt->fetch();
        
        error_log("Schedule found: " . ($schedule ? 'YES' : 'NO'));
        if ($schedule) {
            error_log("Schedule group_id: " . ($schedule['group_id'] ?? 'NULL'));
        }
        
        if (!$schedule) {
            jsonError('Agendamento não encontrado.', 404);
        }
        
        if (!$schedule['group_id']) {
            jsonError('Apenas agendamentos de grupo podem ter responsáveis atribuídos.', 400);
        }
        
        // Verificar se o utilizador é ADMIN do grupo (apenas admins podem atribuir responsáveis)
        $stmt = $db->prepare("SELECT role FROM `group_members` WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$schedule['group_id'], $userId]);
        $member = $stmt->fetch();
        
        if (!$member) {
            jsonError('Não tem permissão para atribuir responsáveis neste grupo.', 403);
        }
        
        // Verificar se é admin
        if ($member['role'] !== 'admin') {
            jsonError('Apenas administradores do grupo podem atribuir ou alterar responsáveis.', 403);
        }
        
        // Se assignedTo foi fornecido, verificar se é membro do grupo
        if ($assignedTo) {
            $stmt = $db->prepare("SELECT id FROM `group_members` WHERE group_id = ? AND user_id = ?");
            $stmt->execute([$schedule['group_id'], $assignedTo]);
            if (!$stmt->fetch()) {
                jsonError('O utilizador atribuído não é membro do grupo.', 400);
            }
        }
        
        // Atualizar responsável
        $stmt = $db->prepare("UPDATE schedules SET assigned_to = ? WHERE id = ?");
        $stmt->execute([$assignedTo, $scheduleId]);
        
        jsonSuccess('Responsável atribuído com sucesso!');
        
    } catch (PDOException $e) {
        jsonError('Erro ao atribuir responsável: ' . $e->getMessage(), 500);
    }
    exit;
}

