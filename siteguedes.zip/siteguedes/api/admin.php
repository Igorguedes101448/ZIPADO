<?php
// ============================================
// ChefGuedes - API de Administração
// Gestão de utilizadores e receitas (apenas admins)
// ============================================

define('DB_SKIP_JSON_HELPERS', true);
require_once 'db.php';
session_start();

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = [];
}

function getSessionTokenFromRequest($input = []) {
    if (!empty($input['sessionToken'])) {
        return $input['sessionToken'];
    }

    if (!empty($_GET['sessionToken'])) {
        return $_GET['sessionToken'];
    }

    $authHeader = '';
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
    } elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    } else {
        $headers = function_exists('getallheaders') ? getallheaders() : [];
        $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    }

    if (!empty($authHeader) && preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
        return trim($matches[1]);
    }

    return '';
}

function resolveAuthenticatedUserId($input = []) {
    if (!empty($_SESSION['user_id'])) {
        return (int) $_SESSION['user_id'];
    }

    $sessionToken = getSessionTokenFromRequest($input);
    if (empty($sessionToken)) {
        return null;
    }

    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT user_id FROM sessions WHERE session_token = ? AND (expires_at IS NULL OR expires_at > NOW())");
        $stmt->execute([$sessionToken]);
        $session = $stmt->fetch();

        if (!$session || empty($session['user_id'])) {
            return null;
        }

        $_SESSION['user_id'] = (int) $session['user_id'];
        return (int) $session['user_id'];
    } catch (PDOException $e) {
        return null;
    }
}

// Verificar se é admin
function isAdmin($input = []) {
    $userId = resolveAuthenticatedUserId($input);
    if (!$userId) {
        return false;
    }
    
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT is_admin FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();

        $isAdmin = $user && (int) $user['is_admin'] === 1;
        $_SESSION['is_admin'] = $isAdmin ? 1 : 0;

        return $isAdmin;
    } catch (PDOException $e) {
        return false;
    }
}

// Função para retornar erro JSON
function jsonError($message, $code = 400) {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code($code);
    echo json_encode(['success' => false, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

// Função para retornar sucesso JSON
function jsonSuccess($data = [], $message = '') {
    header('Content-Type: application/json; charset=utf-8');
    $json = json_encode(['success' => true, 'message' => $message, 'data' => $data], JSON_UNESCAPED_UNICODE);
    
    if ($json === false) {
        http_response_code(500);
        die(json_encode(['success' => false, 'message' => 'Erro ao codificar JSON: ' . json_last_error_msg()], JSON_UNESCAPED_UNICODE));
    }
    
    echo $json;
    exit;
}

// ============================================
// DEBUG - Verificar sessão (remover após debug)
// ============================================
if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'debug_session') {
    $sessionInfo = [
        'session_id' => session_id(),
        'user_id' => $_SESSION['user_id'] ?? 'not set',
        'is_admin' => $_SESSION['is_admin'] ?? 'not set',
        'username' => $_SESSION['username'] ?? 'not set',
        'all_session' => $_SESSION
    ];
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'data' => $sessionInfo]);
    exit;
}

// ============================================
// VERIFICAR SE É ADMIN (para validação) - Antes da verificação global
// ============================================
if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'check_admin') {
    if (isAdmin($input)) {
        jsonSuccess(['is_admin' => true]);
    } else {
        jsonError('Não é administrador.', 403);
    }
}

// Verificar autenticação e permissão de admin para todas as outras ações
if (!isAdmin($input)) {
    jsonError('Acesso negado. Apenas administradores podem aceder a esta API.', 403);
}

try {
    $db = getDB();

    // ============================================
    // OBTER ESTATÍSTICAS
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'stats') {
        // Total de utilizadores
        $stmt = $db->query("SELECT COUNT(*) as total FROM users WHERE is_admin = 0");
        $totalUsers = $stmt->fetch()['total'];
        
        // Utilizadores banidos
        $stmt = $db->query("SELECT COUNT(*) as total FROM users WHERE banned = 1");
        $bannedUsers = $stmt->fetch()['total'];
        
        // Utilizadores suspensos
        $stmt = $db->query("SELECT COUNT(*) as total FROM users WHERE suspended_until IS NOT NULL AND suspended_until > NOW()");
        $suspendedUsers = $stmt->fetch()['total'];
        
        // Total de receitas
        $stmt = $db->query("SELECT COUNT(*) as total FROM recipes");
        $totalRecipes = $stmt->fetch()['total'];
        
        // Receitas públicas
        $stmt = $db->query("SELECT COUNT(*) as total FROM recipes WHERE visibility = 'public'");
        $publicRecipes = $stmt->fetch()['total'];
        
        // Ações recentes
        $stmt = $db->query("SELECT COUNT(*) as total FROM admin_actions WHERE DATE(created_at) = CURDATE()");
        $todayActions = $stmt->fetch()['total'];
        
        jsonSuccess([
            'totalUsers' => $totalUsers,
            'bannedUsers' => $bannedUsers,
            'suspendedUsers' => $suspendedUsers,
            'totalRecipes' => $totalRecipes,
            'publicRecipes' => $publicRecipes,
            'todayActions' => $todayActions
        ]);
    }

    // ============================================
    // LISTAR TODOS OS UTILIZADORES
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'users') {
        $search = $_GET['search'] ?? '';
        
        $sql = "SELECT id, username, email, user_code, created_at, banned, banned_reason, 
                       suspended_until, warning_count, is_admin 
                FROM users 
                WHERE is_admin = 0";
        
        if ($search) {
            $sql .= " AND (username LIKE ? OR email LIKE ?)";
            $stmt = $db->prepare($sql . " ORDER BY created_at DESC");
            $searchParam = '%' . $search . '%';
            $stmt->execute([$searchParam, $searchParam]);
        } else {
            $stmt = $db->prepare($sql . " ORDER BY created_at DESC");
            $stmt->execute();
        }
        
        $users = $stmt->fetchAll();
        
        // Adicionar status a cada utilizador
        foreach ($users as &$user) {
            if ($user['banned']) {
                $user['status'] = 'banned';
            } elseif ($user['suspended_until'] && strtotime($user['suspended_until']) > time()) {
                $user['status'] = 'suspended';
            } else {
                $user['status'] = 'active';
            }
        }
        
        jsonSuccess($users);
    }

    // ============================================
    // LISTAR TODAS AS RECEITAS
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'recipes') {
        $search = $_GET['search'] ?? '';
        
        $sql = "SELECT r.id, r.title, r.category, r.visibility, r.created_at, r.image,
                       u.username as author_username, u.id as author_id
                FROM recipes r
                LEFT JOIN users u ON r.author_id = u.id";
        
        if ($search) {
            $sql .= " WHERE r.title LIKE ? OR r.category LIKE ?";
            $stmt = $db->prepare($sql . " ORDER BY r.created_at DESC");
            $searchParam = '%' . $search . '%';
            $stmt->execute([$searchParam, $searchParam]);
        } else {
            $stmt = $db->prepare($sql . " ORDER BY r.created_at DESC");
            $stmt->execute();
        }
        
        $recipes = $stmt->fetchAll();
        jsonSuccess($recipes);
    }

    // ============================================
    // BANIR UTILIZADOR
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'ban_user') {
        $userId = $input['user_id'] ?? null;
        $reason = $input['reason'] ?? 'Sem motivo especificado';
        
        if (!$userId) {
            jsonError('ID do utilizador não fornecido.');
        }
        
        // Verificar se não é admin
        $stmt = $db->prepare("SELECT username, is_admin FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            jsonError('Utilizador não encontrado.');
        }
        
        if ($user['is_admin']) {
            jsonError('Não é possível banir um administrador.');
        }
        
        // Banir utilizador
        $stmt = $db->prepare("UPDATE users SET banned = 1, banned_reason = ? WHERE id = ?");
        $stmt->execute([$reason, $userId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason)
            VALUES (?, 'ban', 'user', ?, ?)
        ");
        $stmt->execute([$_SESSION['user_id'], $userId, $reason]);
        
        // Registar atividade
        $stmt = $db->prepare("
            INSERT INTO activities (user_id, type, description)
            VALUES (?, 'user_banned', ?)
        ");
        $stmt->execute([$_SESSION['user_id'], "Utilizador {$user['username']} foi banido. Motivo: $reason"]);
        
        jsonSuccess([], 'Utilizador banido com sucesso.');
    }

    // ============================================
    // DESBANIR UTILIZADOR
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'unban_user') {
        $userId = $input['user_id'] ?? null;
        
        if (!$userId) {
            jsonError('ID do utilizador não fornecido.');
        }
        
        // Obter nome do utilizador
        $stmt = $db->prepare("SELECT username FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            jsonError('Utilizador não encontrado.');
        }
        
        // Desbanir utilizador
        $stmt = $db->prepare("UPDATE users SET banned = 0, banned_reason = NULL WHERE id = ?");
        $stmt->execute([$userId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason)
            VALUES (?, 'unban', 'user', ?, 'Banimento removido')
        ");
        $stmt->execute([$_SESSION['user_id'], $userId]);
        
        // Registar atividade
        $stmt = $db->prepare("
            INSERT INTO activities (user_id, type, description)
            VALUES (?, 'user_unbanned', ?)
        ");
        $stmt->execute([$_SESSION['user_id'], "Utilizador {$user['username']} foi desbanido"]);
        
        jsonSuccess([], 'Utilizador desbanido com sucesso.');
    }

    // ============================================
    // SUSPENDER UTILIZADOR (temporário)
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'suspend_user') {
        $userId = $input['user_id'] ?? null;
        $days = $input['days'] ?? 7;
        $reason = $input['reason'] ?? 'Sem motivo especificado';
        
        if (!$userId) {
            jsonError('ID do utilizador não fornecido.');
        }
        
        // Verificar se não é admin
        $stmt = $db->prepare("SELECT username, is_admin FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            jsonError('Utilizador não encontrado.');
        }
        
        if ($user['is_admin']) {
            jsonError('Não é possível suspender um administrador.');
        }
        
        // Calcular data de suspensão
        $suspendUntil = date('Y-m-d H:i:s', strtotime("+$days days"));
        
        // Suspender utilizador
        $stmt = $db->prepare("UPDATE users SET suspended_until = ? WHERE id = ?");
        $stmt->execute([$suspendUntil, $userId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason, details)
            VALUES (?, 'suspend', 'user', ?, ?, ?)
        ");
        $details = json_encode(['days' => $days, 'suspended_until' => $suspendUntil]);
        $stmt->execute([$_SESSION['user_id'], $userId, $reason, $details]);
        
        // Registar atividade
        $stmt = $db->prepare("
            INSERT INTO activities (user_id, type, description)
            VALUES (?, 'user_suspended', ?)
        ");
        $stmt->execute([$_SESSION['user_id'], "Utilizador {$user['username']} suspenso por $days dias. Motivo: $reason"]);
        
        jsonSuccess(['suspended_until' => $suspendUntil], "Utilizador suspenso por $days dias.");
    }

    // ============================================
    // REMOVER SUSPENSÃO
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'unsuspend_user') {
        $userId = $input['user_id'] ?? null;
        
        if (!$userId) {
            jsonError('ID do utilizador não fornecido.');
        }
        
        // Obter nome do utilizador
        $stmt = $db->prepare("SELECT username FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            jsonError('Utilizador não encontrado.');
        }
        
        // Remover suspensão
        $stmt = $db->prepare("UPDATE users SET suspended_until = NULL WHERE id = ?");
        $stmt->execute([$userId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason)
            VALUES (?, 'unsuspend', 'user', ?, 'Suspensão removida')
        ");
        $stmt->execute([$_SESSION['user_id'], $userId]);
        
        // Registar atividade
        $stmt = $db->prepare("
            INSERT INTO activities (user_id, type, description)
            VALUES (?, 'user_unsuspended', ?)
        ");
        $stmt->execute([$_SESSION['user_id'], "Suspensão de {$user['username']} removida"]);
        
        jsonSuccess([], 'Suspensão removida com sucesso.');
    }

    // ============================================
    // DAR AVISO AO UTILIZADOR
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'warn_user') {
        $userId = $input['user_id'] ?? null;
        $reason = $input['reason'] ?? 'Sem motivo especificado';
        
        if (!$userId) {
            jsonError('ID do utilizador não fornecido.');
        }
        
        // Verificar se não é admin
        $stmt = $db->prepare("SELECT username, is_admin, warning_count FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            jsonError('Utilizador não encontrado.');
        }
        
        if ($user['is_admin']) {
            jsonError('Não é possível dar aviso a um administrador.');
        }
        
        // Incrementar contador de avisos
        $newWarningCount = ($user['warning_count'] ?? 0) + 1;
        $stmt = $db->prepare("UPDATE users SET warning_count = ? WHERE id = ?");
        $stmt->execute([$newWarningCount, $userId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason, details)
            VALUES (?, 'warn', 'user', ?, ?, ?)
        ");
        $details = json_encode(['warning_count' => $newWarningCount]);
        $stmt->execute([$_SESSION['user_id'], $userId, $reason, $details]);
        
        // Registar atividade
        $stmt = $db->prepare("
            INSERT INTO activities (user_id, type, description)
            VALUES (?, 'user_warned', ?)
        ");
        $stmt->execute([$_SESSION['user_id'], "Aviso dado a {$user['username']} ($newWarningCount avisos). Motivo: $reason"]);
        
        jsonSuccess(['warning_count' => $newWarningCount], "Aviso registado. Total de avisos: $newWarningCount");
    }

    // ============================================
    // APAGAR UTILIZADOR
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'delete_user') {
        $userId = $input['user_id'] ?? null;
        
        if (!$userId) {
            jsonError('ID do utilizador não fornecido.');
        }
        
        // Verificar se não é admin
        $stmt = $db->prepare("SELECT is_admin FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            jsonError('Utilizador não encontrado.');
        }
        
        if ($user['is_admin']) {
            jsonError('Não é possível apagar um administrador.');
        }
        
        // Apagar utilizador (CASCADE irá apagar suas receitas, favoritos, etc)
        $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        
        jsonSuccess([], 'Utilizador apagado com sucesso.');
    }

    // ============================================
    // APAGAR RECEITA
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'delete_recipe') {
        $recipeId = $input['recipe_id'] ?? null;
        $reason = $input['reason'] ?? 'Sem motivo especificado';
        
        if (!$recipeId) {
            jsonError('ID da receita não fornecido.');
        }
        
        // Verificar se receita existe e obter detalhes
        $stmt = $db->prepare("SELECT r.id, r.title, u.username as author FROM recipes r LEFT JOIN users u ON r.author_id = u.id WHERE r.id = ?");
        $stmt->execute([$recipeId]);
        $recipe = $stmt->fetch();
        
        if (!$recipe) {
            jsonError('Receita não encontrada.');
        }
        
        // Apagar receita
        $stmt = $db->prepare("DELETE FROM recipes WHERE id = ?");
        $stmt->execute([$recipeId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason, details)
            VALUES (?, 'delete_recipe', 'recipe', ?, ?, ?)
        ");
        $details = json_encode(['recipe_title' => $recipe['title'], 'recipe_author' => $recipe['author']]);
        $stmt->execute([$_SESSION['user_id'], $recipeId, $reason, $details]);
        
        // Registar atividade
        $stmt = $db->prepare("
            INSERT INTO activities (user_id, type, description)
            VALUES (?, 'recipe_deleted_admin', ?)
        ");
        $stmt->execute([$_SESSION['user_id'], "Receita '{$recipe['title']}' de {$recipe['author']} foi apagada. Motivo: $reason"]);
        
        jsonSuccess([], 'Receita apagada com sucesso.');
    }

    // ============================================
    // OBTER LOGS DE AÇÕES DO ADMIN
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'logs') {
        $limit = $_GET['limit'] ?? 50;
        $offset = $_GET['offset'] ?? 0;
        
        $actionType = $_GET['action_type'] ?? '';
        $targetType = $_GET['target_type'] ?? '';
        $startDate = $_GET['start_date'] ?? '';
        $endDate = $_GET['end_date'] ?? '';
        
        $sql = "SELECT 
                aa.*,
                u1.username as admin_username
            FROM admin_actions aa
            LEFT JOIN users u1 ON aa.admin_id = u1.id
            WHERE 1=1";
        $params = [];
        
        if ($actionType) {
            $sql .= " AND aa.action_type = ?";
            $params[] = $actionType;
        }
        if ($targetType) {
            $sql .= " AND aa.target_type = ?";
            $params[] = $targetType;
        }
        if ($startDate) {
            $sql .= " AND DATE(aa.created_at) >= ?";
            $params[] = $startDate;
        }
        if ($endDate) {
            $sql .= " AND DATE(aa.created_at) <= ?";
            $params[] = $endDate;
        }
        
        $sql .= " ORDER BY aa.created_at DESC LIMIT ? OFFSET ?";
        $params[] = (int)$limit;
        $params[] = (int)$offset;
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $logs = $stmt->fetchAll();
        
        // Get target details for each log
        foreach ($logs as &$log) {
            if ($log['target_type'] === 'user' && $log['target_id']) {
                $stmt = $db->prepare("SELECT username FROM users WHERE id = ?");
                $stmt->execute([$log['target_id']]);
                $target = $stmt->fetch();
                $log['target_name'] = $target ? $target['username'] : 'Utilizador removido';
            } elseif ($log['target_type'] === 'recipe' && $log['target_id']) {
                $stmt = $db->prepare("SELECT title FROM recipes WHERE id = ?");
                $stmt->execute([$log['target_id']]);
                $target = $stmt->fetch();
                $log['target_name'] = $target ? $target['title'] : 'Receita removida';
            }
        }
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM admin_actions WHERE 1=1";
        $countParams = [];
        if ($actionType) {
            $countSql .= " AND action_type = ?";
            $countParams[] = $actionType;
        }
        if ($targetType) {
            $countSql .= " AND target_type = ?";
            $countParams[] = $targetType;
        }
        if ($startDate) {
            $countSql .= " AND DATE(created_at) >= ?";
            $countParams[] = $startDate;
        }
        if ($endDate) {
            $countSql .= " AND DATE(created_at) <= ?";
            $countParams[] = $endDate;
        }
        
        $stmt = $db->prepare($countSql);
        $stmt->execute($countParams);
        $total = $stmt->fetch()['total'];
        
        jsonSuccess(['logs' => $logs, 'total' => $total]);
    }

    // ============================================
    // ALTERAR VISIBILIDADE DA RECEITA
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'change_recipe_visibility') {
        $recipeId = $input['recipe_id'] ?? null;
        $visibility = $input['visibility'] ?? 'private';
        
        if (!$recipeId) {
            jsonError('ID da receita não fornecido.');
        }
        
        if (!in_array($visibility, ['public', 'private', 'friends'])) {
            jsonError('Visibilidade inválida.');
        }
        
        // Alterar visibilidade
        $stmt = $db->prepare("UPDATE recipes SET visibility = ? WHERE id = ?");
        $stmt->execute([$visibility, $recipeId]);
        
        jsonSuccess([], 'Visibilidade alterada com sucesso.');
    }

    // ============================================
    // GRUPOS - LISTAR TODOS
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_groups') {
        $search = $_GET['search'] ?? '';
        
        $sql = "SELECT g.id, g.name, g.description, g.image, g.created_by, g.created_at, g.updated_at,
                u.username as creator_username,
                COALESCE(gm_count.cnt, 0) as member_count,
                COALESCE(sch_count.cnt, 0) as schedule_count
                FROM `groups` g
                LEFT JOIN users u ON g.created_by = u.id
                LEFT JOIN (SELECT group_id, COUNT(*) as cnt FROM group_members GROUP BY group_id) gm_count ON g.id = gm_count.group_id
                LEFT JOIN (SELECT group_id, COUNT(*) as cnt FROM schedules WHERE group_id IS NOT NULL GROUP BY group_id) sch_count ON g.id = sch_count.group_id";
        
        if ($search) {
            $sql .= " WHERE g.name LIKE ? OR u.username LIKE ?";
            $stmt = $db->prepare($sql . " ORDER BY g.created_at DESC");
            $searchParam = '%' . $search . '%';
            $stmt->execute([$searchParam, $searchParam]);
        } else {
            $stmt = $db->prepare($sql . " ORDER BY g.created_at DESC");
            $stmt->execute();
        }
        
        jsonSuccess($stmt->fetchAll());
    }

    // ============================================
    // GRUPOS - OBTER MEMBROS
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_group_members') {
        $groupId = $_GET['group_id'] ?? null;
        
        if (!$groupId) {
            jsonError('ID do grupo não fornecido.');
        }
        
        $stmt = $db->prepare("
            SELECT gm.*, u.username, u.email, u.profile_picture
            FROM group_members gm
            LEFT JOIN users u ON gm.user_id = u.id
            WHERE gm.group_id = ?
            ORDER BY gm.role DESC, gm.joined_at ASC
        ");
        $stmt->execute([$groupId]);
        
        jsonSuccess($stmt->fetchAll());
    }

    // ============================================
    // GRUPOS - APAGAR GRUPO
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'delete_group') {
        $groupId = $input['group_id'] ?? null;
        $reason = $input['reason'] ?? 'Sem motivo especificado';
        
        if (!$groupId) {
            jsonError('ID do grupo não fornecido.');
        }
        
        // Obter detalhes do grupo
        $stmt = $db->prepare("SELECT name FROM groups WHERE id = ?");
        $stmt->execute([$groupId]);
        $group = $stmt->fetch();
        
        if (!$group) {
            jsonError('Grupo não encontrado.');
        }
        
        // Apagar grupo (CASCADE remove membros e agendamentos)
        $stmt = $db->prepare("DELETE FROM groups WHERE id = ?");
        $stmt->execute([$groupId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason, details)
            VALUES (?, 'delete_group', 'group', ?, ?, ?)
        ");
        $details = json_encode(['group_name' => $group['name']]);
        $stmt->execute([$_SESSION['user_id'], $groupId, $reason, $details]);
        
        jsonSuccess([], 'Grupo apagado com sucesso.');
    }

    // ============================================
    // GRUPOS - REMOVER MEMBRO
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'remove_group_member') {
        $groupId = $input['group_id'] ?? null;
        $userId = $input['user_id'] ?? null;
        $reason = $input['reason'] ?? 'Removido pelo administrador';
        
        if (!$groupId || !$userId) {
            jsonError('ID do grupo e utilizador são necessários.');
        }
        
        // Remover membro
        $stmt = $db->prepare("DELETE FROM group_members WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$groupId, $userId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason, details)
            VALUES (?, 'remove_group_member', 'group', ?, ?, ?)
        ");
        $details = json_encode(['removed_user_id' => $userId]);
        $stmt->execute([$_SESSION['user_id'], $groupId, $reason, $details]);
        
        jsonSuccess([], 'Membro removido do grupo.');
    }

    // ============================================
    // MODERAÇÃO - LISTAR COMENTÁRIOS
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_comments') {
        $search = $_GET['search'] ?? '';
        $recipeId = $_GET['recipe_id'] ?? null;
        $userId = $_GET['user_id'] ?? null;
        
        $sql = "SELECT rc.*, u.username, r.title as recipe_title
                FROM recipe_comments rc
                LEFT JOIN users u ON rc.user_id = u.id
                LEFT JOIN recipes r ON rc.recipe_id = r.id
                WHERE 1=1";
        $params = [];
        
        if ($search) {
            $sql .= " AND (rc.comment LIKE ? OR u.username LIKE ?)";
            $searchParam = '%' . $search . '%';
            $params[] = $searchParam;
            $params[] = $searchParam;
        }
        if ($recipeId) {
            $sql .= " AND rc.recipe_id = ?";
            $params[] = $recipeId;
        }
        if ($userId) {
            $sql .= " AND rc.user_id = ?";
            $params[] = $userId;
        }
        
        $sql .= " ORDER BY rc.created_at DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        jsonSuccess($stmt->fetchAll());
    }

    // ============================================
    // MODERAÇÃO - APAGAR COMENTÁRIO
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'delete_comment') {
        $commentId = $input['comment_id'] ?? null;
        $reason = $input['reason'] ?? 'Conteúdo inapropriado';
        
        if (!$commentId) {
            jsonError('ID do comentário não fornecido.');
        }
        
        // Obter detalhes
        $stmt = $db->prepare("SELECT comment, user_id FROM recipe_comments WHERE id = ?");
        $stmt->execute([$commentId]);
        $comment = $stmt->fetch();
        
        if (!$comment) {
            jsonError('Comentário não encontrado.');
        }
        
        // Apagar comentário
        $stmt = $db->prepare("DELETE FROM recipe_comments WHERE id = ?");
        $stmt->execute([$commentId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason, details)
            VALUES (?, 'delete_comment', 'comment', ?, ?, ?)
        ");
        $details = json_encode(['comment_text' => substr($comment['comment'], 0, 100)]);
        $stmt->execute([$_SESSION['user_id'], $commentId, $reason, $details]);
        
        jsonSuccess([], 'Comentário apagado com sucesso.');
    }

    // ============================================
    // MODERAÇÃO - LISTAR AVALIAÇÕES
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_ratings') {
        $recipeId = $_GET['recipe_id'] ?? null;
        $userId = $_GET['user_id'] ?? null;
        $minRating = $_GET['min_rating'] ?? null;
        $maxRating = $_GET['max_rating'] ?? null;
        
        $sql = "SELECT rr.*, u.username, r.title as recipe_title
                FROM recipe_ratings rr
                LEFT JOIN users u ON rr.user_id = u.id
                LEFT JOIN recipes r ON rr.recipe_id = r.id
                WHERE 1=1";
        $params = [];
        
        if ($recipeId) {
            $sql .= " AND rr.recipe_id = ?";
            $params[] = $recipeId;
        }
        if ($userId) {
            $sql .= " AND rr.user_id = ?";
            $params[] = $userId;
        }
        if ($minRating) {
            $sql .= " AND rr.rating >= ?";
            $params[] = $minRating;
        }
        if ($maxRating) {
            $sql .= " AND rr.rating <= ?";
            $params[] = $maxRating;
        }
        
        $sql .= " ORDER BY rr.created_at DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        jsonSuccess($stmt->fetchAll());
    }

    // ============================================
    // MODERAÇÃO - APAGAR AVALIAÇÃO
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'delete_rating') {
        $ratingId = $input['rating_id'] ?? null;
        $reason = $input['reason'] ?? 'Avaliação inadequada';
        
        if (!$ratingId) {
            jsonError('ID da avaliação não fornecido.');
        }
        
        // Apagar avaliação
        $stmt = $db->prepare("DELETE FROM recipe_ratings WHERE id = ?");
        $stmt->execute([$ratingId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason)
            VALUES (?, 'delete_rating', 'rating', ?, ?)
        ");
        $stmt->execute([$_SESSION['user_id'], $ratingId, $reason]);
        
        jsonSuccess([], 'Avaliação apagada com sucesso.');
    }

    // ============================================
    // MODERAÇÃO - LISTAR INFRAÇÕES
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_infractions') {
        $userId = $_GET['user_id'] ?? null;
        $type = $_GET['type'] ?? null;
        
        $sql = "SELECT ui.*, u.username
                FROM user_infractions ui
                LEFT JOIN users u ON ui.user_id = u.id
                WHERE 1=1";
        $params = [];
        
        if ($userId) {
            $sql .= " AND ui.user_id = ?";
            $params[] = $userId;
        }
        if ($type) {
            $sql .= " AND ui.infraction_type = ?";
            $params[] = $type;
        }
        
        $sql .= " ORDER BY ui.created_at DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        jsonSuccess($stmt->fetchAll());
    }

    // ============================================
    // AGENDAMENTOS - LISTAR TODOS
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_schedules') {
        $isPersonal = $_GET['is_personal'] ?? null;
        $userId = $_GET['user_id'] ?? null;
        $groupId = $_GET['group_id'] ?? null;
        $startDate = $_GET['start_date'] ?? null;
        $endDate = $_GET['end_date'] ?? null;
        
        $sql = "SELECT s.*, 
                       u.username as user_name,
                       g.name as group_name,
                       r.title as recipe_title
                FROM schedules s
                LEFT JOIN users u ON s.user_id = u.id
                LEFT JOIN groups g ON s.group_id = g.id
                LEFT JOIN recipes r ON s.recipe_id = r.id
                WHERE 1=1";
        $params = [];
        
        if ($isPersonal !== null) {
            $sql .= " AND s.is_personal = ?";
            $params[] = $isPersonal;
        }
        if ($userId) {
            $sql .= " AND s.user_id = ?";
            $params[] = $userId;
        }
        if ($groupId) {
            $sql .= " AND s.group_id = ?";
            $params[] = $groupId;
        }
        if ($startDate) {
            $sql .= " AND s.scheduled_date >= ?";
            $params[] = $startDate;
        }
        if ($endDate) {
            $sql .= " AND s.scheduled_date <= ?";
            $params[] = $endDate;
        }
        
        $sql .= " ORDER BY s.scheduled_date DESC, s.scheduled_time DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        jsonSuccess($stmt->fetchAll());
    }

    // ============================================
    // AGENDAMENTOS - APAGAR
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'delete_schedule') {
        $scheduleId = $input['schedule_id'] ?? null;
        $reason = $input['reason'] ?? 'Removido pelo administrador';
        
        if (!$scheduleId) {
            jsonError('ID do agendamento não fornecido.');
        }
        
        // Apagar agendamento
        $stmt = $db->prepare("DELETE FROM schedules WHERE id = ?");
        $stmt->execute([$scheduleId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason)
            VALUES (?, 'delete_schedule', 'schedule', ?, ?)
        ");
        $stmt->execute([$_SESSION['user_id'], $scheduleId, $reason]);
        
        jsonSuccess([], 'Agendamento apagado com sucesso.');
    }

    // ============================================
    // SESSÕES - LISTAR ACTIVAS
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_sessions') {
        $stmt = $db->prepare("
            SELECT s.*, u.username, u.email
            FROM sessions s
            LEFT JOIN users u ON s.user_id = u.id
            WHERE s.expires_at > NOW()
            ORDER BY s.created_at DESC
        ");
        $stmt->execute();
        
        jsonSuccess($stmt->fetchAll());
    }

    // ============================================
    // SESSÕES - TERMINAR SESSÃO
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'terminate_session') {
        $sessionId = $input['session_id'] ?? null;
        
        if (!$sessionId) {
            jsonError('ID da sessão não fornecido.');
        }
        
        // Terminar sessão
        $stmt = $db->prepare("DELETE FROM sessions WHERE id = ?");
        $stmt->execute([$sessionId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason)
            VALUES (?, 'terminate_session', 'session', ?, 'Sessão terminada pelo administrador')
        ");
        $stmt->execute([$_SESSION['user_id'], $sessionId]);
        
        jsonSuccess([], 'Sessão terminada com sucesso.');
    }

    // ============================================
    // NOTIFICAÇÕES - ENVIAR NOTIFICAÇÃO DE SISTEMA
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'send_notification') {
        $targetType = $input['target_type'] ?? 'all'; // all, user, group
        $targetId = $input['target_id'] ?? null;
        $title = $input['title'] ?? '';
        $message = $input['message'] ?? '';
        $link = $input['link'] ?? null;
        
        if (!$title || !$message) {
            jsonError('Título e mensagem são necessários.');
        }
        
        $userIds = [];
        
        if ($targetType === 'all') {
            // Todos os utilizadores
            $stmt = $db->query("SELECT id FROM users WHERE is_admin = 0");
            $userIds = array_column($stmt->fetchAll(), 'id');
        } elseif ($targetType === 'user' && $targetId) {
            // Converter user_code para user_id
            $stmt = $db->prepare("SELECT id FROM users WHERE user_code = ?");
            $stmt->execute([$targetId]);
            $user = $stmt->fetch();
            if ($user) {
                $userIds = [$user['id']];
            } else {
                jsonError('Utilizador não encontrado.');
            }
        } elseif ($targetType === 'group' && $targetId) {
            // Membros do grupo
            $stmt = $db->prepare("SELECT user_id FROM group_members WHERE group_id = ?");
            $stmt->execute([$targetId]);
            $userIds = array_column($stmt->fetchAll(), 'user_id');
        }
        
        // Inserir notificações
        $stmt = $db->prepare("
            INSERT INTO notifications (user_id, type, title, message, link, sender_id)
            VALUES (?, 'system', ?, ?, ?, ?)
        ");
        
        $count = 0;
        foreach ($userIds as $userId) {
            $stmt->execute([$userId, $title, $message, $link, $_SESSION['user_id']]);
            $count++;
        }
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, details)
            VALUES (?, 'send_notification', ?, ?, ?)
        ");
        $details = json_encode(['title' => $title, 'recipients' => $count]);
        $stmt->execute([$_SESSION['user_id'], $targetType, $targetId, $details]);
        
        jsonSuccess(['count' => $count], "Notificação enviada para $count utilizadores.");
    }

    // ============================================
    // ANALYTICS - ESTATÍSTICAS AVANÇADAS
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'analytics') {
        // Crescimento de utilizadores (últimos 30 dias)
        $stmt = $db->query("
            SELECT DATE(created_at) as date, COUNT(*) as count
            FROM users
            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            GROUP BY DATE(created_at)
            ORDER BY date ASC
        ");
        $userGrowth = $stmt->fetchAll();
        
        // Receitas por categoria
        $stmt = $db->query("
            SELECT category, COUNT(*) as count
            FROM recipes
            WHERE visibility = 'public'
            GROUP BY category
            ORDER BY count DESC
        ");
        $recipesByCategory = $stmt->fetchAll();
        
        // Utilizadores mais ativos (por receitas criadas)
        $stmt = $db->query("
            SELECT u.id, u.username, COUNT(r.id) as recipe_count
            FROM users u
            LEFT JOIN recipes r ON u.id = r.author_id
            WHERE u.is_admin = 0
            GROUP BY u.id
            ORDER BY recipe_count DESC
            LIMIT 10
        ");
        $activeUsers = $stmt->fetchAll();
        
        // Receitas mais populares (por favoritos)
        $stmt = $db->query("
            SELECT r.id, r.title, r.image, COUNT(f.id) as favorite_count, r.average_rating
            FROM recipes r
            LEFT JOIN favorites f ON r.id = f.recipe_id
            WHERE r.visibility = 'public'
            GROUP BY r.id
            ORDER BY favorite_count DESC
            LIMIT 10
        ");
        $popularRecipes = $stmt->fetchAll();
        
        // Atividade de grupos
        $stmt = $db->query("
            SELECT 
                COUNT(DISTINCT g.id) as total_groups,
                COUNT(DISTINCT gm.user_id) as total_members,
                AVG(member_count) as avg_members_per_group
            FROM groups g
            LEFT JOIN group_members gm ON g.id = gm.group_id
            LEFT JOIN (
                SELECT group_id, COUNT(*) as member_count
                FROM group_members
                GROUP BY group_id
            ) mc ON g.id = mc.group_id
        ");
        $groupStats = $stmt->fetch();
        
        // Comentários e avaliações recentes
        $stmt = $db->query("
            SELECT DATE(created_at) as date, COUNT(*) as count
            FROM recipe_comments
            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            GROUP BY DATE(created_at)
            ORDER BY date ASC
        ");
        $commentsTimeline = $stmt->fetchAll();
        
        $stmt = $db->query("
            SELECT DATE(created_at) as date, COUNT(*) as count
            FROM recipe_ratings
            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            GROUP BY DATE(created_at)
            ORDER BY date ASC
        ");
        $ratingsTimeline = $stmt->fetchAll();
        
        jsonSuccess([
            'userGrowth' => $userGrowth,
            'recipesByCategory' => $recipesByCategory,
            'activeUsers' => $activeUsers,
            'popularRecipes' => $popularRecipes,
            'groupStats' => $groupStats,
            'commentsTimeline' => $commentsTimeline,
            'ratingsTimeline' => $ratingsTimeline
        ]);
    }

    // ============================================
    // BULK - APAGAR MÚLTIPLOS UTILIZADORES
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'bulk_delete_users') {
        $userIds = $input['user_ids'] ?? [];
        $reason = $input['reason'] ?? 'Remoção em massa pelo administrador';
        
        if (empty($userIds) || !is_array($userIds)) {
            jsonError('Lista de IDs não fornecida.');
        }
        
        $count = 0;
        foreach ($userIds as $userId) {
            // Verificar se não é admin
            $stmt = $db->prepare("SELECT is_admin FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            
            if ($user && !$user['is_admin']) {
                $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
                $stmt->execute([$userId]);
                $count++;
            }
        }
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason, details)
            VALUES (?, 'bulk_delete_users', 'user', NULL, ?, ?)
        ");
        $details = json_encode(['count' => $count, 'user_ids' => $userIds]);
        $stmt->execute([$_SESSION['user_id'], $reason, $details]);
        
        jsonSuccess(['deleted_count' => $count], "$count utilizadores apagados com sucesso.");
    }

    // ============================================
    // BULK - BANIR MÚLTIPLOS UTILIZADORES
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'bulk_ban_users') {
        $userIds = $input['user_ids'] ?? [];
        $reason = $input['reason'] ?? 'Banimento em massa';
        
        if (empty($userIds) || !is_array($userIds)) {
            jsonError('Lista de IDs não fornecida.');
        }
        
        $count = 0;
        foreach ($userIds as $userId) {
            // Verificar se não é admin
            $stmt = $db->prepare("SELECT is_admin FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            
            if ($user && !$user['is_admin']) {
                $stmt = $db->prepare("UPDATE users SET banned = 1, banned_reason = ? WHERE id = ?");
                $stmt->execute([$reason, $userId]);
                $count++;
            }
        }
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason, details)
            VALUES (?, 'bulk_ban_users', 'user', NULL, ?, ?)
        ");
        $details = json_encode(['count' => $count, 'user_ids' => $userIds]);
        $stmt->execute([$_SESSION['user_id'], $reason, $details]);
        
        jsonSuccess(['banned_count' => $count], "$count utilizadores banidos com sucesso.");
    }

    // ============================================
    // BULK - APAGAR MÚLTIPLAS RECEITAS
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'bulk_delete_recipes') {
        $recipeIds = $input['recipe_ids'] ?? [];
        $reason = $input['reason'] ?? 'Remoção em massa pelo administrador';
        
        if (empty($recipeIds) || !is_array($recipeIds)) {
            jsonError('Lista de IDs não fornecida.');
        }
        
        $count = 0;
        foreach ($recipeIds as $recipeId) {
            $stmt = $db->prepare("DELETE FROM recipes WHERE id = ?");
            $stmt->execute([$recipeId]);
            if ($stmt->rowCount() > 0) {
                $count++;
            }
        }
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason, details)
            VALUES (?, 'bulk_delete_recipes', 'recipe', NULL, ?, ?)
        ");
        $details = json_encode(['count' => $count, 'recipe_ids' => $recipeIds]);
        $stmt->execute([$_SESSION['user_id'], $reason, $details]);
        
        jsonSuccess(['deleted_count' => $count], "$count receitas apagadas com sucesso.");
    }

    // ============================================
    // BULK - APAGAR MÚLTIPLOS COMENTÁRIOS
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'bulk_delete_comments') {
        $commentIds = $input['comment_ids'] ?? [];
        $reason = $input['reason'] ?? 'Remoção em massa de comentários';
        
        if (empty($commentIds) || !is_array($commentIds)) {
            jsonError('Lista de IDs não fornecida.');
        }
        
        $count = 0;
        foreach ($commentIds as $commentId) {
            $stmt = $db->prepare("DELETE FROM recipe_comments WHERE id = ?");
            $stmt->execute([$commentId]);
            if ($stmt->rowCount() > 0) {
                $count++;
            }
        }
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason, details)
            VALUES (?, 'bulk_delete_comments', 'comment', NULL, ?, ?)
        ");
        $details = json_encode(['count' => $count, 'comment_ids' => $commentIds]);
        $stmt->execute([$_SESSION['user_id'], $reason, $details]);
        
        jsonSuccess(['deleted_count' => $count], "$count comentários apagados com sucesso.");
    }

    // ============================================
    // DEFINIÇÕES - PROMOVER UTILIZADOR A ADMIN
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'promote_to_admin') {
        $userId = $input['user_id'] ?? null;
        
        if (!$userId) {
            jsonError('ID do utilizador não fornecido.');
        }
        
        // Verificar se utilizador existe
        $stmt = $db->prepare("SELECT username, is_admin FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            jsonError('Utilizador não encontrado.');
        }
        
        if ($user['is_admin']) {
            jsonError('Utilizador já é administrador.');
        }
        
        // Promover a admin
        $stmt = $db->prepare("UPDATE users SET is_admin = 1 WHERE id = ?");
        $stmt->execute([$userId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason)
            VALUES (?, 'promote_to_admin', 'user', ?, 'Promovido a administrador')
        ");
        $stmt->execute([$_SESSION['user_id'], $userId]);
        
        jsonSuccess([], "Utilizador {$user['username']} promovido a administrador.");
    }

    // ============================================
    // DEFINIÇÕES - REMOVER ADMIN
    // ============================================
    if ($method === 'POST' && isset($input['action']) && $input['action'] === 'demote_admin') {
        $userId = $input['user_id'] ?? null;
        
        if (!$userId) {
            jsonError('ID do utilizador não fornecido.');
        }
        
        // Não permitir despromover a si mesmo
        if ($userId == $_SESSION['user_id']) {
            jsonError('Não pode remover suas próprias permissões de admin.');
        }
        
        // Verificar se utilizador existe
        $stmt = $db->prepare("SELECT username, is_admin FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            jsonError('Utilizador não encontrado.');
        }
        
        if (!$user['is_admin']) {
            jsonError('Utilizador não é administrador.');
        }
        
        // Remover admin
        $stmt = $db->prepare("UPDATE users SET is_admin = 0 WHERE id = ?");
        $stmt->execute([$userId]);
        
        // Registar ação
        $stmt = $db->prepare("
            INSERT INTO admin_actions (admin_id, action_type, target_type, target_id, reason)
            VALUES (?, 'demote_admin', 'user', ?, 'Removido de administrador')
        ");
        $stmt->execute([$_SESSION['user_id'], $userId]);
        
        jsonSuccess([], "Utilizador {$user['username']} removido de administrador.");
    }

    // ============================================
    // DEFINIÇÕES - LISTAR ADMINISTRADORES
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_admins') {
        $stmt = $db->query("
            SELECT id, username, email, created_at
            FROM users
            WHERE is_admin = 1
            ORDER BY created_at ASC
        ");
        
        jsonSuccess($stmt->fetchAll());
    }

    // ============================================
    // DETALHES COMPLETOS DE UTILIZADOR
    // ============================================
    if ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'user_details') {
        $userId = $_GET['user_id'] ?? null;
        
        if (!$userId) {
            jsonError('ID do utilizador não fornecido.');
        }
        
        // Informação do utilizador
        $stmt = $db->prepare("
            SELECT u.*, 
                   (SELECT COUNT(*) FROM recipes WHERE author_id = u.id) as recipe_count,
                   (SELECT COUNT(*) FROM group_members WHERE user_id = u.id) as group_count,
                   (SELECT COUNT(*) FROM recipe_comments WHERE user_id = u.id) as comment_count,
                   (SELECT COUNT(*) FROM recipe_ratings WHERE user_id = u.id) as rating_count
            FROM users u
            WHERE u.id = ?
        ");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            jsonError('Utilizador não encontrado.');
        }
        
        // Receitas do utilizador
        $stmt = $db->prepare("
            SELECT id, title, category, visibility, created_at, average_rating
            FROM recipes
            WHERE author_id = ?
            ORDER BY created_at DESC
            LIMIT 10
        ");
        $stmt->execute([$userId]);
        $recipes = $stmt->fetchAll();
        
        // Grupos do utilizador
        $stmt = $db->prepare("
            SELECT g.id, g.name, gm.role, gm.joined_at
            FROM groups g
            INNER JOIN group_members gm ON g.id = gm.group_id
            WHERE gm.user_id = ?
            ORDER BY gm.joined_at DESC
        ");
        $stmt->execute([$userId]);
        $groups = $stmt->fetchAll();
        
        // Infrações do utilizador
        $stmt = $db->prepare("
            SELECT *
            FROM user_infractions
            WHERE user_id = ?
            ORDER BY created_at DESC
        ");
        $stmt->execute([$userId]);
        $infractions = $stmt->fetchAll();
        
        // Atividades recentes
        $stmt = $db->prepare("
            SELECT *
            FROM activities
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT 20
        ");
        $stmt->execute([$userId]);
        $activities = $stmt->fetchAll();
        
        jsonSuccess([
            'user' => $user,
            'recipes' => $recipes,
            'groups' => $groups,
            'infractions' => $infractions,
            'activities' => $activities
        ]);
    }

    // Ação não encontrada
    jsonError('Ação não reconhecida.', 404);

} catch (PDOException $e) {
    error_log('Admin API PDO Error: ' . $e->getMessage() . ' - SQL: ' . ($e->getMessage() ?? 'N/A'));
    jsonError('Erro no servidor: ' . $e->getMessage(), 500);
} catch (Exception $e) {
    error_log('Admin API General Error: ' . $e->getMessage());
    jsonError('Erro no servidor: ' . $e->getMessage(), 500);
}
?>
