<?php
// Migração automática para suportar agendamentos pessoais
require_once 'db.php';

try {
    $db = getDB();
    echo "<h2>Migração de Agendamentos Pessoais</h2>";
    echo "<p>Iniciando migração...</p>";
    
    // 1. Adicionar coluna is_personal
    echo "<p>1. Verificando coluna is_personal...</p>";
    $result = $db->query("SHOW COLUMNS FROM schedules LIKE 'is_personal'");
    if ($result->rowCount() == 0) {
        $db->exec("ALTER TABLE schedules ADD COLUMN is_personal TINYINT(1) DEFAULT 0 AFTER notes");
        echo "<p style='color: green;'>✓ Coluna is_personal adicionada!</p>";
    } else {
        echo "<p style='color: blue;'>✓ Coluna is_personal já existe</p>";
    }
    
    // 2. Adicionar coluna schedule_date
    echo "<p>2. Verificando coluna schedule_date...</p>";
    $result = $db->query("SHOW COLUMNS FROM schedules LIKE 'schedule_date'");
    if ($result->rowCount() == 0) {
        $db->exec("ALTER TABLE schedules ADD COLUMN schedule_date DATE NULL AFTER is_personal");
        echo "<p style='color: green;'>✓ Coluna schedule_date adicionada!</p>";
        
        // Copiar dados
        $db->exec("UPDATE schedules SET schedule_date = scheduled_date WHERE schedule_date IS NULL");
        echo "<p style='color: green;'>✓ Dados copiados de scheduled_date</p>";
    } else {
        echo "<p style='color: blue;'>✓ Coluna schedule_date já existe</p>";
    }
    
    // 3. Adicionar coluna meal_time
    echo "<p>3. Verificando coluna meal_time...</p>";
    $result = $db->query("SHOW COLUMNS FROM schedules LIKE 'meal_time'");
    if ($result->rowCount() == 0) {
        $db->exec("ALTER TABLE schedules ADD COLUMN meal_time TIME NULL AFTER schedule_date");
        echo "<p style='color: green;'>✓ Coluna meal_time adicionada!</p>";
        
        // Copiar dados
        $db->exec("UPDATE schedules SET meal_time = scheduled_time WHERE meal_time IS NULL");
        echo "<p style='color: green;'>✓ Dados copiados de scheduled_time</p>";
    } else {
        echo "<p style='color: blue;'>✓ Coluna meal_time já existe</p>";
    }
    
    // 4. Adicionar índice para agendamentos pessoais
    echo "<p>4. Verificando índice idx_personal_schedules...</p>";
    $result = $db->query("SHOW INDEX FROM schedules WHERE Key_name = 'idx_personal_schedules'");
    if ($result->rowCount() == 0) {
        $db->exec("CREATE INDEX idx_personal_schedules ON schedules(user_id, is_personal, schedule_date)");
        echo "<p style='color: green;'>✓ Índice idx_personal_schedules criado!</p>";
    } else {
        echo "<p style='color: blue;'>✓ Índice idx_personal_schedules já existe</p>";
    }
    
    // 5. Atualizar meal_type para suportar novos valores em inglês
    echo "<p>5. Verificando coluna meal_type...</p>";
    $result = $db->query("SHOW COLUMNS FROM schedules WHERE Field = 'meal_type'");
    $column = $result->fetch(PDO::FETCH_ASSOC);
    
    if (strpos($column['Type'], 'breakfast') === false) {
        $db->exec("ALTER TABLE schedules MODIFY COLUMN meal_type VARCHAR(50) DEFAULT 'lunch'");
        echo "<p style='color: green;'>✓ Tipo da coluna meal_type atualizado para VARCHAR</p>";
    } else {
        echo "<p style='color: blue;'>✓ Coluna meal_type já suporta valores em inglês</p>";
    }
    
    echo "<h3 style='color: green;'>✅ Migração concluída com sucesso!</h3>";
    echo "<p>Pode agora usar o sistema de agendamento pessoal.</p>";
    echo "<p><a href='../pages/agendamento-pessoal.html'>Ir para Agendamento Pessoal</a></p>";
    echo "<p><a href='../pages/dashboard.html'>Voltar ao Dashboard</a></p>";
    
} catch (PDOException $e) {
    echo "<h3 style='color: red;'>❌ Erro na migração:</h3>";
    echo "<p style='color: red;'>" . $e->getMessage() . "</p>";
    echo "<p>Por favor, contacte o administrador do sistema.</p>";
}
?>
