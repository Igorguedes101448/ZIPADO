# 📅 Sistema de Agendamento Pessoal

## Descrição
Sistema de planeamento semanal de refeições individual, permitindo aos utilizadores organizarem as suas refeições sem necessidade de criar ou estar em grupos.

## Funcionalidades

### ✨ Características Principais
- 📆 **Calendário Semanal Visual** - Visualização dos 7 dias da semana
- 🍽️ **4 Tipos de Refeições** - Pequeno-almoço, Almoço, Lanche e Jantar
- 📝 **Seleção de Receitas** - Escolha entre as suas receitas pessoais
- ⏰ **Definição de Horários** - Planeie a hora de cada refeição
- 📊 **Estatísticas** - Visualize o progresso do seu planeamento
- 🔄 **Navegação entre Semanas** - Veja semanas passadas e futuras

### 🎯 Tipos de Refeições
1. **🌅 Pequeno-Almoço** - Hora padrão: 08:00
2. **🍽️ Almoço** - Hora padrão: 13:00
3. **☕ Lanche** - Hora padrão: 17:00
4. **🌙 Jantar** - Hora padrão: 20:00

## Instalação

### 1. Executar Migração da Base de Dados
Aceda ao ficheiro de migração para atualizar a estrutura da base de dados:

```
http://localhost/siteguedes/api/migrate_personal_schedules.php
```

Ou execute o SQL diretamente:
```
http://localhost/siteguedes/api/migrate_personal_schedules.sql
```

### 2. Verificar Instalação
As seguintes colunas devem ser adicionadas à tabela `schedules`:
- `is_personal` (TINYINT) - Identifica agendamentos pessoais
- `schedule_date` (DATE) - Data do agendamento (alias de scheduled_date)
- `meal_time` (TIME) - Hora da refeição (alias de scheduled_time)

## Como Usar

### Acesso
1. Faça login no sistema
2. No Dashboard, clique em **"📅 Agendar Refeição"**
3. Ou aceda diretamente: `pages/agendamento-pessoal.html`

### Adicionar Refeição
1. Clique num slot vazio no calendário
2. Selecione o tipo de refeição
3. Escolha uma receita (das suas receitas pessoais)
4. Defina a hora planeada
5. Adicione notas opcionais (ex: comprar ingredientes)
6. Clique em **"Guardar"**

### Editar Refeição
1. Clique numa refeição já agendada
2. Modifique os campos desejados
3. Clique em **"Guardar"**

### Remover Refeição
1. Clique em **"Remover"** na refeição desejada
2. Confirme a remoção

### Navegar entre Semanas
- Use **"← Semana Anterior"** para ver semanas passadas
- Use **"Semana Seguinte →"** para planear semanas futuras

## Estrutura de Ficheiros

### Frontend
- **pages/agendamento-pessoal.html** - Página principal do calendário
- **js/agendamento-pessoal.js** - Lógica de gestão do calendário
- **css/styles.css** - Estilos (usa os estilos globais do sistema)

### Backend
- **api/schedules.php** - API REST para CRUD de agendamentos
- **api/migrate_personal_schedules.php** - Script de migração
- **api/migrate_personal_schedules.sql** - SQL de migração

## API Endpoints

### GET - Listar Agendamentos Pessoais
```
GET /api/schedules.php?is_personal=1&start_date=YYYY-MM-DD&end_date=YYYY-MM-DD
Headers: Authorization: Bearer {token}
```

### POST - Criar Agendamento
```
POST /api/schedules.php
Headers: Authorization: Bearer {token}
Body: {
    "is_personal": true,
    "schedule_date": "YYYY-MM-DD",
    "meal_type": "breakfast|lunch|snack|dinner",
    "recipe_id": 123,
    "meal_time": "HH:MM",
    "notes": "Texto opcional"
}
```

### PUT - Atualizar Agendamento
```
PUT /api/schedules.php?id=123
Headers: Authorization: Bearer {token}
Body: {
    "is_personal": true,
    "schedule_date": "YYYY-MM-DD",
    "meal_type": "breakfast|lunch|snack|dinner",
    "recipe_id": 123,
    "meal_time": "HH:MM",
    "notes": "Texto opcional"
}
```

### DELETE - Remover Agendamento
```
DELETE /api/schedules.php?id=123
Headers: Authorization: Bearer {token}
```

## Estatísticas

O sistema apresenta 3 estatísticas principais:

1. **Refeições Agendadas** - Total de refeições planeadas na semana
2. **Receitas Diferentes** - Número de receitas únicas utilizadas
3. **Taxa de Planeamento** - Percentagem de slots preenchidos (máximo 28: 7 dias × 4 refeições)

## Diferenças com Agendamento de Grupos

| Característica | Agendamento Pessoal | Agendamento de Grupos |
|----------------|---------------------|----------------------|
| Privacidade | ✅ Apenas visível para o utilizador | ❌ Visível para membros do grupo |
| Grupos | ❌ Não requer grupo | ✅ Requer pertencer a um grupo |
| Notificações | ❌ Sem notificações | ✅ Notifica membros |
| Acesso | `agendamento-pessoal.html` | `grupos.html?tab=agendamento` |
| Campo DB | `is_personal = 1` e `group_id = NULL` | `is_personal = 0` e `group_id != NULL` |

## Resolução de Problemas

### Erro ao carregar receitas
- Verifique se tem receitas criadas no sistema
- Aceda a "Nova Receita" para criar a sua primeira receita

### Erro ao guardar agendamento
- Verifique se executou a migração da base de dados
- Verifique se está autenticado corretamente
- Verifique os logs do servidor

### Calendário não aparece
- Limpe o cache do navegador
- Verifique a consola de erros (F12)
- Verifique se o JavaScript está carregado

## Melhorias Futuras

Possíveis melhorias para versões futuras:

- 📱 Vista mensal além da semanal
- 🔔 Notificações/lembretes para refeições planeadas
- 📋 Lista de compras gerada automaticamente
- 📊 Relatórios nutricionais semanais
- 🔄 Repetir agendamento de semanas anteriores
- 📤 Exportar plano semanal para PDF
- 🎨 Cores personalizadas por tipo de refeição
- 🍴 Drag & drop para reorganizar refeições

## Suporte

Para questões ou problemas, contacte o administrador do sistema ou crie uma issue no repositório.

---

**Versão:** 1.0  
**Data:** Fevereiro 2026  
**Autor:** ChefGuedes Development Team
