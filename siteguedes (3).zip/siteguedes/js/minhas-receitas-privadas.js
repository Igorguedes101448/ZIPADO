/* ============================================
   ChefGuedes - Gestão de Receitas Privadas
   Página dedicada para gerir receitas privadas do utilizador
   ============================================ */

let allPrivateRecipes = [];
let filteredRecipes = [];
let currentEditIngredientIndex = 0;

// Subcategorias por categoria principal
const subcategoriesData = {
    'Entrada': ['Sopa', 'Salada', 'Patê', 'Acepipes', 'Outra'],
    'Prato Principal': ['Carne', 'Peixe', 'Vegetariano', 'Massas', 'Arroz', 'Outro'],
    'Sobremesa': ['Bolo', 'Doce', 'Mousse', 'Gelado', 'Fruta', 'Outra'],
    'Bebida': ['Cocktail', 'Sumo', 'Batido', 'Chá', 'Café', 'Outra']
};

// Inicialização
document.addEventListener('DOMContentLoaded', async function() {
    // Proteger rota
    if (!requireAuth()) {
        return;
    }

    await loadPrivateRecipes();
    setupSearchFilter();
});

// Carregar receitas privadas do utilizador
async function loadPrivateRecipes() {
    try {
        // Carregar TODAS as receitas do utilizador (públicas, privadas e rascunhos)
        const response = await fetchWithAuth('/api/recipes.php?user_recipes=true');
        
        if (response.success) {
            allPrivateRecipes = response.data.recipes || [];
            filteredRecipes = [...allPrivateRecipes];
            renderPrivateRecipes();
        } else {
            showError('Erro ao carregar receitas: ' + response.message);
        }
    } catch (error) {
        console.error('Erro ao carregar receitas:', error);
        showError('Erro ao carregar receitas. Por favor, tente novamente.');
    } finally {
        document.getElementById('loadingMessage').style.display = 'none';
    }
}

// Renderizar receitas
function renderPrivateRecipes() {
    const grid = document.getElementById('privateRecipesGrid');
    const noRecipesMsg = document.getElementById('noRecipesMessage');

    if (filteredRecipes.length === 0) {
        grid.style.display = 'none';
        noRecipesMsg.style.display = 'block';
        return;
    }

    grid.style.display = 'grid';
    noRecipesMsg.style.display = 'none';

    grid.innerHTML = filteredRecipes.map(recipe => {
        const visibilityBadge = recipe.is_draft ? 
            '<span style="background: #95a5a6; color: white; padding: 4px 8px; border-radius: 4px; font-size: 0.8rem; margin-left: 8px;">Rascunho</span>' :
            (recipe.visibility === 'private' ? 
                '<span style="background: #e74c3c; color: white; padding: 4px 8px; border-radius: 4px; font-size: 0.8rem; margin-left: 8px;">Privada</span>' :
                '<span style="background: #27ae60; color: white; padding: 4px 8px; border-radius: 4px; font-size: 0.8rem; margin-left: 8px;">Pública</span>');
        
        const imageUrl = recipe.image_url;
        const prepTime = recipe.prep_time ? `${recipe.prep_time} min` : 'N/A';
        const difficulty = recipe.difficulty || 'N/A';
        
        return `
            <div class="recipe-card" style="position: relative;">
                ${imageUrl ? `<img src="${imageUrl}" alt="${recipe.title}">` : ''}
                <div class="recipe-card-content">
                    <h3>
                        ${recipe.title}
                        ${visibilityBadge}
                    </h3>
                    <p>${recipe.description || 'Sem descrição'}</p>
                    <div class="recipe-meta">
                        <span>⏱️ ${prepTime}</span>
                        <span>📊 ${difficulty}</span>
                        <span>📁 ${recipe.category || 'N/A'}</span>
                    </div>
                    <div style="display: flex; gap: 10px; margin-top: 10px;">
                        <button class="btn btn-primary" onclick="openEditModal(${recipe.id})" style="flex: 1;">
                            ✏️ Editar
                        </button>
                        <button class="btn btn-outline" onclick="viewRecipe(${recipe.id})" style="flex: 1;">
                            👁️ Ver
                        </button>
                        <button class="btn" onclick="deleteRecipe(${recipe.id})" 
                                style="background: #e74c3c; color: white; padding: 8px 12px;">
                            🗑️
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// Filtrar receitas
function filterRecipes() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const visibilityFilter = document.getElementById('filterVisibility').value;

    filteredRecipes = allPrivateRecipes.filter(recipe => {
        const matchesSearch = recipe.title.toLowerCase().includes(searchTerm) || 
                            (recipe.description && recipe.description.toLowerCase().includes(searchTerm));
        
        let matchesVisibility = true;
        if (visibilityFilter === 'private') {
            matchesVisibility = recipe.visibility === 'private' && !recipe.is_draft;
        } else if (visibilityFilter === 'draft') {
            matchesVisibility = recipe.is_draft;
        } else if (visibilityFilter === 'public') {
            matchesVisibility = recipe.visibility === 'public' && !recipe.is_draft;
        }

        return matchesSearch && matchesVisibility;
    });

    renderPrivateRecipes();
}

// Configurar filtro de pesquisa
function setupSearchFilter() {
    const searchInput = document.getElementById('searchInput');
    let searchTimeout;

    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(filterRecipes, 300);
    });
}

// Ver receita
function viewRecipe(recipeId) {
    window.location.href = `receita-detalhes.html?id=${recipeId}`;
}

// Abrir modal de edição
async function openEditModal(recipeId) {
    const recipe = allPrivateRecipes.find(r => r.id === recipeId);
    
    if (!recipe) {
        showError('Receita não encontrada');
        return;
    }

    // Preencher formulário
    document.getElementById('editRecipeId').value = recipe.id;
    document.getElementById('editTitle').value = recipe.title;
    document.getElementById('editCategory').value = recipe.category || '';
    document.getElementById('editDescription').value = recipe.description || '';
    document.getElementById('editPrepTime').value = recipe.prep_time || '';
    document.getElementById('editCookTime').value = recipe.cook_time || '';
    document.getElementById('editServings').value = recipe.servings || '';
    document.getElementById('editDifficulty').value = recipe.difficulty || 'Média';
    document.getElementById('editInstructions').value = recipe.instructions || '';
    document.getElementById('editImage').value = recipe.image_url || '';
    document.getElementById('editVisibility').value = recipe.visibility || 'public';
    document.getElementById('editIsDraft').checked = recipe.is_draft || false;

    // Atualizar subcategorias
    updateEditSubcategories();
    document.getElementById('editSubcategory').value = recipe.subcategory || '';

    // Carregar ingredientes
    loadEditIngredients(recipe.ingredients);

    // Mostrar modal
    document.getElementById('editRecipeModal').style.display = 'flex';
}

// Fechar modal de edição
function closeEditModal() {
    document.getElementById('editRecipeModal').style.display = 'none';
    document.getElementById('editRecipeForm').reset();
}

// Atualizar subcategorias no formulário de edição
function updateEditSubcategories() {
    const category = document.getElementById('editCategory').value;
    const subcategorySelect = document.getElementById('editSubcategory');
    
    subcategorySelect.innerHTML = '<option value="">Selecione...</option>';
    
    if (category && subcategoriesData[category]) {
        subcategoriesData[category].forEach(sub => {
            const option = document.createElement('option');
            option.value = sub;
            option.textContent = sub;
            subcategorySelect.appendChild(option);
        });
    }
}

// Carregar ingredientes para edição
function loadEditIngredients(ingredientsData) {
    const container = document.getElementById('editIngredientsContainer');
    container.innerHTML = '';
    currentEditIngredientIndex = 0;

    let ingredients = [];
    
    // Parse dos ingredientes
    if (typeof ingredientsData === 'string') {
        try {
            ingredients = JSON.parse(ingredientsData);
        } catch (e) {
            // Se não for JSON, tentar dividir por linhas
            ingredients = ingredientsData.split('\n').filter(i => i.trim());
        }
    } else if (Array.isArray(ingredientsData)) {
        ingredients = ingredientsData;
    }

    // Se não houver ingredientes, adicionar campo vazio
    if (ingredients.length === 0) {
        addEditIngredient();
        return;
    }

    // Adicionar cada ingrediente
    ingredients.forEach(ingredient => {
        let quantity = '', unit = '', name = '';
        
        if (typeof ingredient === 'object') {
            quantity = ingredient.quantity || '';
            unit = ingredient.unit || '';
            name = ingredient.name || '';
        } else {
            // Tentar parse de string
            const parts = ingredient.split(' ');
            if (parts.length >= 2) {
                quantity = parts[0];
                unit = parts[1];
                name = parts.slice(2).join(' ');
            } else {
                name = ingredient;
            }
        }
        
        addEditIngredient(quantity, unit, name);
    });
}

// Adicionar ingrediente para edição
function addEditIngredient(quantity = '', unit = '', name = '') {
    const container = document.getElementById('editIngredientsContainer');
    const index = currentEditIngredientIndex++;
    
    const ingredientDiv = document.createElement('div');
    ingredientDiv.className = 'ingredient-row';
    ingredientDiv.id = `edit-ingredient-${index}`;
    ingredientDiv.style.cssText = 'display: flex; gap: 10px; margin-bottom: 10px; align-items: center;';
    
    ingredientDiv.innerHTML = `
        <input type="text" placeholder="Quantidade" value="${quantity}" 
               style="width: 100px; padding: 8px; border: 1px solid var(--border-color); border-radius: 4px;">
        <input type="text" placeholder="Unidade" value="${unit}" 
               style="width: 100px; padding: 8px; border: 1px solid var(--border-color); border-radius: 4px;">
        <input type="text" placeholder="Ingrediente" value="${name}" required 
               style="flex: 1; padding: 8px; border: 1px solid var(--border-color); border-radius: 4px;">
        <button type="button" onclick="removeEditIngredient(${index})" 
                style="background: #e74c3c; color: white; border: none; padding: 8px 12px; border-radius: 4px; cursor: pointer;">
            ×
        </button>
    `;
    
    container.appendChild(ingredientDiv);
}

// Remover ingrediente da edição
function removeEditIngredient(index) {
    const ingredient = document.getElementById(`edit-ingredient-${index}`);
    if (ingredient) {
        ingredient.remove();
    }
}

// Coletar ingredientes do formulário de edição
function collectEditIngredients() {
    const ingredientRows = document.querySelectorAll('#editIngredientsContainer .ingredient-row');
    const ingredients = [];
    
    ingredientRows.forEach(row => {
        const inputs = row.querySelectorAll('input');
        const quantity = inputs[0].value.trim();
        const unit = inputs[1].value.trim();
        const name = inputs[2].value.trim();
        
        if (name) {
            ingredients.push({
                quantity: quantity,
                unit: unit,
                name: name
            });
        }
    });
    
    return ingredients;
}

// Atualizar receita
async function updateRecipe(event) {
    event.preventDefault();
    
    const recipeId = document.getElementById('editRecipeId').value;
    const ingredients = collectEditIngredients();
    
    if (ingredients.length === 0) {
        showError('Por favor, adicione pelo menos um ingrediente');
        return;
    }

    const recipeData = {
        title: document.getElementById('editTitle').value.trim(),
        category: document.getElementById('editCategory').value,
        subcategory: document.getElementById('editSubcategory').value,
        description: document.getElementById('editDescription').value.trim(),
        prep_time: parseInt(document.getElementById('editPrepTime').value) || null,
        cook_time: parseInt(document.getElementById('editCookTime').value) || null,
        servings: parseInt(document.getElementById('editServings').value) || null,
        difficulty: document.getElementById('editDifficulty').value,
        ingredients: JSON.stringify(ingredients),
        instructions: document.getElementById('editInstructions').value.trim(),
        image_url: document.getElementById('editImage').value.trim() || null,
        visibility: document.getElementById('editVisibility').value,
        is_draft: document.getElementById('editIsDraft').checked
    };

    // Validação de profanidade
    const profanityCheck = checkProfanity(recipeData.title + ' ' + recipeData.description + ' ' + recipeData.instructions);
    if (profanityCheck.hasProfanity) {
        showError(`Linguagem inapropriada detectada: ${profanityCheck.words.join(', ')}`);
        return;
    }

    try {
        const response = await fetchWithAuth(`/api/recipes.php?id=${recipeId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(recipeData)
        });

        if (response.success) {
            showSuccess('Receita atualizada com sucesso!');
            closeEditModal();
            await loadPrivateRecipes();
        } else {
            showError('Erro ao atualizar receita: ' + response.message);
        }
    } catch (error) {
        console.error('Erro ao atualizar receita:', error);
        showError('Erro ao atualizar receita. Por favor, tente novamente.');
    }
}

// Eliminar receita
async function deleteRecipe(recipeId) {
    const recipe = allPrivateRecipes.find(r => r.id === recipeId);
    
    if (!confirm(`Tem a certeza que deseja eliminar a receita "${recipe.title}"? Esta ação não pode ser revertida.`)) {
        return;
    }

    try {
        const response = await fetchWithAuth(`/api/recipes.php?id=${recipeId}`, {
            method: 'DELETE'
        });

        if (response.success) {
            showSuccess('Receita eliminada com sucesso!');
            await loadPrivateRecipes();
        } else {
            showError('Erro ao eliminar receita: ' + response.message);
        }
    } catch (error) {
        console.error('Erro ao eliminar receita:', error);
        showError('Erro ao eliminar receita. Por favor, tente novamente.');
    }
}

// Funções de utilidade
function showSuccess(message) {
    alert(message); // Pode ser melhorado com um toast/notification mais elegante
}

function showError(message) {
    alert(message); // Pode ser melhorado com um toast/notification mais elegante
}

// Fechar modal ao clicar fora
document.addEventListener('click', function(event) {
    const modal = document.getElementById('editRecipeModal');
    if (event.target === modal) {
        closeEditModal();
    }
});
