# Correção: Exibição de Imagens nas Receitas

## Problema
As imagens das receitas não estavam aparecendo em várias páginas do site (Explorar Receitas, Dashboard, Minhas Receitas, etc.).

## Causa
As receitas no banco de dados tinham o campo `image` como NULL ou vazio, e o JavaScript estava tentando usar esse campo para exibir as imagens.

## Solução Implementada

### 1. API alterada (recipes.php)
- Adicionada função `addImageUrlToRecipes()` que mapeia automaticamente os títulos das receitas para os arquivos de imagem correspondentes em `images/receitas/`
- A função adiciona o campo `image_url` a todas as receitas retornadas pela API
- Suporte para títulos com variações (por exemplo, "Bacalhau á Brás" ou "Bacalhau à Brás")

### 2. Páginas HTML/JavaScript atualizadas
Foram atualizadas as seguintes páginas para usar `image_url` ou `image`:

- **explorar-receitas.html** - Grid de receitas e modal de detalhes
- **minhas-receitas-privadas.html** - Já estava correto (usa minhas-receitas-privadas.js)
- **dashboard.html** - Seção de rascunhos e receitas recentes
- **receita-detalhes.html** - Página de detalhes da receita

### 3. Mapeamento de Imagens

As seguintes receitas estão mapeadas para suas respectivas imagens:

| Título da Receita | Arquivo de Imagem |
|-------------------|-------------------|
| Bacalhau à Brás | bacalhau-bras.jpg |
| Caldo Verde | caldo-verde.jpg |
| Francesinha | francesinha.png |
| Açorda Alentejana | acorda-alentejana.avif |
| Arroz de Marisco | arroz-marisco.jpg |
| Polvo à Lagareiro | polvo-lagareiro.jpg |
| Pastéis de Nata | pasteis-nata.webp |
| Cozido à Portuguesa | cozido-portuguesa.png |

## Como Aplicar a Correção

### Opção 1: Automático (via API)
A API já está configurada para mapear as imagens automaticamente. Basta acessar qualquer página de receitas e as imagens aparecerão.

### Opção 2: Atualizar Banco de Dados (Recomendado)
Para persistir os caminhos das imagens no banco de dados:

1. Acesse o script PHP no navegador:
   ```
   http://localhost/siteguedes/fixes/add_recipe_images.php
   ```

2. Ou execute o SQL diretamente no phpMyAdmin:
   ```
   http://localhost/siteguedes/fixes/add_recipe_images.sql
   ```

## Testar

1. Acesse a página **Explorar Receitas**:
   - http://localhost/siteguedes/pages/explorar-receitas.html

2. As receitas devem aparecer com suas respectivas imagens

3. Clique em uma receita para ver os detalhes completos com imagem

4. Acesse o **Dashboard** para ver as receitas recentes também com imagens

## Adicionar Novas Imagens

Para adicionar imagens para novas receitas:

1. **Coloque o arquivo de imagem** em `images/receitas/`
   - Formatos suportados: jpg, png, webp, avif, gif

2. **Atualize o mapeamento** em `api/recipes.php` na função `addImageUrlToRecipes()`:
   ```php
   $imageMap = [
       'Nome da Receita' => 'nome-do-arquivo.jpg',
       // ... adicione mais aqui
   ];
   ```

3. **Ou salve diretamente no banco** ao criar/editar a receita, enviando o campo `image` com o caminho correto

## Arquivos Modificados

- `api/recipes.php` - Adiciona mapeamento automático de imagens
- `pages/explorar-receitas.html` - Usa image_url
- `pages/dashboard.html` - Usa image_url  
- `pages/receita-detalhes.html` - Usa image_url
- `fixes/add_recipe_images.php` - Script para atualizar banco
- `fixes/add_recipe_images.sql` - SQL para atualizar banco

## Notas

- O JavaScript já tem fallback: tenta usar `image_url` primeiro, depois `image`
- Se uma receita não tiver imagem mapeada, mostrará "Imagem em breve"
- As imagens são carregadas com `onerror` handler para mostrar placeholder se falhar
